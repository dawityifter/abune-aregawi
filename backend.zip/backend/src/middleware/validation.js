const { body, param, query, validationResult } = require('express-validator');

// Centralized validation error handler
function handleValidationErrors(req, res, next) {
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }
  return res.status(400).json({
    success: false,
    message: 'Validation failed',
    errors: errors.array()
  });
}

// Define allowed relationship values
const RELATIONSHIP_VALUES = ['Son', 'Daughter', 'Spouse', 'Parent', 'Sibling', 'Other'];

// Validation for outreach note creation
const validateOutreachCreate = [
  param('id').isInt({ min: 1 }).withMessage('Member ID must be a positive integer'),
  body('note')
    .isString().withMessage('Note must be text')
    .trim()
    .isLength({ min: 1, max: 2000 }).withMessage('Note must be between 1 and 2000 characters'),
  handleValidationErrors
];

// Validation for member queries
const validateMemberQuery = [
  query('page').optional().isInt({ min: 1 }).withMessage('Page must be a positive integer'),
  query('limit').optional().isInt({ min: 1, max: 100 }).withMessage('Limit must be between 1 and 100'),
  query('search').optional().isString().withMessage('Search must be a string'),
  query('role').optional().isIn(['member', 'admin', 'church_leadership', 'treasurer', 'secretary']).withMessage('Invalid role filter'),
  query('phone').optional().isString().withMessage('Phone must be a string')
];

// Validation for member ID parameter
const validateMemberId = [
  param('id').isInt({ min: 1 }).withMessage('Member ID must be a positive integer')
];

// Validation for dependent ID parameter
const validateDependentId = [
  param('dependentId').isInt({ min: 1 }).withMessage('Dependent ID must be a positive integer')
];

// Validation for dependent data
const validateDependentData = [
  body('firstName').notEmpty().trim().withMessage('First name is required'),
  body('lastName').notEmpty().trim().withMessage('Last name is required'),
  // DOB optional for all; if provided must be a valid date
  body('dateOfBirth')
    .optional({ nullable: true, checkFalsy: true })
    .custom((value) => {
      if (value) {
        const d = Date.parse(value);
        if (Number.isNaN(d)) {
          throw new Error('Date of birth must be a valid date');
        }
      }
      return true;
    }),
  body('gender').optional().isIn(['Male', 'Female']).withMessage('Gender must be Male or Female'),
  body('relationship').optional().isIn(RELATIONSHIP_VALUES).withMessage(`Relationship must be one of: ${RELATIONSHIP_VALUES.join(', ')}`),
  body('phone').optional().isString().withMessage('Phone must be a string'),
  body('email').optional({ nullable: true, checkFalsy: true }).isEmail().withMessage('Email must be a valid email address'),
  body('baptismName').optional().isString().withMessage('Baptism name must be a string'),
  body('isBaptized').optional().isBoolean().withMessage('Is baptized must be a boolean'),
  body('baptismDate').optional().isISO8601().withMessage('Baptism date must be a valid date'),
  body('medicalConditions').optional().isString().withMessage('Medical conditions must be a string'),
  body('allergies').optional().isString().withMessage('Allergies must be a string'),
  body('medications').optional().isString().withMessage('Medications must be a string'),
  body('dietaryRestrictions').optional().isString().withMessage('Dietary restrictions must be a string'),
  body('notes').optional().isString().withMessage('Notes must be a string')
];

// Validation for dependent partial update (PATCH) - all fields optional
const validateDependentUpdate = [
  body('firstName').optional().notEmpty().trim().withMessage('First name cannot be empty'),
  body('lastName').optional().notEmpty().trim().withMessage('Last name cannot be empty'),
  // DOB optional for all; if provided must be a valid date
  body('dateOfBirth')
    .optional({ nullable: true, checkFalsy: true })
    .custom((value) => {
      if (value) {
        const d = Date.parse(value);
        if (Number.isNaN(d)) {
          throw new Error('Date of birth must be a valid date');
        }
      }
      return true;
    }),
  body('gender').optional().isIn(['Male', 'Female']).withMessage('Gender must be Male or Female'),
  body('relationship').optional().isIn(RELATIONSHIP_VALUES).withMessage(`Relationship must be one of: ${RELATIONSHIP_VALUES.join(', ')}`),
  body('phone').optional().isString().withMessage('Phone must be a string'),
  body('email').optional({ nullable: true, checkFalsy: true }).isEmail().withMessage('Email must be a valid email address'),
  body('baptismName').optional().isString().withMessage('Baptism name must be a string'),
  body('isBaptized').optional().isBoolean().withMessage('Is baptized must be a boolean'),
  body('baptismDate').optional().isISO8601().withMessage('Baptism date must be a valid date'),
  body('medicalConditions').optional().isString().withMessage('Medical conditions must be a string'),
  body('allergies').optional().isString().withMessage('Allergies must be a string'),
  body('medications').optional().isString().withMessage('Medications must be a string'),
  body('dietaryRestrictions').optional().isString().withMessage('Dietary restrictions must be a string'),
  body('notes').optional().isString().withMessage('Notes must be a string')
];

// Validation for profile updates
const validateProfileUpdate = [
  body('firstName').optional().notEmpty().trim().withMessage('First name cannot be empty'),
  body('lastName').optional().notEmpty().trim().withMessage('Last name cannot be empty'),
  body('email').optional().isEmail().withMessage('Email must be a valid email address'),
  body('phoneNumber').optional().isString().withMessage('Phone number must be a string'),
  // dateOfBirth removed from member registration (only collected for dependents)
  body('gender').optional().isIn(['male', 'female']).withMessage('Gender must be male or female'),
  body('baptismName').optional().isString().withMessage('Baptism name must be a string'),
  body('repentanceFather').optional().isString().withMessage('Repentance father must be a string'),
  body('householdSize').optional().isInt({ min: 1 }).withMessage('Household size must be a positive integer'),
  body('streetLine1').optional().isString().withMessage('Street line 1 must be a string'),
  body('apartmentNo').optional().isString().withMessage('Apartment number must be a string'),
  body('city').optional().isString().withMessage('City must be a string'),
  body('state').optional().isString().withMessage('State must be a string'),
  body('postalCode').optional().isString().withMessage('Postal code must be a string'),
  body('country').optional().isString().withMessage('Country must be a string'),
  body('emergencyContactName').optional().isString().withMessage('Emergency contact name must be a string'),
  body('emergencyContactPhone').optional().isString().withMessage('Emergency contact phone must be a string'),
  body('dateJoinedParish').optional().isISO8601().withMessage('Date joined parish must be a valid date'),
  body('spouseName').optional().isString().withMessage('Spouse name must be a string'),
  body('familyId').optional().isString().withMessage('Family ID must be a string')
];

// Validation for member registration
const validateMemberRegistration = [
  body('firstName').notEmpty().trim().withMessage('First name is required'),
  body('lastName').notEmpty().trim().withMessage('Last name is required'),
  body('phoneNumber').notEmpty().withMessage('Phone number is required'),
  body('email').optional().isEmail().withMessage('Email must be a valid email address'),
  body('dateOfBirth').optional().isISO8601().withMessage('Date of birth must be a valid date'),
  body('gender').optional().isIn(['male', 'female']).withMessage('Gender must be male or female'),
  body('maritalStatus').optional().isIn(['single', 'married', 'divorced', 'widowed']).withMessage('Invalid marital status'),
  // Admin-created members may not have a Firebase account yet; allow missing firebaseUid
  body('firebaseUid').optional().isString().withMessage('Firebase UID must be a string'),
  body('role').optional().isIn(['member', 'admin', 'church_leadership', 'treasurer', 'secretary']).withMessage('Invalid role'),
  body('streetLine1').optional().isString().withMessage('Street line 1 must be a string'),
  body('apartmentNo').optional().isString().withMessage('Apartment number must be a string'),
  body('city').optional().isString().withMessage('City must be a string'),
  body('state').optional().isString().withMessage('State must be a string'),
  body('postalCode').optional().isString().withMessage('Postal code must be a string'),
  body('country').optional().isString().withMessage('Country must be a string'),
  body('emergencyContactName').optional().isString().withMessage('Emergency contact name must be a string'),
  body('emergencyContactPhone').optional().isString().withMessage('Emergency contact phone must be a string'),
  body('dateJoinedParish').optional().isISO8601().withMessage('Date joined parish must be a valid date'),
  body('spouseName').optional().isString().withMessage('Spouse name must be a string'),
  body('baptismName').optional().isString().withMessage('Baptism name must be a string'),
  body('repentanceFather').optional().isString().withMessage('Repentance father must be a string'),
  body('householdSize').optional().isInt({ min: 1 }).withMessage('Household size must be a positive integer'),
  body('isHeadOfHousehold').optional().isBoolean().withMessage('Is head of household must be a boolean'),
  body('spouseEmail').optional().isEmail().withMessage('Spouse email must be a valid email address'),
  body('interestedInServing').optional().isIn(['yes', 'no', 'maybe']).withMessage('Interested in serving must be one of: yes, no, maybe'),
  body('ministries').optional().isArray().withMessage('Ministries must be an array'),
  body('languagePreference').optional().isIn(['en', 'ti']).withMessage('Language preference must be en or ti'),
  body('preferredGivingMethod').optional().isIn(['cash', 'check', 'online', 'other']).withMessage('Invalid preferred giving method'),
  body('titheParticipation').optional().isBoolean().withMessage('Tithe participation must be a boolean'),
  body('yearlyPledge').optional().isFloat({ min: 0 }).withMessage('Yearly pledge must be a non-negative number'),
  // Prefer 'dependents', support legacy 'dependants'
  body('dependents').optional().isArray().withMessage('Dependents must be an array'),
  body('dependants').optional().isArray().withMessage('Dependents must be an array')
];

// Validation for login
const validateLogin = [
  body('phoneNumber').notEmpty().withMessage('Phone number is required'),
  body('otp').notEmpty().withMessage('OTP is required')
];

// Self-claim: start
const validateSelfClaimStart = [
  body('dateOfBirth').optional().isISO8601().withMessage('Date of birth must be a valid date'),
  body('lastName').optional().isString().withMessage('Last name must be a string'),
  handleValidationErrors
];

// Self-claim: verify
const validateSelfClaimVerify = [
  body('dependentId').isInt({ min: 1 }).withMessage('Dependent ID must be a positive integer'),
  body('lastName').optional().isString().withMessage('Last name must be a string'),
  body('dateOfBirth').optional().isISO8601().withMessage('Date of birth must be a valid date'),
  // require at least one of lastName or dateOfBirth
  (req, res, next) => {
    const { lastName, dateOfBirth } = req.body || {};
    if (!lastName && !dateOfBirth) {
      return res.status(400).json({
        success: false,
        message: 'Provide lastName or dateOfBirth for verification'
      });
    }
    return next();
  },
  handleValidationErrors
];

// Self-claim: link
const validateSelfClaimLink = [
  body('dependentId').isInt({ min: 1 }).withMessage('Dependent ID must be a positive integer'),
  body('token').isString().withMessage('Verification token is required'),
  handleValidationErrors
];

module.exports = {
  validateMemberRegistration,
  validateMemberQuery,
  validateMemberId,
  validateDependentId,
  validateDependentData,
  validateDependentUpdate,
  validateProfileUpdate,
  validateLogin,
  RELATIONSHIP_VALUES,
  handleValidationErrors,
  validateSelfClaimStart,
  validateSelfClaimVerify,
  validateSelfClaimLink,
  validateOutreachCreate
};