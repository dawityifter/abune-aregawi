const { execSync } = require('child_process');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

// Configuration
const BACKUP_DIR = path.join(__dirname, '../backup');
const BACKUP_FILE = 'abune_aregawi_db_2025-09-28_141848.sql.gz';
const BACKUP_PATH = path.join(BACKUP_DIR, BACKUP_FILE);
const TIMESTAMP = new Date().toISOString().replace(/[:.]/g, '-');

// Get database URL and parse it
const DATABASE_URL="postgresql://dawit@localhost:5432/abune_aregawi_db";
//const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error('Error: DATABASE_URL environment variable is not set');
  process.exit(1);
}

// Parse database URL
let dbConfig;
try {
  const url = new URL(DATABASE_URL);
  dbConfig = {
    user: url.username,
    password: url.password,
    host: url.hostname,
    port: url.port || '5432',
    database: url.pathname.replace(/^\//, '')
  };
} catch (error) {
  console.error('Error parsing DATABASE_URL:', error.message);
  process.exit(1);
}

// Check if backup file exists
if (!fs.existsSync(BACKUP_PATH)) {
  console.error(`Error: Backup file not found at ${BACKUP_PATH}`);
  process.exit(1);
}

console.log('=== DATABASE IMPORT UTILITY ===\n');
console.log('This script will:');
console.log(`1. Drop and recreate the database ${dbConfig.database}`);
console.log(`2. Import data from ${BACKUP_FILE}`);
console.log('3. Run any pending migrations');
console.log('\nWARNING: This will DESTROY all data in the target database!\n');

// Ask for confirmation
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});

readline.question('Are you sure you want to continue? (yes/no) ', async (answer) => {
  if (answer.toLowerCase() !== 'yes') {
    console.log('Operation cancelled by user');
    process.exit(0);
  }
  
  readline.close();
  
  try {
    // Drop and recreate database
    console.log('\n=== STEP 1: Recreating database ===');
    const postgresUrl = `postgres://${dbConfig.user}:${dbConfig.password}@${dbConfig.host}:${dbConfig.port}/postgres`;
    
    console.log(`Dropping database ${dbConfig.database}...`);
    try {
      execSync(`psql ${postgresUrl} -c "DROP DATABASE IF EXISTS \"${dbConfig.database}\""`, { stdio: 'inherit' });
    } catch (error) {
      console.log('Note: Could not drop database (might not exist yet)');
    }
    
    console.log(`Creating database ${dbConfig.database}...`);
    execSync(`psql ${postgresUrl} -c "CREATE DATABASE \"${dbConfig.database}\""`, { stdio: 'inherit' });
    console.log('✓ Database recreated successfully');
    
    // Import the production backup
    console.log('\n=== STEP 2: Importing production backup ===');
    console.log(`Importing from ${BACKUP_PATH}...`);
    execSync(`gunzip -c ${BACKUP_PATH} | psql ${DATABASE_URL}`, { stdio: 'inherit' });
    console.log('✓ Production data imported successfully');
    
   // Run migrations
    console.log('\n=== STEP 3: Running migrations ===');
    process.chdir(path.join(__dirname, '..')); // Move to backend directory
    execSync('npx sequelize-cli db:migrate', { stdio: 'inherit' });
    console.log('✓ Migrations completed successfully');
    
    console.log('\n=== IMPORT COMPLETE ===');
    console.log('- Production data imported successfully');
    console.log('- All migrations have been applied');
    
  } catch (error) {
    console.error('\n❌ Error during import:', error.message);
    console.log('\nIMPORT FAILED!');
    process.exit(1);
  }
});
