--
-- PostgreSQL database dump
--

-- Dumped from database version 17.4
-- Dumped by pg_dump version 17.5

-- Started on 2025-09-09 17:15:54 CDT

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- TOC entry 17 (class 2615 OID 16492)
-- Name: auth; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA auth;


--
-- TOC entry 13 (class 2615 OID 16388)
-- Name: extensions; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA extensions;


--
-- TOC entry 16 (class 2615 OID 16622)
-- Name: graphql; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql;


--
-- TOC entry 15 (class 2615 OID 16611)
-- Name: graphql_public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA graphql_public;


--
-- TOC entry 11 (class 2615 OID 16386)
-- Name: pgbouncer; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA pgbouncer;


--
-- TOC entry 9 (class 2615 OID 16603)
-- Name: realtime; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA realtime;


--
-- TOC entry 18 (class 2615 OID 16540)
-- Name: storage; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA storage;


--
-- TOC entry 14 (class 2615 OID 16651)
-- Name: vault; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA vault;


--
-- TOC entry 6 (class 3079 OID 16687)
-- Name: pg_graphql; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_graphql WITH SCHEMA graphql;


--
-- TOC entry 4223 (class 0 OID 0)
-- Dependencies: 6
-- Name: EXTENSION pg_graphql; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_graphql IS 'pg_graphql: GraphQL support';


--
-- TOC entry 4 (class 3079 OID 16389)
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA extensions;


--
-- TOC entry 4224 (class 0 OID 0)
-- Dependencies: 4
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- TOC entry 2 (class 3079 OID 16441)
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA extensions;


--
-- TOC entry 4225 (class 0 OID 0)
-- Dependencies: 2
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- TOC entry 5 (class 3079 OID 16652)
-- Name: supabase_vault; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS supabase_vault WITH SCHEMA vault;


--
-- TOC entry 4226 (class 0 OID 0)
-- Dependencies: 5
-- Name: EXTENSION supabase_vault; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION supabase_vault IS 'Supabase Vault Extension';


--
-- TOC entry 3 (class 3079 OID 16430)
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA extensions;


--
-- TOC entry 4227 (class 0 OID 0)
-- Dependencies: 3
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- TOC entry 1069 (class 1247 OID 16780)
-- Name: aal_level; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.aal_level AS ENUM (
    'aal1',
    'aal2',
    'aal3'
);


--
-- TOC entry 1093 (class 1247 OID 16921)
-- Name: code_challenge_method; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.code_challenge_method AS ENUM (
    's256',
    'plain'
);


--
-- TOC entry 1066 (class 1247 OID 16774)
-- Name: factor_status; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_status AS ENUM (
    'unverified',
    'verified'
);


--
-- TOC entry 1063 (class 1247 OID 16769)
-- Name: factor_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.factor_type AS ENUM (
    'totp',
    'webauthn',
    'phone'
);


--
-- TOC entry 1150 (class 1247 OID 63654)
-- Name: oauth_registration_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.oauth_registration_type AS ENUM (
    'dynamic',
    'manual'
);


--
-- TOC entry 1099 (class 1247 OID 16963)
-- Name: one_time_token_type; Type: TYPE; Schema: auth; Owner: -
--

CREATE TYPE auth.one_time_token_type AS ENUM (
    'confirmation_token',
    'reauthentication_token',
    'recovery_token',
    'email_change_token_new',
    'email_change_token_current',
    'phone_change_token'
);


--
-- TOC entry 1183 (class 1247 OID 22920)
-- Name: enum_church_transactions_payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_church_transactions_payment_method AS ENUM (
    'cash',
    'check',
    'zelle',
    'credit_card',
    'debit_card',
    'ach',
    'other'
);


--
-- TOC entry 1180 (class 1247 OID 22908)
-- Name: enum_church_transactions_payment_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_church_transactions_payment_type AS ENUM (
    'membership_due',
    'tithe',
    'donation',
    'event',
    'other'
);


--
-- TOC entry 1153 (class 1247 OID 17338)
-- Name: enum_dependants_gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_dependants_gender AS ENUM (
    'Male',
    'Female'
);


--
-- TOC entry 1219 (class 1247 OID 24526)
-- Name: enum_dependents_gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_dependents_gender AS ENUM (
    'male',
    'female',
    'other'
);


--
-- TOC entry 1198 (class 1247 OID 24126)
-- Name: enum_dependents_new_gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_dependents_new_gender AS ENUM (
    'male',
    'female',
    'other'
);


--
-- TOC entry 1228 (class 1247 OID 24641)
-- Name: enum_dependents_relationship; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_dependents_relationship AS ENUM (
    'Son',
    'Daughter',
    'Spouse',
    'Parent',
    'Sibling',
    'Other'
);


--
-- TOC entry 1246 (class 1247 OID 30208)
-- Name: enum_donations_donation_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_donations_donation_type AS ENUM (
    'one-time',
    'recurring'
);


--
-- TOC entry 1249 (class 1247 OID 30214)
-- Name: enum_donations_frequency; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_donations_frequency AS ENUM (
    'weekly',
    'monthly',
    'quarterly',
    'yearly'
);


--
-- TOC entry 1252 (class 1247 OID 30224)
-- Name: enum_donations_payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_donations_payment_method AS ENUM (
    'card',
    'ach'
);


--
-- TOC entry 1255 (class 1247 OID 30230)
-- Name: enum_donations_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_donations_status AS ENUM (
    'pending',
    'succeeded',
    'failed',
    'canceled'
);


--
-- TOC entry 1135 (class 1247 OID 17269)
-- Name: enum_members_gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_gender AS ENUM (
    'Male',
    'Female',
    'male',
    'female',
    'other'
);


--
-- TOC entry 1243 (class 1247 OID 30201)
-- Name: enum_members_interested_in_serving; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_interested_in_serving AS ENUM (
    'yes',
    'no',
    'maybe'
);


--
-- TOC entry 1141 (class 1247 OID 17284)
-- Name: enum_members_language_preference; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_language_preference AS ENUM (
    'English',
    'Tigrigna',
    'Amharic'
);


--
-- TOC entry 1138 (class 1247 OID 17274)
-- Name: enum_members_marital_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_marital_status AS ENUM (
    'Single',
    'Married',
    'Divorced',
    'Widowed',
    'single',
    'married',
    'divorced',
    'widowed'
);


--
-- TOC entry 1189 (class 1247 OID 24065)
-- Name: enum_members_new_gender; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_new_gender AS ENUM (
    'male',
    'female',
    'other'
);


--
-- TOC entry 1195 (class 1247 OID 24086)
-- Name: enum_members_new_registration_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_new_registration_status AS ENUM (
    'pending',
    'complete',
    'incomplete'
);


--
-- TOC entry 1192 (class 1247 OID 24072)
-- Name: enum_members_new_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_new_role AS ENUM (
    'member',
    'admin',
    'treasurer',
    'secretary',
    'priest',
    'deacon'
);


--
-- TOC entry 1144 (class 1247 OID 17292)
-- Name: enum_members_preferred_giving_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_preferred_giving_method AS ENUM (
    'Cash',
    'Online',
    'Envelope',
    'Check'
);


--
-- TOC entry 1216 (class 1247 OID 24513)
-- Name: enum_members_registration_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_registration_status AS ENUM (
    'pending',
    'complete',
    'incomplete'
);


--
-- TOC entry 1147 (class 1247 OID 17302)
-- Name: enum_members_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_members_role AS ENUM (
    'admin',
    'church_leadership',
    'treasurer',
    'secretary',
    'member',
    'guest',
    'priest',
    'deacon',
    'relationship'
);


--
-- TOC entry 1231 (class 1247 OID 42497)
-- Name: enum_sms_logs_recipient_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_sms_logs_recipient_type AS ENUM (
    'individual',
    'group',
    'all'
);


--
-- TOC entry 1234 (class 1247 OID 42504)
-- Name: enum_sms_logs_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_sms_logs_status AS ENUM (
    'success',
    'partial',
    'failed'
);


--
-- TOC entry 1204 (class 1247 OID 24160)
-- Name: enum_transactions_new_payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_transactions_new_payment_method AS ENUM (
    'cash',
    'check',
    'zelle',
    'credit_card',
    'debit_card',
    'ach',
    'other'
);


--
-- TOC entry 1201 (class 1247 OID 24149)
-- Name: enum_transactions_new_payment_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_transactions_new_payment_type AS ENUM (
    'membership_due',
    'tithe',
    'donation',
    'event',
    'other'
);


--
-- TOC entry 1225 (class 1247 OID 24546)
-- Name: enum_transactions_payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_transactions_payment_method AS ENUM (
    'cash',
    'check',
    'zelle',
    'credit_card',
    'debit_card',
    'ach',
    'other'
);


--
-- TOC entry 1222 (class 1247 OID 24535)
-- Name: enum_transactions_payment_type; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_transactions_payment_type AS ENUM (
    'membership_due',
    'tithe',
    'donation',
    'event',
    'other'
);


--
-- TOC entry 1022 (class 1247 OID 31363)
-- Name: enum_transactions_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.enum_transactions_status AS ENUM (
    'pending',
    'succeeded',
    'failed',
    'canceled'
);


--
-- TOC entry 1123 (class 1247 OID 17134)
-- Name: action; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.action AS ENUM (
    'INSERT',
    'UPDATE',
    'DELETE',
    'TRUNCATE',
    'ERROR'
);


--
-- TOC entry 1114 (class 1247 OID 17095)
-- Name: equality_op; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.equality_op AS ENUM (
    'eq',
    'neq',
    'lt',
    'lte',
    'gt',
    'gte',
    'in'
);


--
-- TOC entry 1117 (class 1247 OID 17109)
-- Name: user_defined_filter; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.user_defined_filter AS (
	column_name text,
	op realtime.equality_op,
	value text
);


--
-- TOC entry 1129 (class 1247 OID 17176)
-- Name: wal_column; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_column AS (
	name text,
	type_name text,
	type_oid oid,
	value jsonb,
	is_pkey boolean,
	is_selectable boolean
);


--
-- TOC entry 1126 (class 1247 OID 17147)
-- Name: wal_rls; Type: TYPE; Schema: realtime; Owner: -
--

CREATE TYPE realtime.wal_rls AS (
	wal jsonb,
	is_rls_enabled boolean,
	subscription_ids uuid[],
	errors text[]
);


--
-- TOC entry 1171 (class 1247 OID 56985)
-- Name: buckettype; Type: TYPE; Schema: storage; Owner: -
--

CREATE TYPE storage.buckettype AS ENUM (
    'STANDARD',
    'ANALYTICS'
);


--
-- TOC entry 350 (class 1255 OID 16538)
-- Name: email(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.email() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.email', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'email')
  )::text
$$;


--
-- TOC entry 4228 (class 0 OID 0)
-- Dependencies: 350
-- Name: FUNCTION email(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.email() IS 'Deprecated. Use auth.jwt() -> ''email'' instead.';


--
-- TOC entry 369 (class 1255 OID 16751)
-- Name: jwt(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.jwt() RETURNS jsonb
    LANGUAGE sql STABLE
    AS $$
  select 
    coalesce(
        nullif(current_setting('request.jwt.claim', true), ''),
        nullif(current_setting('request.jwt.claims', true), '')
    )::jsonb
$$;


--
-- TOC entry 349 (class 1255 OID 16537)
-- Name: role(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.role() RETURNS text
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.role', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'role')
  )::text
$$;


--
-- TOC entry 4229 (class 0 OID 0)
-- Dependencies: 349
-- Name: FUNCTION role(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.role() IS 'Deprecated. Use auth.jwt() -> ''role'' instead.';


--
-- TOC entry 348 (class 1255 OID 16536)
-- Name: uid(); Type: FUNCTION; Schema: auth; Owner: -
--

CREATE FUNCTION auth.uid() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
  select 
  coalesce(
    nullif(current_setting('request.jwt.claim.sub', true), ''),
    (nullif(current_setting('request.jwt.claims', true), '')::jsonb ->> 'sub')
  )::uuid
$$;


--
-- TOC entry 4230 (class 0 OID 0)
-- Dependencies: 348
-- Name: FUNCTION uid(); Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON FUNCTION auth.uid() IS 'Deprecated. Use auth.jwt() -> ''sub'' instead.';


--
-- TOC entry 351 (class 1255 OID 16595)
-- Name: grant_pg_cron_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_cron_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_cron'
  )
  THEN
    grant usage on schema cron to postgres with grant option;

    alter default privileges in schema cron grant all on tables to postgres with grant option;
    alter default privileges in schema cron grant all on functions to postgres with grant option;
    alter default privileges in schema cron grant all on sequences to postgres with grant option;

    alter default privileges for user supabase_admin in schema cron grant all
        on sequences to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on tables to postgres with grant option;
    alter default privileges for user supabase_admin in schema cron grant all
        on functions to postgres with grant option;

    grant all privileges on all tables in schema cron to postgres with grant option;
    revoke all on table cron.job from postgres;
    grant select on table cron.job to postgres with grant option;
  END IF;
END;
$$;


--
-- TOC entry 4231 (class 0 OID 0)
-- Dependencies: 351
-- Name: FUNCTION grant_pg_cron_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_cron_access() IS 'Grants access to pg_cron';


--
-- TOC entry 355 (class 1255 OID 16616)
-- Name: grant_pg_graphql_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_graphql_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
DECLARE
    func_is_graphql_resolve bool;
BEGIN
    func_is_graphql_resolve = (
        SELECT n.proname = 'resolve'
        FROM pg_event_trigger_ddl_commands() AS ev
        LEFT JOIN pg_catalog.pg_proc AS n
        ON ev.objid = n.oid
    );

    IF func_is_graphql_resolve
    THEN
        -- Update public wrapper to pass all arguments through to the pg_graphql resolve func
        DROP FUNCTION IF EXISTS graphql_public.graphql;
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language sql
        as $$
            select graphql.resolve(
                query := query,
                variables := coalesce(variables, '{}'),
                "operationName" := "operationName",
                extensions := extensions
            );
        $$;

        -- This hook executes when `graphql.resolve` is created. That is not necessarily the last
        -- function in the extension so we need to grant permissions on existing entities AND
        -- update default permissions to any others that are created after `graphql.resolve`
        grant usage on schema graphql to postgres, anon, authenticated, service_role;
        grant select on all tables in schema graphql to postgres, anon, authenticated, service_role;
        grant execute on all functions in schema graphql to postgres, anon, authenticated, service_role;
        grant all on all sequences in schema graphql to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on tables to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on functions to postgres, anon, authenticated, service_role;
        alter default privileges in schema graphql grant all on sequences to postgres, anon, authenticated, service_role;

        -- Allow postgres role to allow granting usage on graphql and graphql_public schemas to custom roles
        grant usage on schema graphql_public to postgres with grant option;
        grant usage on schema graphql to postgres with grant option;
    END IF;

END;
$_$;


--
-- TOC entry 4232 (class 0 OID 0)
-- Dependencies: 355
-- Name: FUNCTION grant_pg_graphql_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_graphql_access() IS 'Grants access to pg_graphql';


--
-- TOC entry 352 (class 1255 OID 16597)
-- Name: grant_pg_net_access(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.grant_pg_net_access() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  IF EXISTS (
    SELECT 1
    FROM pg_event_trigger_ddl_commands() AS ev
    JOIN pg_extension AS ext
    ON ev.objid = ext.oid
    WHERE ext.extname = 'pg_net'
  )
  THEN
    IF NOT EXISTS (
      SELECT 1
      FROM pg_roles
      WHERE rolname = 'supabase_functions_admin'
    )
    THEN
      CREATE USER supabase_functions_admin NOINHERIT CREATEROLE LOGIN NOREPLICATION;
    END IF;

    GRANT USAGE ON SCHEMA net TO supabase_functions_admin, postgres, anon, authenticated, service_role;

    IF EXISTS (
      SELECT FROM pg_extension
      WHERE extname = 'pg_net'
      -- all versions in use on existing projects as of 2025-02-20
      -- version 0.12.0 onwards don't need these applied
      AND extversion IN ('0.2', '0.6', '0.7', '0.7.1', '0.8', '0.10.0', '0.11.0')
    ) THEN
      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SECURITY DEFINER;

      ALTER function net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;
      ALTER function net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) SET search_path = net;

      REVOKE ALL ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;
      REVOKE ALL ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) FROM PUBLIC;

      GRANT EXECUTE ON FUNCTION net.http_get(url text, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
      GRANT EXECUTE ON FUNCTION net.http_post(url text, body jsonb, params jsonb, headers jsonb, timeout_milliseconds integer) TO supabase_functions_admin, postgres, anon, authenticated, service_role;
    END IF;
  END IF;
END;
$$;


--
-- TOC entry 4233 (class 0 OID 0)
-- Dependencies: 352
-- Name: FUNCTION grant_pg_net_access(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.grant_pg_net_access() IS 'Grants access to pg_net';


--
-- TOC entry 353 (class 1255 OID 16607)
-- Name: pgrst_ddl_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_ddl_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN SELECT * FROM pg_event_trigger_ddl_commands()
  LOOP
    IF cmd.command_tag IN (
      'CREATE SCHEMA', 'ALTER SCHEMA'
    , 'CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO', 'ALTER TABLE'
    , 'CREATE FOREIGN TABLE', 'ALTER FOREIGN TABLE'
    , 'CREATE VIEW', 'ALTER VIEW'
    , 'CREATE MATERIALIZED VIEW', 'ALTER MATERIALIZED VIEW'
    , 'CREATE FUNCTION', 'ALTER FUNCTION'
    , 'CREATE TRIGGER'
    , 'CREATE TYPE', 'ALTER TYPE'
    , 'CREATE RULE'
    , 'COMMENT'
    )
    -- don't notify in case of CREATE TEMP table or other objects created on pg_temp
    AND cmd.schema_name is distinct from 'pg_temp'
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- TOC entry 354 (class 1255 OID 16608)
-- Name: pgrst_drop_watch(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.pgrst_drop_watch() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
  obj record;
BEGIN
  FOR obj IN SELECT * FROM pg_event_trigger_dropped_objects()
  LOOP
    IF obj.object_type IN (
      'schema'
    , 'table'
    , 'foreign table'
    , 'view'
    , 'materialized view'
    , 'function'
    , 'trigger'
    , 'type'
    , 'rule'
    )
    AND obj.is_temporary IS false -- no pg_temp objects
    THEN
      NOTIFY pgrst, 'reload schema';
    END IF;
  END LOOP;
END; $$;


--
-- TOC entry 356 (class 1255 OID 16618)
-- Name: set_graphql_placeholder(); Type: FUNCTION; Schema: extensions; Owner: -
--

CREATE FUNCTION extensions.set_graphql_placeholder() RETURNS event_trigger
    LANGUAGE plpgsql
    AS $_$
    DECLARE
    graphql_is_dropped bool;
    BEGIN
    graphql_is_dropped = (
        SELECT ev.schema_name = 'graphql_public'
        FROM pg_event_trigger_dropped_objects() AS ev
        WHERE ev.schema_name = 'graphql_public'
    );

    IF graphql_is_dropped
    THEN
        create or replace function graphql_public.graphql(
            "operationName" text default null,
            query text default null,
            variables jsonb default null,
            extensions jsonb default null
        )
            returns jsonb
            language plpgsql
        as $$
            DECLARE
                server_version float;
            BEGIN
                server_version = (SELECT (SPLIT_PART((select version()), ' ', 2))::float);

                IF server_version >= 14 THEN
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql extension is not enabled.'
                            )
                        )
                    );
                ELSE
                    RETURN jsonb_build_object(
                        'errors', jsonb_build_array(
                            jsonb_build_object(
                                'message', 'pg_graphql is only available on projects running Postgres 14 onwards.'
                            )
                        )
                    );
                END IF;
            END;
        $$;
    END IF;

    END;
$_$;


--
-- TOC entry 4234 (class 0 OID 0)
-- Dependencies: 356
-- Name: FUNCTION set_graphql_placeholder(); Type: COMMENT; Schema: extensions; Owner: -
--

COMMENT ON FUNCTION extensions.set_graphql_placeholder() IS 'Reintroduces placeholder function for graphql_public.graphql';


--
-- TOC entry 298 (class 1255 OID 16387)
-- Name: get_auth(text); Type: FUNCTION; Schema: pgbouncer; Owner: -
--

CREATE FUNCTION pgbouncer.get_auth(p_usename text) RETURNS TABLE(username text, password text)
    LANGUAGE plpgsql SECURITY DEFINER
    AS $_$
begin
    raise debug 'PgBouncer auth request: %', p_usename;

    return query
    select 
        rolname::text, 
        case when rolvaliduntil < now() 
            then null 
            else rolpassword::text 
        end 
    from pg_authid 
    where rolname=$1 and rolcanlogin;
end;
$_$;


--
-- TOC entry 384 (class 1255 OID 17169)
-- Name: apply_rls(jsonb, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.apply_rls(wal jsonb, max_record_bytes integer DEFAULT (1024 * 1024)) RETURNS SETOF realtime.wal_rls
    LANGUAGE plpgsql
    AS $$
declare
-- Regclass of the table e.g. public.notes
entity_ regclass = (quote_ident(wal ->> 'schema') || '.' || quote_ident(wal ->> 'table'))::regclass;

-- I, U, D, T: insert, update ...
action realtime.action = (
    case wal ->> 'action'
        when 'I' then 'INSERT'
        when 'U' then 'UPDATE'
        when 'D' then 'DELETE'
        else 'ERROR'
    end
);

-- Is row level security enabled for the table
is_rls_enabled bool = relrowsecurity from pg_class where oid = entity_;

subscriptions realtime.subscription[] = array_agg(subs)
    from
        realtime.subscription subs
    where
        subs.entity = entity_;

-- Subscription vars
roles regrole[] = array_agg(distinct us.claims_role::text)
    from
        unnest(subscriptions) us;

working_role regrole;
claimed_role regrole;
claims jsonb;

subscription_id uuid;
subscription_has_access bool;
visible_to_subscription_ids uuid[] = '{}';

-- structured info for wal's columns
columns realtime.wal_column[];
-- previous identity values for update/delete
old_columns realtime.wal_column[];

error_record_exceeds_max_size boolean = octet_length(wal::text) > max_record_bytes;

-- Primary jsonb output for record
output jsonb;

begin
perform set_config('role', null, true);

columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'columns') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

old_columns =
    array_agg(
        (
            x->>'name',
            x->>'type',
            x->>'typeoid',
            realtime.cast(
                (x->'value') #>> '{}',
                coalesce(
                    (x->>'typeoid')::regtype, -- null when wal2json version <= 2.4
                    (x->>'type')::regtype
                )
            ),
            (pks ->> 'name') is not null,
            true
        )::realtime.wal_column
    )
    from
        jsonb_array_elements(wal -> 'identity') x
        left join jsonb_array_elements(wal -> 'pk') pks
            on (x ->> 'name') = (pks ->> 'name');

for working_role in select * from unnest(roles) loop

    -- Update `is_selectable` for columns and old_columns
    columns =
        array_agg(
            (
                c.name,
                c.type_name,
                c.type_oid,
                c.value,
                c.is_pkey,
                pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
            )::realtime.wal_column
        )
        from
            unnest(columns) c;

    old_columns =
            array_agg(
                (
                    c.name,
                    c.type_name,
                    c.type_oid,
                    c.value,
                    c.is_pkey,
                    pg_catalog.has_column_privilege(working_role, entity_, c.name, 'SELECT')
                )::realtime.wal_column
            )
            from
                unnest(old_columns) c;

    if action <> 'DELETE' and count(1) = 0 from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            -- subscriptions is already filtered by entity
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 400: Bad Request, no primary key']
        )::realtime.wal_rls;

    -- The claims role does not have SELECT permission to the primary key of entity
    elsif action <> 'DELETE' and sum(c.is_selectable::int) <> count(1) from unnest(columns) c where c.is_pkey then
        return next (
            jsonb_build_object(
                'schema', wal ->> 'schema',
                'table', wal ->> 'table',
                'type', action
            ),
            is_rls_enabled,
            (select array_agg(s.subscription_id) from unnest(subscriptions) as s where claims_role = working_role),
            array['Error 401: Unauthorized']
        )::realtime.wal_rls;

    else
        output = jsonb_build_object(
            'schema', wal ->> 'schema',
            'table', wal ->> 'table',
            'type', action,
            'commit_timestamp', to_char(
                ((wal ->> 'timestamp')::timestamptz at time zone 'utc'),
                'YYYY-MM-DD"T"HH24:MI:SS.MS"Z"'
            ),
            'columns', (
                select
                    jsonb_agg(
                        jsonb_build_object(
                            'name', pa.attname,
                            'type', pt.typname
                        )
                        order by pa.attnum asc
                    )
                from
                    pg_attribute pa
                    join pg_type pt
                        on pa.atttypid = pt.oid
                where
                    attrelid = entity_
                    and attnum > 0
                    and pg_catalog.has_column_privilege(working_role, entity_, pa.attname, 'SELECT')
            )
        )
        -- Add "record" key for insert and update
        || case
            when action in ('INSERT', 'UPDATE') then
                jsonb_build_object(
                    'record',
                    (
                        select
                            jsonb_object_agg(
                                -- if unchanged toast, get column name and value from old record
                                coalesce((c).name, (oc).name),
                                case
                                    when (c).name is null then (oc).value
                                    else (c).value
                                end
                            )
                        from
                            unnest(columns) c
                            full outer join unnest(old_columns) oc
                                on (c).name = (oc).name
                        where
                            coalesce((c).is_selectable, (oc).is_selectable)
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                    )
                )
            else '{}'::jsonb
        end
        -- Add "old_record" key for update and delete
        || case
            when action = 'UPDATE' then
                jsonb_build_object(
                        'old_record',
                        (
                            select jsonb_object_agg((c).name, (c).value)
                            from unnest(old_columns) c
                            where
                                (c).is_selectable
                                and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                        )
                    )
            when action = 'DELETE' then
                jsonb_build_object(
                    'old_record',
                    (
                        select jsonb_object_agg((c).name, (c).value)
                        from unnest(old_columns) c
                        where
                            (c).is_selectable
                            and ( not error_record_exceeds_max_size or (octet_length((c).value::text) <= 64))
                            and ( not is_rls_enabled or (c).is_pkey ) -- if RLS enabled, we can't secure deletes so filter to pkey
                    )
                )
            else '{}'::jsonb
        end;

        -- Create the prepared statement
        if is_rls_enabled and action <> 'DELETE' then
            if (select 1 from pg_prepared_statements where name = 'walrus_rls_stmt' limit 1) > 0 then
                deallocate walrus_rls_stmt;
            end if;
            execute realtime.build_prepared_statement_sql('walrus_rls_stmt', entity_, columns);
        end if;

        visible_to_subscription_ids = '{}';

        for subscription_id, claims in (
                select
                    subs.subscription_id,
                    subs.claims
                from
                    unnest(subscriptions) subs
                where
                    subs.entity = entity_
                    and subs.claims_role = working_role
                    and (
                        realtime.is_visible_through_filters(columns, subs.filters)
                        or (
                          action = 'DELETE'
                          and realtime.is_visible_through_filters(old_columns, subs.filters)
                        )
                    )
        ) loop

            if not is_rls_enabled or action = 'DELETE' then
                visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
            else
                -- Check if RLS allows the role to see the record
                perform
                    -- Trim leading and trailing quotes from working_role because set_config
                    -- doesn't recognize the role as valid if they are included
                    set_config('role', trim(both '"' from working_role::text), true),
                    set_config('request.jwt.claims', claims::text, true);

                execute 'execute walrus_rls_stmt' into subscription_has_access;

                if subscription_has_access then
                    visible_to_subscription_ids = visible_to_subscription_ids || subscription_id;
                end if;
            end if;
        end loop;

        perform set_config('role', null, true);

        return next (
            output,
            is_rls_enabled,
            visible_to_subscription_ids,
            case
                when error_record_exceeds_max_size then array['Error 413: Payload Too Large']
                else '{}'
            end
        )::realtime.wal_rls;

    end if;
end loop;

perform set_config('role', null, true);
end;
$$;


--
-- TOC entry 390 (class 1255 OID 17248)
-- Name: broadcast_changes(text, text, text, text, text, record, record, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.broadcast_changes(topic_name text, event_name text, operation text, table_name text, table_schema text, new record, old record, level text DEFAULT 'ROW'::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE
    -- Declare a variable to hold the JSONB representation of the row
    row_data jsonb := '{}'::jsonb;
BEGIN
    IF level = 'STATEMENT' THEN
        RAISE EXCEPTION 'function can only be triggered for each row, not for each statement';
    END IF;
    -- Check the operation type and handle accordingly
    IF operation = 'INSERT' OR operation = 'UPDATE' OR operation = 'DELETE' THEN
        row_data := jsonb_build_object('old_record', OLD, 'record', NEW, 'operation', operation, 'table', table_name, 'schema', table_schema);
        PERFORM realtime.send (row_data, event_name, topic_name);
    ELSE
        RAISE EXCEPTION 'Unexpected operation type: %', operation;
    END IF;
EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Failed to process the row: %', SQLERRM;
END;

$$;


--
-- TOC entry 386 (class 1255 OID 17181)
-- Name: build_prepared_statement_sql(text, regclass, realtime.wal_column[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.build_prepared_statement_sql(prepared_statement_name text, entity regclass, columns realtime.wal_column[]) RETURNS text
    LANGUAGE sql
    AS $$
      /*
      Builds a sql string that, if executed, creates a prepared statement to
      tests retrive a row from *entity* by its primary key columns.
      Example
          select realtime.build_prepared_statement_sql('public.notes', '{"id"}'::text[], '{"bigint"}'::text[])
      */
          select
      'prepare ' || prepared_statement_name || ' as
          select
              exists(
                  select
                      1
                  from
                      ' || entity || '
                  where
                      ' || string_agg(quote_ident(pkc.name) || '=' || quote_nullable(pkc.value #>> '{}') , ' and ') || '
              )'
          from
              unnest(columns) pkc
          where
              pkc.is_pkey
          group by
              entity
      $$;


--
-- TOC entry 382 (class 1255 OID 17131)
-- Name: cast(text, regtype); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime."cast"(val text, type_ regtype) RETURNS jsonb
    LANGUAGE plpgsql IMMUTABLE
    AS $$
    declare
      res jsonb;
    begin
      execute format('select to_jsonb(%L::'|| type_::text || ')', val)  into res;
      return res;
    end
    $$;


--
-- TOC entry 381 (class 1255 OID 17126)
-- Name: check_equality_op(realtime.equality_op, regtype, text, text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.check_equality_op(op realtime.equality_op, type_ regtype, val_1 text, val_2 text) RETURNS boolean
    LANGUAGE plpgsql IMMUTABLE
    AS $$
      /*
      Casts *val_1* and *val_2* as type *type_* and check the *op* condition for truthiness
      */
      declare
          op_symbol text = (
              case
                  when op = 'eq' then '='
                  when op = 'neq' then '!='
                  when op = 'lt' then '<'
                  when op = 'lte' then '<='
                  when op = 'gt' then '>'
                  when op = 'gte' then '>='
                  when op = 'in' then '= any'
                  else 'UNKNOWN OP'
              end
          );
          res boolean;
      begin
          execute format(
              'select %L::'|| type_::text || ' ' || op_symbol
              || ' ( %L::'
              || (
                  case
                      when op = 'in' then type_::text || '[]'
                      else type_::text end
              )
              || ')', val_1, val_2) into res;
          return res;
      end;
      $$;


--
-- TOC entry 385 (class 1255 OID 17177)
-- Name: is_visible_through_filters(realtime.wal_column[], realtime.user_defined_filter[]); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.is_visible_through_filters(columns realtime.wal_column[], filters realtime.user_defined_filter[]) RETURNS boolean
    LANGUAGE sql IMMUTABLE
    AS $_$
    /*
    Should the record be visible (true) or filtered out (false) after *filters* are applied
    */
        select
            -- Default to allowed when no filters present
            $2 is null -- no filters. this should not happen because subscriptions has a default
            or array_length($2, 1) is null -- array length of an empty array is null
            or bool_and(
                coalesce(
                    realtime.check_equality_op(
                        op:=f.op,
                        type_:=coalesce(
                            col.type_oid::regtype, -- null when wal2json version <= 2.4
                            col.type_name::regtype
                        ),
                        -- cast jsonb to text
                        val_1:=col.value #>> '{}',
                        val_2:=f.value
                    ),
                    false -- if null, filter does not match
                )
            )
        from
            unnest(filters) f
            join unnest(columns) col
                on f.column_name = col.name;
    $_$;


--
-- TOC entry 387 (class 1255 OID 17188)
-- Name: list_changes(name, name, integer, integer); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.list_changes(publication name, slot_name name, max_changes integer, max_record_bytes integer) RETURNS SETOF realtime.wal_rls
    LANGUAGE sql
    SET log_min_messages TO 'fatal'
    AS $$
      with pub as (
        select
          concat_ws(
            ',',
            case when bool_or(pubinsert) then 'insert' else null end,
            case when bool_or(pubupdate) then 'update' else null end,
            case when bool_or(pubdelete) then 'delete' else null end
          ) as w2j_actions,
          coalesce(
            string_agg(
              realtime.quote_wal2json(format('%I.%I', schemaname, tablename)::regclass),
              ','
            ) filter (where ppt.tablename is not null and ppt.tablename not like '% %'),
            ''
          ) w2j_add_tables
        from
          pg_publication pp
          left join pg_publication_tables ppt
            on pp.pubname = ppt.pubname
        where
          pp.pubname = publication
        group by
          pp.pubname
        limit 1
      ),
      w2j as (
        select
          x.*, pub.w2j_add_tables
        from
          pub,
          pg_logical_slot_get_changes(
            slot_name, null, max_changes,
            'include-pk', 'true',
            'include-transaction', 'false',
            'include-timestamp', 'true',
            'include-type-oids', 'true',
            'format-version', '2',
            'actions', pub.w2j_actions,
            'add-tables', pub.w2j_add_tables
          ) x
      )
      select
        xyz.wal,
        xyz.is_rls_enabled,
        xyz.subscription_ids,
        xyz.errors
      from
        w2j,
        realtime.apply_rls(
          wal := w2j.data::jsonb,
          max_record_bytes := max_record_bytes
        ) xyz(wal, is_rls_enabled, subscription_ids, errors)
      where
        w2j.w2j_add_tables <> ''
        and xyz.subscription_ids[1] is not null
    $$;


--
-- TOC entry 380 (class 1255 OID 17125)
-- Name: quote_wal2json(regclass); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.quote_wal2json(entity regclass) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
      select
        (
          select string_agg('' || ch,'')
          from unnest(string_to_array(nsp.nspname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
        )
        || '.'
        || (
          select string_agg('' || ch,'')
          from unnest(string_to_array(pc.relname::text, null)) with ordinality x(ch, idx)
          where
            not (x.idx = 1 and x.ch = '"')
            and not (
              x.idx = array_length(string_to_array(nsp.nspname::text, null), 1)
              and x.ch = '"'
            )
          )
      from
        pg_class pc
        join pg_namespace nsp
          on pc.relnamespace = nsp.oid
      where
        pc.oid = entity
    $$;


--
-- TOC entry 389 (class 1255 OID 17247)
-- Name: send(jsonb, text, text, boolean); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.send(payload jsonb, event text, topic text, private boolean DEFAULT true) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  BEGIN
    -- Set the topic configuration
    EXECUTE format('SET LOCAL realtime.topic TO %L', topic);

    -- Attempt to insert the message
    INSERT INTO realtime.messages (payload, event, topic, private, extension)
    VALUES (payload, event, topic, private, 'broadcast');
  EXCEPTION
    WHEN OTHERS THEN
      -- Capture and notify the error
      RAISE WARNING 'ErrorSendingBroadcastMessage: %', SQLERRM;
  END;
END;
$$;


--
-- TOC entry 379 (class 1255 OID 17123)
-- Name: subscription_check_filters(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.subscription_check_filters() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
    /*
    Validates that the user defined filters for a subscription:
    - refer to valid columns that the claimed role may access
    - values are coercable to the correct column type
    */
    declare
        col_names text[] = coalesce(
                array_agg(c.column_name order by c.ordinal_position),
                '{}'::text[]
            )
            from
                information_schema.columns c
            where
                format('%I.%I', c.table_schema, c.table_name)::regclass = new.entity
                and pg_catalog.has_column_privilege(
                    (new.claims ->> 'role'),
                    format('%I.%I', c.table_schema, c.table_name)::regclass,
                    c.column_name,
                    'SELECT'
                );
        filter realtime.user_defined_filter;
        col_type regtype;

        in_val jsonb;
    begin
        for filter in select * from unnest(new.filters) loop
            -- Filtered column is valid
            if not filter.column_name = any(col_names) then
                raise exception 'invalid column for filter %', filter.column_name;
            end if;

            -- Type is sanitized and safe for string interpolation
            col_type = (
                select atttypid::regtype
                from pg_catalog.pg_attribute
                where attrelid = new.entity
                      and attname = filter.column_name
            );
            if col_type is null then
                raise exception 'failed to lookup type for column %', filter.column_name;
            end if;

            -- Set maximum number of entries for in filter
            if filter.op = 'in'::realtime.equality_op then
                in_val = realtime.cast(filter.value, (col_type::text || '[]')::regtype);
                if coalesce(jsonb_array_length(in_val), 0) > 100 then
                    raise exception 'too many values for `in` filter. Maximum 100';
                end if;
            else
                -- raises an exception if value is not coercable to type
                perform realtime.cast(filter.value, col_type);
            end if;

        end loop;

        -- Apply consistent order to filters so the unique constraint on
        -- (subscription_id, entity, filters) can't be tricked by a different filter order
        new.filters = coalesce(
            array_agg(f order by f.column_name, f.op, f.value),
            '{}'
        ) from unnest(new.filters) f;

        return new;
    end;
    $$;


--
-- TOC entry 383 (class 1255 OID 17158)
-- Name: to_regrole(text); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.to_regrole(role_name text) RETURNS regrole
    LANGUAGE sql IMMUTABLE
    AS $$ select role_name::regrole $$;


--
-- TOC entry 388 (class 1255 OID 17241)
-- Name: topic(); Type: FUNCTION; Schema: realtime; Owner: -
--

CREATE FUNCTION realtime.topic() RETURNS text
    LANGUAGE sql STABLE
    AS $$
select nullif(current_setting('realtime.topic', true), '')::text;
$$;


--
-- TOC entry 394 (class 1255 OID 56963)
-- Name: add_prefixes(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.add_prefixes(_bucket_id text, _name text) RETURNS void
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
DECLARE
    prefixes text[];
BEGIN
    prefixes := "storage"."get_prefixes"("_name");

    IF array_length(prefixes, 1) > 0 THEN
        INSERT INTO storage.prefixes (name, bucket_id)
        SELECT UNNEST(prefixes) as name, "_bucket_id" ON CONFLICT DO NOTHING;
    END IF;
END;
$$;


--
-- TOC entry 375 (class 1255 OID 17028)
-- Name: can_insert_object(text, text, uuid, jsonb); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.can_insert_object(bucketid text, name text, owner uuid, metadata jsonb) RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO "storage"."objects" ("bucket_id", "name", "owner", "metadata") VALUES (bucketid, name, owner, metadata);
  -- hack to rollback the successful insert
  RAISE sqlstate 'PT200' using
  message = 'ROLLBACK',
  detail = 'rollback successful insert';
END
$$;


--
-- TOC entry 395 (class 1255 OID 56964)
-- Name: delete_prefix(text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix(_bucket_id text, _name text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    AS $$
BEGIN
    -- Check if we can delete the prefix
    IF EXISTS(
        SELECT FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name") + 1
          AND "prefixes"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    )
    OR EXISTS(
        SELECT FROM "storage"."objects"
        WHERE "objects"."bucket_id" = "_bucket_id"
          AND "storage"."get_level"("objects"."name") = "storage"."get_level"("_name") + 1
          AND "objects"."name" COLLATE "C" LIKE "_name" || '/%'
        LIMIT 1
    ) THEN
    -- There are sub-objects, skip deletion
    RETURN false;
    ELSE
        DELETE FROM "storage"."prefixes"
        WHERE "prefixes"."bucket_id" = "_bucket_id"
          AND level = "storage"."get_level"("_name")
          AND "prefixes"."name" = "_name";
        RETURN true;
    END IF;
END;
$$;


--
-- TOC entry 398 (class 1255 OID 56967)
-- Name: delete_prefix_hierarchy_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.delete_prefix_hierarchy_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    prefix text;
BEGIN
    prefix := "storage"."get_prefix"(OLD."name");

    IF coalesce(prefix, '') != '' THEN
        PERFORM "storage"."delete_prefix"(OLD."bucket_id", prefix);
    END IF;

    RETURN OLD;
END;
$$;


--
-- TOC entry 404 (class 1255 OID 56982)
-- Name: enforce_bucket_name_length(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.enforce_bucket_name_length() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
begin
    if length(new.name) > 100 then
        raise exception 'bucket name "%" is too long (% characters). Max is 100.', new.name, length(new.name);
    end if;
    return new;
end;
$$;


--
-- TOC entry 372 (class 1255 OID 17002)
-- Name: extension(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.extension(name text) RETURNS text
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
    _filename text;
BEGIN
    SELECT string_to_array(name, '/') INTO _parts;
    SELECT _parts[array_length(_parts,1)] INTO _filename;
    RETURN reverse(split_part(reverse(_filename), '.', 1));
END
$$;


--
-- TOC entry 371 (class 1255 OID 17001)
-- Name: filename(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.filename(name text) RETURNS text
    LANGUAGE plpgsql
    AS $$
DECLARE
_parts text[];
BEGIN
	select string_to_array(name, '/') into _parts;
	return _parts[array_length(_parts,1)];
END
$$;


--
-- TOC entry 370 (class 1255 OID 17000)
-- Name: foldername(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.foldername(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE
    AS $$
DECLARE
    _parts text[];
BEGIN
    -- Split on "/" to get path segments
    SELECT string_to_array(name, '/') INTO _parts;
    -- Return everything except the last segment
    RETURN _parts[1 : array_length(_parts,1) - 1];
END
$$;


--
-- TOC entry 391 (class 1255 OID 56945)
-- Name: get_level(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_level(name text) RETURNS integer
    LANGUAGE sql IMMUTABLE STRICT
    AS $$
SELECT array_length(string_to_array("name", '/'), 1);
$$;


--
-- TOC entry 392 (class 1255 OID 56961)
-- Name: get_prefix(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefix(name text) RETURNS text
    LANGUAGE sql IMMUTABLE STRICT
    AS $_$
SELECT
    CASE WHEN strpos("name", '/') > 0 THEN
             regexp_replace("name", '[\/]{1}[^\/]+\/?$', '')
         ELSE
             ''
        END;
$_$;


--
-- TOC entry 393 (class 1255 OID 56962)
-- Name: get_prefixes(text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_prefixes(name text) RETURNS text[]
    LANGUAGE plpgsql IMMUTABLE STRICT
    AS $$
DECLARE
    parts text[];
    prefixes text[];
    prefix text;
BEGIN
    -- Split the name into parts by '/'
    parts := string_to_array("name", '/');
    prefixes := '{}';

    -- Construct the prefixes, stopping one level below the last part
    FOR i IN 1..array_length(parts, 1) - 1 LOOP
            prefix := array_to_string(parts[1:i], '/');
            prefixes := array_append(prefixes, prefix);
    END LOOP;

    RETURN prefixes;
END;
$$;


--
-- TOC entry 402 (class 1255 OID 56980)
-- Name: get_size_by_bucket(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.get_size_by_bucket() RETURNS TABLE(size bigint, bucket_id text)
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    return query
        select sum((metadata->>'size')::bigint) as size, obj.bucket_id
        from "storage".objects as obj
        group by obj.bucket_id;
END
$$;


--
-- TOC entry 377 (class 1255 OID 17067)
-- Name: list_multipart_uploads_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_multipart_uploads_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, next_key_token text DEFAULT ''::text, next_upload_token text DEFAULT ''::text) RETURNS TABLE(key text, id text, created_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(key COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                        substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1)))
                    ELSE
                        key
                END AS key, id, created_at
            FROM
                storage.s3_multipart_uploads
            WHERE
                bucket_id = $5 AND
                key ILIKE $1 || ''%'' AND
                CASE
                    WHEN $4 != '''' AND $6 = '''' THEN
                        CASE
                            WHEN position($2 IN substring(key from length($1) + 1)) > 0 THEN
                                substring(key from 1 for length($1) + position($2 IN substring(key from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                key COLLATE "C" > $4
                            END
                    ELSE
                        true
                END AND
                CASE
                    WHEN $6 != '''' THEN
                        id COLLATE "C" > $6
                    ELSE
                        true
                    END
            ORDER BY
                key COLLATE "C" ASC, created_at ASC) as e order by key COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_key_token, bucket_id, next_upload_token;
END;
$_$;


--
-- TOC entry 376 (class 1255 OID 17030)
-- Name: list_objects_with_delimiter(text, text, text, integer, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.list_objects_with_delimiter(bucket_id text, prefix_param text, delimiter_param text, max_keys integer DEFAULT 100, start_after text DEFAULT ''::text, next_token text DEFAULT ''::text) RETURNS TABLE(name text, id uuid, metadata jsonb, updated_at timestamp with time zone)
    LANGUAGE plpgsql
    AS $_$
BEGIN
    RETURN QUERY EXECUTE
        'SELECT DISTINCT ON(name COLLATE "C") * from (
            SELECT
                CASE
                    WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                        substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1)))
                    ELSE
                        name
                END AS name, id, metadata, updated_at
            FROM
                storage.objects
            WHERE
                bucket_id = $5 AND
                name ILIKE $1 || ''%'' AND
                CASE
                    WHEN $6 != '''' THEN
                    name COLLATE "C" > $6
                ELSE true END
                AND CASE
                    WHEN $4 != '''' THEN
                        CASE
                            WHEN position($2 IN substring(name from length($1) + 1)) > 0 THEN
                                substring(name from 1 for length($1) + position($2 IN substring(name from length($1) + 1))) COLLATE "C" > $4
                            ELSE
                                name COLLATE "C" > $4
                            END
                    ELSE
                        true
                END
            ORDER BY
                name COLLATE "C" ASC) as e order by name COLLATE "C" LIMIT $3'
        USING prefix_param, delimiter_param, max_keys, next_token, bucket_id, start_after;
END;
$_$;


--
-- TOC entry 397 (class 1255 OID 56966)
-- Name: objects_insert_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_insert_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    NEW.level := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 403 (class 1255 OID 56981)
-- Name: objects_update_prefix_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.objects_update_prefix_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE
    old_prefixes TEXT[];
BEGIN
    -- Ensure this is an update operation and the name has changed
    IF TG_OP = 'UPDATE' AND (NEW."name" <> OLD."name" OR NEW."bucket_id" <> OLD."bucket_id") THEN
        -- Retrieve old prefixes
        old_prefixes := "storage"."get_prefixes"(OLD."name");

        -- Remove old prefixes that are only used by this object
        WITH all_prefixes as (
            SELECT unnest(old_prefixes) as prefix
        ),
        can_delete_prefixes as (
             SELECT prefix
             FROM all_prefixes
             WHERE NOT EXISTS (
                 SELECT 1 FROM "storage"."objects"
                 WHERE "bucket_id" = OLD."bucket_id"
                   AND "name" <> OLD."name"
                   AND "name" LIKE (prefix || '%')
             )
         )
        DELETE FROM "storage"."prefixes" WHERE name IN (SELECT prefix FROM can_delete_prefixes);

        -- Add new prefixes
        PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    END IF;
    -- Set the new level
    NEW."level" := "storage"."get_level"(NEW."name");

    RETURN NEW;
END;
$$;


--
-- TOC entry 378 (class 1255 OID 17083)
-- Name: operation(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.operation() RETURNS text
    LANGUAGE plpgsql STABLE
    AS $$
BEGIN
    RETURN current_setting('storage.operation', true);
END;
$$;


--
-- TOC entry 396 (class 1255 OID 56965)
-- Name: prefixes_insert_trigger(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.prefixes_insert_trigger() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    PERFORM "storage"."add_prefixes"(NEW."bucket_id", NEW."name");
    RETURN NEW;
END;
$$;


--
-- TOC entry 373 (class 1255 OID 17017)
-- Name: search(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql
    AS $$
declare
    can_bypass_rls BOOLEAN;
begin
    SELECT rolbypassrls
    INTO can_bypass_rls
    FROM pg_roles
    WHERE rolname = coalesce(nullif(current_setting('role', true), 'none'), current_user);

    IF can_bypass_rls THEN
        RETURN QUERY SELECT * FROM storage.search_v1_optimised(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    ELSE
        RETURN QUERY SELECT * FROM storage.search_legacy_v1(prefix, bucketname, limits, levels, offsets, search, sortcolumn, sortorder);
    END IF;
end;
$$;


--
-- TOC entry 401 (class 1255 OID 56978)
-- Name: search_legacy_v1(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_legacy_v1(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select path_tokens[$1] as folder
           from storage.objects
             where objects.name ilike $2 || $3 || ''%''
               and bucket_id = $4
               and array_length(objects.path_tokens, 1) <> $1
           group by folder
           order by folder ' || v_sort_order || '
     )
     (select folder as "name",
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[$1] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where objects.name ilike $2 || $3 || ''%''
       and bucket_id = $4
       and array_length(objects.path_tokens, 1) = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 400 (class 1255 OID 56977)
-- Name: search_v1_optimised(text, text, integer, integer, integer, text, text, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v1_optimised(prefix text, bucketname text, limits integer DEFAULT 100, levels integer DEFAULT 1, offsets integer DEFAULT 0, search text DEFAULT ''::text, sortcolumn text DEFAULT 'name'::text, sortorder text DEFAULT 'asc'::text) RETURNS TABLE(name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, last_accessed_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
declare
    v_order_by text;
    v_sort_order text;
begin
    case
        when sortcolumn = 'name' then
            v_order_by = 'name';
        when sortcolumn = 'updated_at' then
            v_order_by = 'updated_at';
        when sortcolumn = 'created_at' then
            v_order_by = 'created_at';
        when sortcolumn = 'last_accessed_at' then
            v_order_by = 'last_accessed_at';
        else
            v_order_by = 'name';
        end case;

    case
        when sortorder = 'asc' then
            v_sort_order = 'asc';
        when sortorder = 'desc' then
            v_sort_order = 'desc';
        else
            v_sort_order = 'asc';
        end case;

    v_order_by = v_order_by || ' ' || v_sort_order;

    return query execute
        'with folders as (
           select (string_to_array(name, ''/''))[level] as name
           from storage.prefixes
             where lower(prefixes.name) like lower($2 || $3) || ''%''
               and bucket_id = $4
               and level = $1
           order by name ' || v_sort_order || '
     )
     (select name,
            null as id,
            null as updated_at,
            null as created_at,
            null as last_accessed_at,
            null as metadata from folders)
     union all
     (select path_tokens[level] as "name",
            id,
            updated_at,
            created_at,
            last_accessed_at,
            metadata
     from storage.objects
     where lower(objects.name) like lower($2 || $3) || ''%''
       and bucket_id = $4
       and level = $1
     order by ' || v_order_by || ')
     limit $5
     offset $6' using levels, prefix, search, bucketname, limits, offsets;
end;
$_$;


--
-- TOC entry 399 (class 1255 OID 56972)
-- Name: search_v2(text, text, integer, integer, text); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.search_v2(prefix text, bucket_name text, limits integer DEFAULT 100, levels integer DEFAULT 1, start_after text DEFAULT ''::text) RETURNS TABLE(key text, name text, id uuid, updated_at timestamp with time zone, created_at timestamp with time zone, metadata jsonb)
    LANGUAGE plpgsql STABLE
    AS $_$
BEGIN
    RETURN query EXECUTE
        $sql$
        SELECT * FROM (
            (
                SELECT
                    split_part(name, '/', $4) AS key,
                    name || '/' AS name,
                    NULL::uuid AS id,
                    NULL::timestamptz AS updated_at,
                    NULL::timestamptz AS created_at,
                    NULL::jsonb AS metadata
                FROM storage.prefixes
                WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
                ORDER BY prefixes.name COLLATE "C" LIMIT $3
            )
            UNION ALL
            (SELECT split_part(name, '/', $4) AS key,
                name,
                id,
                updated_at,
                created_at,
                metadata
            FROM storage.objects
            WHERE name COLLATE "C" LIKE $1 || '%'
                AND bucket_id = $2
                AND level = $4
                AND name COLLATE "C" > $5
            ORDER BY name COLLATE "C" LIMIT $3)
        ) obj
        ORDER BY name COLLATE "C" LIMIT $3;
        $sql$
        USING prefix, bucket_name, limits, levels, start_after;
END;
$_$;


--
-- TOC entry 374 (class 1255 OID 17018)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: storage; Owner: -
--

CREATE FUNCTION storage.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW; 
END;
$$;


SET default_table_access_method = heap;

--
-- TOC entry 236 (class 1259 OID 16523)
-- Name: audit_log_entries; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.audit_log_entries (
    instance_id uuid,
    id uuid NOT NULL,
    payload json,
    created_at timestamp with time zone,
    ip_address character varying(64) DEFAULT ''::character varying NOT NULL
);


--
-- TOC entry 4235 (class 0 OID 0)
-- Dependencies: 236
-- Name: TABLE audit_log_entries; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.audit_log_entries IS 'Auth: Audit trail for user actions.';


--
-- TOC entry 253 (class 1259 OID 16925)
-- Name: flow_state; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.flow_state (
    id uuid NOT NULL,
    user_id uuid,
    auth_code text NOT NULL,
    code_challenge_method auth.code_challenge_method NOT NULL,
    code_challenge text NOT NULL,
    provider_type text NOT NULL,
    provider_access_token text,
    provider_refresh_token text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    authentication_method text NOT NULL,
    auth_code_issued_at timestamp with time zone
);


--
-- TOC entry 4236 (class 0 OID 0)
-- Dependencies: 253
-- Name: TABLE flow_state; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.flow_state IS 'stores metadata for pkce logins';


--
-- TOC entry 244 (class 1259 OID 16723)
-- Name: identities; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.identities (
    provider_id text NOT NULL,
    user_id uuid NOT NULL,
    identity_data jsonb NOT NULL,
    provider text NOT NULL,
    last_sign_in_at timestamp with time zone,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    email text GENERATED ALWAYS AS (lower((identity_data ->> 'email'::text))) STORED,
    id uuid DEFAULT gen_random_uuid() NOT NULL
);


--
-- TOC entry 4237 (class 0 OID 0)
-- Dependencies: 244
-- Name: TABLE identities; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.identities IS 'Auth: Stores identities associated to a user.';


--
-- TOC entry 4238 (class 0 OID 0)
-- Dependencies: 244
-- Name: COLUMN identities.email; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.identities.email IS 'Auth: Email is a generated column that references the optional email property in the identity_data';


--
-- TOC entry 235 (class 1259 OID 16516)
-- Name: instances; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.instances (
    id uuid NOT NULL,
    uuid uuid,
    raw_base_config text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone
);


--
-- TOC entry 4239 (class 0 OID 0)
-- Dependencies: 235
-- Name: TABLE instances; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.instances IS 'Auth: Manages users across multiple sites.';


--
-- TOC entry 248 (class 1259 OID 16812)
-- Name: mfa_amr_claims; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_amr_claims (
    session_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    authentication_method text NOT NULL,
    id uuid NOT NULL
);


--
-- TOC entry 4240 (class 0 OID 0)
-- Dependencies: 248
-- Name: TABLE mfa_amr_claims; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_amr_claims IS 'auth: stores authenticator method reference claims for multi factor authentication';


--
-- TOC entry 247 (class 1259 OID 16800)
-- Name: mfa_challenges; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_challenges (
    id uuid NOT NULL,
    factor_id uuid NOT NULL,
    created_at timestamp with time zone NOT NULL,
    verified_at timestamp with time zone,
    ip_address inet NOT NULL,
    otp_code text,
    web_authn_session_data jsonb
);


--
-- TOC entry 4241 (class 0 OID 0)
-- Dependencies: 247
-- Name: TABLE mfa_challenges; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_challenges IS 'auth: stores metadata about challenge requests made';


--
-- TOC entry 246 (class 1259 OID 16787)
-- Name: mfa_factors; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.mfa_factors (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    friendly_name text,
    factor_type auth.factor_type NOT NULL,
    status auth.factor_status NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    secret text,
    phone text,
    last_challenged_at timestamp with time zone,
    web_authn_credential jsonb,
    web_authn_aaguid uuid
);


--
-- TOC entry 4242 (class 0 OID 0)
-- Dependencies: 246
-- Name: TABLE mfa_factors; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.mfa_factors IS 'auth: stores metadata about factors';


--
-- TOC entry 285 (class 1259 OID 63659)
-- Name: oauth_clients; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.oauth_clients (
    id uuid NOT NULL,
    client_id text NOT NULL,
    client_secret_hash text NOT NULL,
    registration_type auth.oauth_registration_type NOT NULL,
    redirect_uris text NOT NULL,
    grant_types text NOT NULL,
    client_name text,
    client_uri text,
    logo_uri text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    deleted_at timestamp with time zone,
    CONSTRAINT oauth_clients_client_name_length CHECK ((char_length(client_name) <= 1024)),
    CONSTRAINT oauth_clients_client_uri_length CHECK ((char_length(client_uri) <= 2048)),
    CONSTRAINT oauth_clients_logo_uri_length CHECK ((char_length(logo_uri) <= 2048))
);


--
-- TOC entry 254 (class 1259 OID 16975)
-- Name: one_time_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.one_time_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_type auth.one_time_token_type NOT NULL,
    token_hash text NOT NULL,
    relates_to text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    CONSTRAINT one_time_tokens_token_hash_check CHECK ((char_length(token_hash) > 0))
);


--
-- TOC entry 234 (class 1259 OID 16505)
-- Name: refresh_tokens; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.refresh_tokens (
    instance_id uuid,
    id bigint NOT NULL,
    token character varying(255),
    user_id character varying(255),
    revoked boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    parent character varying(255),
    session_id uuid
);


--
-- TOC entry 4243 (class 0 OID 0)
-- Dependencies: 234
-- Name: TABLE refresh_tokens; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.refresh_tokens IS 'Auth: Store of tokens used to refresh JWT tokens once they expire.';


--
-- TOC entry 233 (class 1259 OID 16504)
-- Name: refresh_tokens_id_seq; Type: SEQUENCE; Schema: auth; Owner: -
--

CREATE SEQUENCE auth.refresh_tokens_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4244 (class 0 OID 0)
-- Dependencies: 233
-- Name: refresh_tokens_id_seq; Type: SEQUENCE OWNED BY; Schema: auth; Owner: -
--

ALTER SEQUENCE auth.refresh_tokens_id_seq OWNED BY auth.refresh_tokens.id;


--
-- TOC entry 251 (class 1259 OID 16854)
-- Name: saml_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_providers (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    entity_id text NOT NULL,
    metadata_xml text NOT NULL,
    metadata_url text,
    attribute_mapping jsonb,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    name_id_format text,
    CONSTRAINT "entity_id not empty" CHECK ((char_length(entity_id) > 0)),
    CONSTRAINT "metadata_url not empty" CHECK (((metadata_url = NULL::text) OR (char_length(metadata_url) > 0))),
    CONSTRAINT "metadata_xml not empty" CHECK ((char_length(metadata_xml) > 0))
);


--
-- TOC entry 4245 (class 0 OID 0)
-- Dependencies: 251
-- Name: TABLE saml_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_providers IS 'Auth: Manages SAML Identity Provider connections.';


--
-- TOC entry 252 (class 1259 OID 16872)
-- Name: saml_relay_states; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.saml_relay_states (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    request_id text NOT NULL,
    for_email text,
    redirect_to text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    flow_state_id uuid,
    CONSTRAINT "request_id not empty" CHECK ((char_length(request_id) > 0))
);


--
-- TOC entry 4246 (class 0 OID 0)
-- Dependencies: 252
-- Name: TABLE saml_relay_states; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.saml_relay_states IS 'Auth: Contains SAML Relay State information for each Service Provider initiated login.';


--
-- TOC entry 237 (class 1259 OID 16531)
-- Name: schema_migrations; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.schema_migrations (
    version character varying(255) NOT NULL
);


--
-- TOC entry 4247 (class 0 OID 0)
-- Dependencies: 237
-- Name: TABLE schema_migrations; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.schema_migrations IS 'Auth: Manages updates to the auth system.';


--
-- TOC entry 245 (class 1259 OID 16753)
-- Name: sessions; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    factor_id uuid,
    aal auth.aal_level,
    not_after timestamp with time zone,
    refreshed_at timestamp without time zone,
    user_agent text,
    ip inet,
    tag text
);


--
-- TOC entry 4248 (class 0 OID 0)
-- Dependencies: 245
-- Name: TABLE sessions; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sessions IS 'Auth: Stores session data associated to a user.';


--
-- TOC entry 4249 (class 0 OID 0)
-- Dependencies: 245
-- Name: COLUMN sessions.not_after; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sessions.not_after IS 'Auth: Not after is a nullable column that contains a timestamp after which the session should be regarded as expired.';


--
-- TOC entry 250 (class 1259 OID 16839)
-- Name: sso_domains; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_domains (
    id uuid NOT NULL,
    sso_provider_id uuid NOT NULL,
    domain text NOT NULL,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    CONSTRAINT "domain not empty" CHECK ((char_length(domain) > 0))
);


--
-- TOC entry 4250 (class 0 OID 0)
-- Dependencies: 250
-- Name: TABLE sso_domains; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_domains IS 'Auth: Manages SSO email address domain mapping to an SSO Identity Provider.';


--
-- TOC entry 249 (class 1259 OID 16830)
-- Name: sso_providers; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.sso_providers (
    id uuid NOT NULL,
    resource_id text,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    disabled boolean,
    CONSTRAINT "resource_id not empty" CHECK (((resource_id = NULL::text) OR (char_length(resource_id) > 0)))
);


--
-- TOC entry 4251 (class 0 OID 0)
-- Dependencies: 249
-- Name: TABLE sso_providers; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.sso_providers IS 'Auth: Manages SSO identity provider information; see saml_providers for SAML.';


--
-- TOC entry 4252 (class 0 OID 0)
-- Dependencies: 249
-- Name: COLUMN sso_providers.resource_id; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.sso_providers.resource_id IS 'Auth: Uniquely identifies a SSO provider according to a user-chosen resource ID (case insensitive), useful in infrastructure as code.';


--
-- TOC entry 232 (class 1259 OID 16493)
-- Name: users; Type: TABLE; Schema: auth; Owner: -
--

CREATE TABLE auth.users (
    instance_id uuid,
    id uuid NOT NULL,
    aud character varying(255),
    role character varying(255),
    email character varying(255),
    encrypted_password character varying(255),
    email_confirmed_at timestamp with time zone,
    invited_at timestamp with time zone,
    confirmation_token character varying(255),
    confirmation_sent_at timestamp with time zone,
    recovery_token character varying(255),
    recovery_sent_at timestamp with time zone,
    email_change_token_new character varying(255),
    email_change character varying(255),
    email_change_sent_at timestamp with time zone,
    last_sign_in_at timestamp with time zone,
    raw_app_meta_data jsonb,
    raw_user_meta_data jsonb,
    is_super_admin boolean,
    created_at timestamp with time zone,
    updated_at timestamp with time zone,
    phone text DEFAULT NULL::character varying,
    phone_confirmed_at timestamp with time zone,
    phone_change text DEFAULT ''::character varying,
    phone_change_token character varying(255) DEFAULT ''::character varying,
    phone_change_sent_at timestamp with time zone,
    confirmed_at timestamp with time zone GENERATED ALWAYS AS (LEAST(email_confirmed_at, phone_confirmed_at)) STORED,
    email_change_token_current character varying(255) DEFAULT ''::character varying,
    email_change_confirm_status smallint DEFAULT 0,
    banned_until timestamp with time zone,
    reauthentication_token character varying(255) DEFAULT ''::character varying,
    reauthentication_sent_at timestamp with time zone,
    is_sso_user boolean DEFAULT false NOT NULL,
    deleted_at timestamp with time zone,
    is_anonymous boolean DEFAULT false NOT NULL,
    CONSTRAINT users_email_change_confirm_status_check CHECK (((email_change_confirm_status >= 0) AND (email_change_confirm_status <= 2)))
);


--
-- TOC entry 4253 (class 0 OID 0)
-- Dependencies: 232
-- Name: TABLE users; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON TABLE auth.users IS 'Auth: Stores user login data within a secure schema.';


--
-- TOC entry 4254 (class 0 OID 0)
-- Dependencies: 232
-- Name: COLUMN users.is_sso_user; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON COLUMN auth.users.is_sso_user IS 'Auth: Set this column to true when the account comes from SSO. These accounts can have duplicate emails.';


--
-- TOC entry 266 (class 1259 OID 22895)
-- Name: SequelizeMeta; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public."SequelizeMeta" (
    name character varying(255) NOT NULL
);


--
-- TOC entry 267 (class 1259 OID 22935)
-- Name: church_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.church_transactions (
    id uuid NOT NULL,
    member_id uuid NOT NULL,
    collected_by uuid NOT NULL,
    payment_date date NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_type public.enum_church_transactions_payment_type NOT NULL,
    payment_method public.enum_church_transactions_payment_method NOT NULL,
    receipt_number character varying(100),
    note text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    CONSTRAINT check_positive_amount CHECK ((amount > (0)::numeric)),
    CONSTRAINT check_receipt_for_cash_check CHECK ((((payment_method = ANY (ARRAY['cash'::public.enum_church_transactions_payment_method, 'check'::public.enum_church_transactions_payment_method])) AND (receipt_number IS NOT NULL)) OR (payment_method <> ALL (ARRAY['cash'::public.enum_church_transactions_payment_method, 'check'::public.enum_church_transactions_payment_method]))))
);


--
-- TOC entry 271 (class 1259 OID 24457)
-- Name: dependents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dependents (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    first_name character varying(100) NOT NULL,
    middle_name character varying(100),
    last_name character varying(100) NOT NULL,
    date_of_birth date,
    gender character varying(10),
    relationship public.enum_dependents_relationship,
    medical_conditions text,
    allergies text,
    medications text,
    dietary_restrictions text,
    notes text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    phone character varying(20),
    email character varying(255),
    baptism_name character varying(100),
    is_baptized boolean DEFAULT false,
    baptism_date date,
    linked_member_id bigint,
    interested_in_serving character varying(10) DEFAULT 'no'::character varying NOT NULL,
    language_preference character varying(50)
);


--
-- TOC entry 270 (class 1259 OID 24456)
-- Name: dependents_new_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.dependents ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.dependents_new_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 275 (class 1259 OID 30240)
-- Name: donations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.donations (
    id bigint NOT NULL,
    stripe_payment_intent_id character varying(255) NOT NULL,
    stripe_customer_id character varying(255),
    amount numeric(10,2) NOT NULL,
    currency character varying(3) DEFAULT 'usd'::character varying NOT NULL,
    donation_type public.enum_donations_donation_type NOT NULL,
    frequency public.enum_donations_frequency,
    payment_method public.enum_donations_payment_method NOT NULL,
    status public.enum_donations_status DEFAULT 'pending'::public.enum_donations_status NOT NULL,
    donor_first_name character varying(255) NOT NULL,
    donor_last_name character varying(255) NOT NULL,
    donor_email character varying(255) NOT NULL,
    donor_phone character varying(255),
    donor_address text,
    donor_zip_code character varying(255),
    metadata jsonb,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 274 (class 1259 OID 30239)
-- Name: donations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.donations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4255 (class 0 OID 0)
-- Dependencies: 274
-- Name: donations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.donations_id_seq OWNED BY public.donations.id;


--
-- TOC entry 277 (class 1259 OID 42470)
-- Name: groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.groups (
    id bigint NOT NULL,
    name character varying(150) NOT NULL,
    description character varying(500),
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 276 (class 1259 OID 42469)
-- Name: groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4256 (class 0 OID 0)
-- Dependencies: 276
-- Name: groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.groups_id_seq OWNED BY public.groups.id;


--
-- TOC entry 279 (class 1259 OID 42480)
-- Name: member_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_groups (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    group_id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 278 (class 1259 OID 42479)
-- Name: member_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4257 (class 0 OID 0)
-- Dependencies: 278
-- Name: member_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_groups_id_seq OWNED BY public.member_groups.id;


--
-- TOC entry 265 (class 1259 OID 17357)
-- Name: member_payments_2024; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.member_payments_2024 (
    id integer NOT NULL,
    member_id uuid,
    member_name character varying(255) NOT NULL,
    spouse_name character varying(255),
    phone_1 character varying(255),
    phone_2 character varying(255),
    year integer,
    payment_method character varying(255),
    monthly_payment numeric(10,2),
    total_amount_due numeric(10,2),
    january numeric(10,2),
    february numeric(10,2),
    march numeric(10,2),
    april numeric(10,2),
    may numeric(10,2),
    june numeric(10,2),
    july numeric(10,2),
    august numeric(10,2),
    september numeric(10,2),
    october numeric(10,2),
    november numeric(10,2),
    december numeric(10,2),
    total_collected numeric(10,2),
    balance_due numeric(10,2),
    paid_up_to_date character varying(255),
    number_of_household integer,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 264 (class 1259 OID 17356)
-- Name: member_payments_2024_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.member_payments_2024_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4258 (class 0 OID 0)
-- Dependencies: 264
-- Name: member_payments_2024_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.member_payments_2024_id_seq OWNED BY public.member_payments_2024.id;


--
-- TOC entry 269 (class 1259 OID 24425)
-- Name: members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.members (
    id bigint NOT NULL,
    firebase_uid character varying(255),
    first_name character varying(100) NOT NULL,
    middle_name character varying(100),
    last_name character varying(100) NOT NULL,
    email character varying(255),
    phone_number character varying(20) NOT NULL,
    date_of_birth date,
    gender character varying(10),
    baptism_name character varying(100),
    repentance_father character varying(100),
    household_size integer DEFAULT 1 NOT NULL,
    street_line1 character varying(255),
    apartment_no character varying(50),
    city character varying(100),
    state character varying(50),
    postal_code character varying(20),
    country character varying(100) DEFAULT 'USA'::character varying,
    emergency_contact_name character varying(200),
    emergency_contact_phone character varying(20),
    date_joined_parish date,
    spouse_name character varying(200),
    family_id bigint,
    role character varying(20) DEFAULT 'member'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    registration_status character varying(20) DEFAULT 'pending'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    interested_in_serving public.enum_members_interested_in_serving DEFAULT 'maybe'::public.enum_members_interested_in_serving,
    yearly_pledge numeric(10,2),
    is_welcomed boolean DEFAULT false NOT NULL,
    welcomed_at timestamp with time zone,
    welcomed_by bigint,
    marital_status public.enum_members_marital_status,
    is_imported boolean DEFAULT false NOT NULL
);


--
-- TOC entry 4259 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN members.interested_in_serving; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.interested_in_serving IS 'Whether the member is interested in serving in ministries';


--
-- TOC entry 4260 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN members.yearly_pledge; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.yearly_pledge IS 'Yearly membership pledge amount in USD';


--
-- TOC entry 4261 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN members.is_welcomed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.is_welcomed IS 'Whether the member has been welcomed by the Relationship Department';


--
-- TOC entry 4262 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN members.welcomed_at; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.welcomed_at IS 'Timestamp when the member was welcomed';


--
-- TOC entry 4263 (class 0 OID 0)
-- Dependencies: 269
-- Name: COLUMN members.welcomed_by; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.members.welcomed_by IS 'Member ID of the staff/admin who marked as welcomed';


--
-- TOC entry 268 (class 1259 OID 24424)
-- Name: members_new_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.members ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.members_new_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 286 (class 1259 OID 70305)
-- Name: outreach; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outreach (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    member_id bigint NOT NULL,
    welcomed_by character varying(255) NOT NULL,
    welcomed_date timestamp with time zone DEFAULT now() NOT NULL,
    note text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 281 (class 1259 OID 42512)
-- Name: sms_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sms_logs (
    id bigint NOT NULL,
    sender_id bigint NOT NULL,
    role character varying(50) NOT NULL,
    recipient_type public.enum_sms_logs_recipient_type NOT NULL,
    recipient_member_id bigint,
    group_id bigint,
    recipient_count integer DEFAULT 1 NOT NULL,
    message text NOT NULL,
    status public.enum_sms_logs_status NOT NULL,
    error text,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 280 (class 1259 OID 42511)
-- Name: sms_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.sms_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 4264 (class 0 OID 0)
-- Dependencies: 280
-- Name: sms_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.sms_logs_id_seq OWNED BY public.sms_logs.id;


--
-- TOC entry 273 (class 1259 OID 24473)
-- Name: transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.transactions (
    id bigint NOT NULL,
    member_id bigint NOT NULL,
    collected_by bigint NOT NULL,
    payment_date date DEFAULT CURRENT_DATE NOT NULL,
    amount numeric(10,2) NOT NULL,
    payment_type character varying(20) NOT NULL,
    payment_method character varying(20) NOT NULL,
    receipt_number character varying(100),
    note text,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    external_id character varying(191),
    status public.enum_transactions_status DEFAULT 'succeeded'::public.enum_transactions_status NOT NULL,
    donation_id bigint,
    CONSTRAINT check_positive_amount CHECK ((amount > (0)::numeric)),
    CONSTRAINT check_receipt_for_cash_check CHECK (((((payment_method)::text = ANY ((ARRAY['cash'::character varying, 'check'::character varying])::text[])) AND (receipt_number IS NOT NULL)) OR ((payment_method)::text <> ALL ((ARRAY['cash'::character varying, 'check'::character varying])::text[]))))
);


--
-- TOC entry 4265 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN transactions.external_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.external_id IS 'External payment reference (e.g., Stripe payment_intent id)';


--
-- TOC entry 4266 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN transactions.status; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.status IS 'Settlement status for the transaction';


--
-- TOC entry 4267 (class 0 OID 0)
-- Dependencies: 273
-- Name: COLUMN transactions.donation_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.transactions.donation_id IS 'Optional FK to donations table for Stripe/audit linkage';


--
-- TOC entry 272 (class 1259 OID 24472)
-- Name: transactions_new_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.transactions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.transactions_new_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 284 (class 1259 OID 57007)
-- Name: zelle_memo_matches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.zelle_memo_matches (
    id uuid NOT NULL,
    member_id bigint NOT NULL,
    first_name character varying(100),
    last_name character varying(100),
    memo text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


--
-- TOC entry 263 (class 1259 OID 17251)
-- Name: messages; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.messages (
    topic text NOT NULL,
    extension text NOT NULL,
    payload jsonb,
    event text,
    private boolean DEFAULT false,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    inserted_at timestamp without time zone DEFAULT now() NOT NULL,
    id uuid DEFAULT gen_random_uuid() NOT NULL
)
PARTITION BY RANGE (inserted_at);


--
-- TOC entry 257 (class 1259 OID 17089)
-- Name: schema_migrations; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.schema_migrations (
    version bigint NOT NULL,
    inserted_at timestamp(0) without time zone
);


--
-- TOC entry 260 (class 1259 OID 17111)
-- Name: subscription; Type: TABLE; Schema: realtime; Owner: -
--

CREATE TABLE realtime.subscription (
    id bigint NOT NULL,
    subscription_id uuid NOT NULL,
    entity regclass NOT NULL,
    filters realtime.user_defined_filter[] DEFAULT '{}'::realtime.user_defined_filter[] NOT NULL,
    claims jsonb NOT NULL,
    claims_role regrole GENERATED ALWAYS AS (realtime.to_regrole((claims ->> 'role'::text))) STORED NOT NULL,
    created_at timestamp without time zone DEFAULT timezone('utc'::text, now()) NOT NULL
);


--
-- TOC entry 259 (class 1259 OID 17110)
-- Name: subscription_id_seq; Type: SEQUENCE; Schema: realtime; Owner: -
--

ALTER TABLE realtime.subscription ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME realtime.subscription_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 16544)
-- Name: buckets; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets (
    id text NOT NULL,
    name text NOT NULL,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    public boolean DEFAULT false,
    avif_autodetection boolean DEFAULT false,
    file_size_limit bigint,
    allowed_mime_types text[],
    owner_id text,
    type storage.buckettype DEFAULT 'STANDARD'::storage.buckettype NOT NULL
);


--
-- TOC entry 4268 (class 0 OID 0)
-- Dependencies: 238
-- Name: COLUMN buckets.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.buckets.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 283 (class 1259 OID 56990)
-- Name: buckets_analytics; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.buckets_analytics (
    id text NOT NULL,
    type storage.buckettype DEFAULT 'ANALYTICS'::storage.buckettype NOT NULL,
    format text DEFAULT 'ICEBERG'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 240 (class 1259 OID 16586)
-- Name: migrations; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.migrations (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    hash character varying(40) NOT NULL,
    executed_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


--
-- TOC entry 239 (class 1259 OID 16559)
-- Name: objects; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.objects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    bucket_id text,
    name text,
    owner uuid,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    last_accessed_at timestamp with time zone DEFAULT now(),
    metadata jsonb,
    path_tokens text[] GENERATED ALWAYS AS (string_to_array(name, '/'::text)) STORED,
    version text,
    owner_id text,
    user_metadata jsonb,
    level integer
);


--
-- TOC entry 4269 (class 0 OID 0)
-- Dependencies: 239
-- Name: COLUMN objects.owner; Type: COMMENT; Schema: storage; Owner: -
--

COMMENT ON COLUMN storage.objects.owner IS 'Field is deprecated, use owner_id instead';


--
-- TOC entry 282 (class 1259 OID 56946)
-- Name: prefixes; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.prefixes (
    bucket_id text NOT NULL,
    name text NOT NULL COLLATE pg_catalog."C",
    level integer GENERATED ALWAYS AS (storage.get_level(name)) STORED NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 255 (class 1259 OID 17032)
-- Name: s3_multipart_uploads; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads (
    id text NOT NULL,
    in_progress_size bigint DEFAULT 0 NOT NULL,
    upload_signature text NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    version text NOT NULL,
    owner_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_metadata jsonb
);


--
-- TOC entry 256 (class 1259 OID 17046)
-- Name: s3_multipart_uploads_parts; Type: TABLE; Schema: storage; Owner: -
--

CREATE TABLE storage.s3_multipart_uploads_parts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    upload_id text NOT NULL,
    size bigint DEFAULT 0 NOT NULL,
    part_number integer NOT NULL,
    bucket_id text NOT NULL,
    key text NOT NULL COLLATE pg_catalog."C",
    etag text NOT NULL,
    owner_id text,
    version text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- TOC entry 3665 (class 2604 OID 16508)
-- Name: refresh_tokens id; Type: DEFAULT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens ALTER COLUMN id SET DEFAULT nextval('auth.refresh_tokens_id_seq'::regclass);


--
-- TOC entry 3718 (class 2604 OID 30243)
-- Name: donations id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations ALTER COLUMN id SET DEFAULT nextval('public.donations_id_seq'::regclass);


--
-- TOC entry 3721 (class 2604 OID 42473)
-- Name: groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups ALTER COLUMN id SET DEFAULT nextval('public.groups_id_seq'::regclass);


--
-- TOC entry 3723 (class 2604 OID 42483)
-- Name: member_groups id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_groups ALTER COLUMN id SET DEFAULT nextval('public.member_groups_id_seq'::regclass);


--
-- TOC entry 3699 (class 2604 OID 17360)
-- Name: member_payments_2024 id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_payments_2024 ALTER COLUMN id SET DEFAULT nextval('public.member_payments_2024_id_seq'::regclass);


--
-- TOC entry 3724 (class 2604 OID 42515)
-- Name: sms_logs id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs ALTER COLUMN id SET DEFAULT nextval('public.sms_logs_id_seq'::regclass);


--
-- TOC entry 4174 (class 0 OID 16523)
-- Dependencies: 236
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.audit_log_entries (instance_id, id, payload, created_at, ip_address) FROM stdin;
\.


--
-- TOC entry 4188 (class 0 OID 16925)
-- Dependencies: 253
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.flow_state (id, user_id, auth_code, code_challenge_method, code_challenge, provider_type, provider_access_token, provider_refresh_token, created_at, updated_at, authentication_method, auth_code_issued_at) FROM stdin;
\.


--
-- TOC entry 4179 (class 0 OID 16723)
-- Dependencies: 244
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.identities (provider_id, user_id, identity_data, provider, last_sign_in_at, created_at, updated_at, id) FROM stdin;
\.


--
-- TOC entry 4173 (class 0 OID 16516)
-- Dependencies: 235
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.instances (id, uuid, raw_base_config, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4183 (class 0 OID 16812)
-- Dependencies: 248
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_amr_claims (session_id, created_at, updated_at, authentication_method, id) FROM stdin;
\.


--
-- TOC entry 4182 (class 0 OID 16800)
-- Dependencies: 247
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_challenges (id, factor_id, created_at, verified_at, ip_address, otp_code, web_authn_session_data) FROM stdin;
\.


--
-- TOC entry 4181 (class 0 OID 16787)
-- Dependencies: 246
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.mfa_factors (id, user_id, friendly_name, factor_type, status, created_at, updated_at, secret, phone, last_challenged_at, web_authn_credential, web_authn_aaguid) FROM stdin;
\.


--
-- TOC entry 4216 (class 0 OID 63659)
-- Dependencies: 285
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.oauth_clients (id, client_id, client_secret_hash, registration_type, redirect_uris, grant_types, client_name, client_uri, logo_uri, created_at, updated_at, deleted_at) FROM stdin;
\.


--
-- TOC entry 4189 (class 0 OID 16975)
-- Dependencies: 254
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.one_time_tokens (id, user_id, token_type, token_hash, relates_to, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4172 (class 0 OID 16505)
-- Dependencies: 234
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.refresh_tokens (instance_id, id, token, user_id, revoked, created_at, updated_at, parent, session_id) FROM stdin;
\.


--
-- TOC entry 4186 (class 0 OID 16854)
-- Dependencies: 251
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_providers (id, sso_provider_id, entity_id, metadata_xml, metadata_url, attribute_mapping, created_at, updated_at, name_id_format) FROM stdin;
\.


--
-- TOC entry 4187 (class 0 OID 16872)
-- Dependencies: 252
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.saml_relay_states (id, sso_provider_id, request_id, for_email, redirect_to, created_at, updated_at, flow_state_id) FROM stdin;
\.


--
-- TOC entry 4175 (class 0 OID 16531)
-- Dependencies: 237
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.schema_migrations (version) FROM stdin;
20171026211738
20171026211808
20171026211834
20180103212743
20180108183307
20180119214651
20180125194653
00
20210710035447
20210722035447
20210730183235
20210909172000
20210927181326
20211122151130
20211124214934
20211202183645
20220114185221
20220114185340
20220224000811
20220323170000
20220429102000
20220531120530
20220614074223
20220811173540
20221003041349
20221003041400
20221011041400
20221020193600
20221021073300
20221021082433
20221027105023
20221114143122
20221114143410
20221125140132
20221208132122
20221215195500
20221215195800
20221215195900
20230116124310
20230116124412
20230131181311
20230322519590
20230402418590
20230411005111
20230508135423
20230523124323
20230818113222
20230914180801
20231027141322
20231114161723
20231117164230
20240115144230
20240214120130
20240306115329
20240314092811
20240427152123
20240612123726
20240729123726
20240802193726
20240806073726
20241009103726
20250717082212
20250731150234
\.


--
-- TOC entry 4180 (class 0 OID 16753)
-- Dependencies: 245
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sessions (id, user_id, created_at, updated_at, factor_id, aal, not_after, refreshed_at, user_agent, ip, tag) FROM stdin;
\.


--
-- TOC entry 4185 (class 0 OID 16839)
-- Dependencies: 250
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_domains (id, sso_provider_id, domain, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4184 (class 0 OID 16830)
-- Dependencies: 249
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.sso_providers (id, resource_id, created_at, updated_at, disabled) FROM stdin;
\.


--
-- TOC entry 4170 (class 0 OID 16493)
-- Dependencies: 232
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: -
--

COPY auth.users (instance_id, id, aud, role, email, encrypted_password, email_confirmed_at, invited_at, confirmation_token, confirmation_sent_at, recovery_token, recovery_sent_at, email_change_token_new, email_change, email_change_sent_at, last_sign_in_at, raw_app_meta_data, raw_user_meta_data, is_super_admin, created_at, updated_at, phone, phone_confirmed_at, phone_change, phone_change_token, phone_change_sent_at, email_change_token_current, email_change_confirm_status, banned_until, reauthentication_token, reauthentication_sent_at, is_sso_user, deleted_at, is_anonymous) FROM stdin;
\.


--
-- TOC entry 4197 (class 0 OID 22895)
-- Dependencies: 266
-- Data for Name: SequelizeMeta; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public."SequelizeMeta" (name) FROM stdin;
20250122000000-remove-login-email.js
20250123000000-add-repentance-father-household-size.js
20250712175822-rename-children-to-dependants.js
20250123000001-make-email-optional.js
20250124000000-create-church-transactions.js
20250125000001-simple-refactor-to-bigint.js
20250125000002-create-donations.js
20250130000000-add-church-fields-to-dependents.js
20250130000001-update-relationship-to-enum.js
20250807024456-add-interested-in-serving.js
20250807024942-add-interested-in-serving-enum.js
20250807030529-skip-problematic-migration.js
20250809162900-add-yearly-pledge-to-members.js
20250809172130-add-external-id-to-transactions.js
20250810023000-add-status-to-transactions.js
20250810023500-add-donation-id-to-transactions.js
20250810040618-convert-interested-in-serving-boolean-to-enum.js
20250817090000-add-onboarding-and-relationship-role.js
20250820010000-add-linked-member-id-to-dependents.js
20250823000000-add-interested-in-serving-to-dependents.js
20250823001000-add-language-preference-to-dependents.js
20250817093000-create-groups-and-member-groups.js
20250817093500-create-sms-logs.js
20250823000000-add-marital-status-to-members.js
20250828090000-create-zelle-memo-matches.js
20250831152500-drop-name-day-from-dependents.js
20250907000000-create-outreach.js
\.


--
-- TOC entry 4198 (class 0 OID 22935)
-- Dependencies: 267
-- Data for Name: church_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.church_transactions (id, member_id, collected_by, payment_date, amount, payment_type, payment_method, receipt_number, note, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4202 (class 0 OID 24457)
-- Dependencies: 271
-- Data for Name: dependents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dependents (id, member_id, first_name, middle_name, last_name, date_of_birth, gender, relationship, medical_conditions, allergies, medications, dietary_restrictions, notes, created_at, updated_at, phone, email, baptism_name, is_baptized, baptism_date, linked_member_id, interested_in_serving, language_preference) FROM stdin;
16	186	Aregawi	Arefayne	Gebremariam	\N	male	Spouse	\N	\N	\N	\N	\N	2025-08-24 16:14:46.252	2025-08-24 16:14:46.252	5716229195	a.aregawigeb@gmail.com	\N	f	\N	186	no	\N
17	186	Netanya	Aregawi	Arefeayne	2016-03-11	female	Daughter	\N	\N	\N	\N	\N	2025-08-24 16:16:14.815	2025-08-24 16:16:14.816	\N	\N	wolete mariam	t	\N	186	no	\N
19	322	Aaron	\N	Abebe	2015-01-29	Male	Son	\N	\N	\N	\N	\N	2025-08-31 14:56:56.771	2025-08-31 14:56:56.773	\N	\N	HaileEysus	t	2015-03-30	322	no	\N
20	322	Dinah	\N	Abebe	2024-02-23	Female	Daughter	\N	\N	\N	\N	\N	2025-08-31 14:59:34.676	2025-08-31 14:59:34.677	\N	\N	WeleteTensae	t	2024-08-31	322	no	\N
18	322	Bethel	\N	Abebe	\N	female	Daughter	\N	\N	\N	\N	\N	2025-08-31 14:53:10.641	2025-09-02 17:58:10.25	\N	\N	\N	t	\N	322	no	\N
3	3	Meaza	G	Abera	1980-08-24	Female	Spouse	\N	\N	\N	\N	\N	2025-08-04 02:21:06.316	2025-09-03 01:20:25.77	+14698883430	mabera125@gmail.com	Welete Eyesus	t	\N	3	no	\N
22	324	nnn	\N	ttt	2018-12-22	Male	Son	\N	\N	\N	\N	\N	2025-09-04 03:16:28.688	2025-09-04 03:16:28.688	\N	\N	ffff	f	\N	324	no	\N
23	96	Letebrrhan	Alembrehan	Zeweldi	\N	female	Spouse	\N	\N	\N	\N	\N	2025-09-07 14:52:05.597	2025-09-07 14:52:05.597	4439348709	\N	Letebrhan	f	\N	96	no	\N
24	96	Kannan	\N	Tesfom	\N	male	Son	\N	\N	\N	\N	\N	2025-09-07 14:52:53.381	2025-09-07 14:52:53.381	\N	\N	\N	f	\N	96	no	\N
25	96	Miki	\N	Tesfom	\N	male	Son	\N	\N	\N	\N	\N	2025-09-07 14:53:13.191	2025-09-07 14:53:13.192	\N	\N	\N	f	\N	96	no	\N
26	96	Nehamya	\N	Tesfom	\N	male	Son	\N	\N	\N	\N	\N	2025-09-07 14:53:41.438	2025-09-07 14:53:41.438	\N	\N	\N	f	\N	96	no	\N
4	78	Musye 		Muruts	2005-01-10	Male	Son						2025-08-10 15:28:41.969	2025-08-10 15:28:41.969			Hailesilase	f	\N	78	no	\N
5	78	Ribka		Muruts	2008-12-10	Female	Daughter	\N	\N	\N	\N	\N	2025-08-10 15:28:41.969	2025-08-10 15:28:41.969				f	\N	78	no	\N
6	78	Aaron		Muruts	2015-07-10	Male	Son	\N	\N	\N	\N	\N	2025-08-10 15:28:41.969	2025-08-10 15:28:41.969			G/meskel	t	\N	78	no	\N
8	133	Lydia	Mengistu 	Alemayehu 	2004-09-01	Female	Daughter	\N	\N	\N	\N	\N	2025-08-16 01:28:19.51	2025-08-16 01:28:19.51	\N	\N	\N	f	\N	133	no	\N
9	133	Rakeb	Mengistu	Alemayehu 	2009-12-01	Female	Daughter	\N	\N	\N	\N	\N	2025-08-16 01:28:19.51	2025-08-16 01:28:19.51	\N	\N	\N	f	2009-12-01	133	no	\N
12	181	samuel	seged	Yared	2006-04-09	Male	Son	\N	\N	\N	\N	\N	2025-08-18 16:24:03.769	2025-08-18 16:44:11.449	+14695568747	syared24@gmail.com	zemicahael	t	2006-05-22	181	no	\N
13	181	Daniel	Seged	Yared	2007-10-04	Male	Son	\N	\N	\N	\N	\N	2025-08-18 16:24:03.77	2025-08-18 16:44:18.467	+14699206276	dannyyared99@gmail.com	Habtegiorgis	t	2007-11-18	181	no	\N
1	3	Noah	Dawit	Yifter	2009-10-05	Male	Son	\N	\N	\N	\N	Original ID: 10ff4b69-9305-4701-a7c4-f99ec1dea452\nPhone: +19452179619\nEmail: noahdyifter@gmail.com\nBaptism: Tekle Tsadiq (Baptized)\nBaptism Date: N/A\nName Day: N/A	2025-07-29 23:35:52.077	2025-08-23 01:40:11.644	+19452179619	noahdyifter@gmail.com	Tekle Tsadiq	t	\N	3	no	\N
2	3	Nathan	Dawit	Yifter	2010-09-26	Male	Son	\N	\N	\N	\N	Original ID: 48478a82-eca4-406d-9666-25fc268c7d28\nPhone: +14698104927\nEmail: nathanyifter@gmail.com\nBaptism: Haile Meskel (Baptized)\nBaptism Date: N/A\nName Day: N/A	2025-07-29 23:35:52.078	2025-08-23 01:40:11.739	+14698104927	nathanyifter@gmail.com	Haile Meskel	t	\N	3	no	\N
10	94	Gebre		Tesfamichael	1963-05-01	Male	Spouse						2025-08-17 14:55:18.02	2025-08-23 01:40:11.871	+12142151360	gebret123@yahoo.com	MM kes Seifu	t	\N	94	no	\N
11	94	Lidia	\N	Gebremedhin	\N	\N	Daughter	\N	\N	\N	\N	\N	2025-08-17 15:10:33.35	2025-08-23 01:40:11.935	+12148037295	\N	Weletesenbet	t	\N	94	no	\N
14	181	Ezra	seged	Yared	2014-04-11	Male	Son						2025-08-18 16:43:51.625	2025-08-23 01:40:11.999	+14699395302	merafehaile@gmail.com	weldemariam	t	\N	181	no	\N
27	205	Teklu	\N	Berhane	\N	male	Spouse	\N	\N	\N	\N	\N	2025-09-07 15:03:49.212	2025-09-07 15:03:49.213	\N	\N	\N	f	\N	205	no	\N
\.


--
-- TOC entry 4206 (class 0 OID 30240)
-- Dependencies: 275
-- Data for Name: donations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.donations (id, stripe_payment_intent_id, stripe_customer_id, amount, currency, donation_type, frequency, payment_method, status, donor_first_name, donor_last_name, donor_email, donor_phone, donor_address, donor_zip_code, metadata, created_at, updated_at) FROM stdin;
19	pi_3S4k1V0QGyCViXXj1wdLY3LP	\N	100.00	usd	one-time	\N	card	pending	Tesfom	Gebrehiwot	phone_14439348109@phone-signin.local	+14439348109	3957 Sidney ln	75126	{"purpose": "membership_due", "payment_method": "card"}	2025-09-07 14:56:57.946+00	2025-09-07 14:56:57.946+00
20	pi_3S5HcF1Y4tq8nVje1mN05gbg	\N	1.00	usd	one-time	\N	card	succeeded	Dawit	Yifter	dawityifter@gmail.com	+14699078229	12540 pond cypress ln	75035	{"purpose": "donation", "payment_method": "card"}	2025-09-09 02:49:07.469+00	2025-09-09 02:49:09.801+00
\.


--
-- TOC entry 4208 (class 0 OID 42470)
-- Dependencies: 277
-- Data for Name: groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.groups (id, name, description, is_active, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4210 (class 0 OID 42480)
-- Dependencies: 279
-- Data for Name: member_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_groups (id, member_id, group_id, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4196 (class 0 OID 17357)
-- Dependencies: 265
-- Data for Name: member_payments_2024; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.member_payments_2024 (id, member_id, member_name, spouse_name, phone_1, phone_2, year, payment_method, monthly_payment, total_amount_due, january, february, march, april, may, june, july, august, september, october, november, december, total_collected, balance_due, paid_up_to_date, number_of_household, created_at, updated_at) FROM stdin;
1	\N	Abeba Abraham Reda	Taddesse Midekisa			2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
2	\N	Abeba Dessalegn	Yemane Tewelde			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
3	\N	Abeba Tesfay	Yonnas Bekele			2024	Check	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	0.00	0.00	0.00	270.00	-90.00	9/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
4	\N	Abeba Woldu				2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
5	\N	Abiy Makonnen				2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
6	\N	Abraham G/medhin			469-623-0120	2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
7	\N	Abraham Takle Haile DN	Samrawit Derbew			2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
8	\N	Abraham Woldegabrale			254-229-3622	2024	Paypal	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	0.00	0.00	0.00	300.00	-300.00	6/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
9	\N	Abrehet Ghebru		214-859-3303		2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	0.00	0.00	0.00	0.00	80.00	-40.00	8/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
10	\N	Abrha Kahsay	Zufan Lema	512-566-9881	512-734-7426	2024	Cash	25.00	300.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
11	\N	Abrha Tesfay	Tirhas Gebremariam	469-774-0370		2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
12	\N	Addisu Dagnehegn	Tarikua Tesfamariam			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
13	\N	Adonias Tadesse DN				2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
14	\N	Afework Angesom	Letay G/Kristos			2024	Cash	200.00	2400.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
15	\N	AKLILU KIDANE				2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
16	\N	Alem Belay Gesesse	Tsehai Tesema	979-213-0808		2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
17	\N	Alem Tedla			469-556-9123	2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
18	\N	Alemseged Kassa	Frewoini W.Giorgis	214-732-3884		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	600.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
19	\N	Alex Abrha	Samret			2024	$40	480.00	0.00	0.00	0.00	0.00	0.00	40.00	0.00	0.00	0.00	0.00	0.00	0.00	40.00	-440.00	6.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
20	\N	Alex Hadera				2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
21	\N	Almaz Ertro	Yohannes Gebreselasie	404-543-0559		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	0.00	0.00	0.00	300.00	-300.00	6/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
22	\N	Almaz Gebremariam			972-809-3269	2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
23	\N	Aman Fikadu	Roman	206-234-4888		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
24	\N	Aman Hagos	Yodit Kassa	469-653-9888	208-353-2225	2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	180.00	-180.00	6/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
25	\N	Amanuel Gidey	Meaza Endrias			2024	$30	360.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	360.00	0.00	12.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
26	\N	Amanuel Kahisay Gebru	470-546-0196		2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
27	\N	Amanuel Negussie Kihshen	Eyerus ageta			2024	$30	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
28	\N	Amarech Aregawi				2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
29	\N	Amelework Negash	Hadera G.tsadik			2024	Cash	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	0.00	0.00	0.00	0.00	800.00	-400.00	8/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
30	\N	Amha Araya	Senait Gebreslassie	207-408-2479		2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
31	\N	Amleset tsehaye				2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
32	\N	Ananya B/Medhin	Senait M.			2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
33	\N	Andom Berhe	Helina Gebrekidan	720-216-7616		2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
34	\N	Arefayne Guangul			945-225-0443	2024	Dir Dep	50.00	600.00	0.00	60.00	0.00	50.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	110.00	-490.00	4/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
35	\N	Aregay Tesfay				2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
36	\N	Ariam Habtemariam				2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
37	\N	Arsema Kiros				2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
38	\N	Asefa Birhane	Almaz G.Yohannes			2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	240.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
39	\N	Aselefech Abebe				2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
40	\N	Ashenafi Gebremichael	Brkti Tedla			2024	$50	600.00	0.00	0.00	0.00	0.00	0.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	200.00	-400.00	9.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
41	\N	Assefash Berhe				2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
42	\N	Astede Mariam				2024	$50	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
43	\N	Aster W/Gebrael			214-256-0651	2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
44	\N	Asther Asmelash (Tekabo)			2149388716	2024	Cash	170.00	2040.00	170.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	170.00	-1870.00	1/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
45	\N	Atsede Gebrehiwot			323-633-5685	2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	0.00	0.00	0.00	0.00	80.00	-40.00	8/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
46	\N	Atsede Girmay	Tekalegn Mesfin	469-350-0293		2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	100.00	-140.00	5/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
47	\N	Atsede Hezkias				2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	50.00	-70.00	5/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
48	\N	Atsede Wolde				2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
49	\N	Awote G/Silass	Eden Gebru	408-775-2431		2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
50	\N	Ayalenesh Kassa				2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
51	\N	Ayalnesh Atnaf				2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
52	\N	Azeb Abera			972-370-4850	2024	Cash	30.00	360.00	30.00	30.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	90.00	-270.00	4/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
53	\N	Azeb Tesfay				2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
54	\N	Bekele Tekle	Emebate Dubale			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
55	\N	Belay Gesessew	Timnit Teka	214-558-4405		2024	Cash	40.00	480.00	40.00	40.00	40.00	40.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	160.00	-320.00	5/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
56	\N	Berhane Demoz	Abeba Mesfin			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
57	\N	Berhane Kahsay				2024	$30	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
58	\N	Berhanemarkos Tadesse				2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
59	\N	Berhanemeskel Baraki	kewanit			2024	$30	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
60	\N	Berihu Araya Gidey	Akeza Ayele	214-500-4823		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
61	\N	Berihun Araya	Akeza Lema			2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
62	\N	Beyou Yohanes	Teklu Berhane	469-360-8918		2024	Cash	30.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
63	\N	Bilen Bezabeh			469-363-9651	2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
64	\N	Birhane Kahsay			972-730-0772	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
65	\N	Birhane Mebratu	Martha Tadesse	469-233-4703		2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
66	\N	Biruk Gebru	Selam Asgedom	585-287-0931		2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
67	\N	Bisrat Meles	Tigist Kahsaye	214-845-2359		2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	120.00	-240.00	5/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
68	\N	Bitewat Aynalem				2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	240.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
69	\N	Bitsti Abraha				2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
70	\N	Bizen Berhane	Desta			2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
71	\N	Brhane Gebru			525-355-5990	2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
72	\N	Bsrat Mezgebe	Senay Redda	718-775-8634		2024	Cash	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	0.00	0.00	0.00	900.00	-300.00	9/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
73	\N	Chanyalew Girmay	Genet Teklu	214-404-7890		2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	180.00	-180.00	6/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
74	\N	Christiyana Bruk			214-998-0042	2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
75	\N	Daniel Kidane	Eden W/Abzgi	617-285-3106		2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	360.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
76	\N	Daniel Kiros Fanta				2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	0.00	0.00	0.00	0.00	160.00	-80.00	8/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
77	\N	Daniel Sahle	Atikilt Kassa			2024	Cash	40.00	480.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
78	\N	Dawit Abraham	Mebrat Eyasu			2024	Paypal	400.00	4800.00	400.00	400.00	400.00	400.00	400.00	400.00	400.00	400.00	0.00	0.00	0.00	0.00	3200.00	-1600.00	8/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
79	\N	Dawit Fshaye	Brhan Drar			2024	$50	600.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	250.00	-350.00	5.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
80	\N	Dawit G/Yohanis				2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
81	\N	Dawit Gebru			2024	2024	$10	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12.00	1	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
82	\N	Dawit Kidane	Meareg Kidanemariam	469-878-5963		2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	240.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
83	\N	Dawit Tekle	Edom G. Amanuel	972-330-7411		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
84	\N	Dawit Yifter	Meaza G Abera			2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
85	\N	Dawit Zeweldi	Sara Tekle	860-336-8010		2024	Cash	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	0.00	0.00	0.00	0.00	0.00	700.00	-500.00	7/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
86	\N	Degef Kassahun			469-939-2174	2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
87	\N	Degu Kassa			940-634-7173	2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
88	\N	Demelash Debebe	Azeb Amsalu			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
89	\N	Desta Ashebir Hailemariam	Fana Negash	281-755-8289		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
90	\N	Desta Legesse	Kiros Weletehanes			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
91	\N	Desta Negash Zelelew	Eyerusalem Taddesse			2024	$50	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
92	\N	Dirar Aregawi	Elieni Shishay	510-356-8730		2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
93	\N	Eden A Kassa			214-679-6610	2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	240.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
94	\N	Elias Fekresellasie	Freweyni Tesfa	469-226-2926	214-566-3500	2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
95	\N	Elias Gebrehiwot			2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
96	\N	Elana Kidane	Yodit Sergute Gerel			2024	$100	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
97	\N	Elias Gebrehiwot	Adey Gebregorgis	617-417-8073		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
98	\N	Elsabeth Ayalew Shiferaw			2024	2024	$100	1200.00	100.00	200.00	200.00	100.00	200.00	100.00	100.00	100.00	100.00	0.00	0.00	0.00	1200.00	0.00	9.00	1	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
99	\N	Emebet Getachew			2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
100	\N	Emebet Kidane			469-525-3081	2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
101	\N	Emmanuel Gebrekirstos	Rahiwa	361-220-8499		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	200.00	-400.00	4/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
102	\N	Endalkachew Tulu	Alem Lemma			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
103	\N	Enderias Petros	Tew			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
104	\N	Ephrem W/Giorgis	Mergea G/silass			2024	Cash	15.00	180.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
105	\N	Esayas Tadesse	Mehret Yohannes			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
106	\N	Eshetu Berhe	Genet Hagos			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
107	\N	Etsegenet Manaye Shiferaw			2024	2024	$100	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
108	\N	Eyasu Seged Hagos			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
109	\N	Eyerus Hagos	Eyob Woldeysus			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
110	\N	Eyerusalem Tadesse			2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
111	\N	Eyerusalem Yohanes			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
112	\N	Fetlework Tesfay				2024	$360	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
113	\N	Fetsum Brhan Biadgelgne	Aster Abraha	469-867-5429		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	0.00	400.00	-200.00	8/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
114	\N	Fikerte Asfaw			2024	2024	$50	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
115	\N	Frehiwot Berhe			2024	2024	$15	180.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
116	\N	Freweini Girmay			2024	2024	$10	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12.00	1	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
117	\N	Freweini Tesfa				2024	$300	0.00	0.00	0.00	0.00	0.00	0.00	50.00	50.00	50.00	50.00	0.00	0.00	200.00	-100.00	10.00	1.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
118	\N	Freweyni Desta			801-688-2141	2024	Card	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
119	\N	Freweyni Woldu	Firehaymanot	469-230-6671		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
120	\N	Friew Abraha	Helina Aregawi	619-309-5601	702-827-8331	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
121	\N	Friew Zerihun	Meaza			2024	$30	360.00	0.00	0.00	0.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	30.00	-330.00	4.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
122	\N	G/Meskel Tesfamichael	Almaz Tesfay	469-939-3483	214-215-1360	2024	Zelle	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	0.00	400.00	-200.00	8/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
123	\N	G/Selasie G/Meskel			2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
124	\N	Gebre Habtu	Genet Habtu			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
125	\N	Gebreegziabher Redda				2024	$180	0.00	0.00	0.00	20.00	20.00	20.00	20.00	0.00	0.00	0.00	0.00	0.00	80.00	-100.00	7.00	1.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
126	\N	Gebrehewot Gebremariam			585-485-9628	2024	Cash	42.00	500.00	42.00	42.00	42.00	42.00	42.00	42.00	42.00	42.00	42.00	42.00	40.00	40.00	500.00	-0.04	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
127	\N	Gebrehiwot File	Hadas Tsehaye			2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
128	\N	Gebrehiwot Hinsta	Zafu Tadesse			2024	Cash	15.00	180.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
129	\N	Gebremedhin Araya	Simert Nerai	469-212-5884		2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
130	\N	Gebreselassie Gebreyesus			469-258-5138	2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
131	\N	Genanaw Tesema	Mekdes Birhanu			2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
132	\N	Genet and Gebre Habtu			2024	2024	$25	300.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
133	\N	Genet Beyene			2024	2024	$30	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
134	\N	Genet Gebreamlak	Solomon Ayalew	214-552-3120		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
135	\N	Genet Hailu				2024	$600	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
136	\N	Genet Tesfay			469-544-7340	2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
137	\N	Genet Yetebarek	Haile Zeleke			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
138	\N	Genet Yihum	Wubshet Ayalew			2024	Cash	200.00	2400.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
139	\N	Gerawork Zeyohanes			2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
140	\N	Gessesew Hagos	Letebrhan			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
141	\N	Getachew Siyum	Elsa Girmay	832-232-2256		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
142	\N	Gezahegn Abay	Selamawit Berhe - Direct Payment	469-321-7935		2024	Dir Dep	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
143	\N	Gezayi Mana	Helen Amare	972-978-8395		2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
144	\N	Ghebreghiorgis Ghebrekidan			214-281-0985	2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
145	\N	Gidena Mehari	Angesome Mehari	214-962-7974		2024	Cash	40.00	480.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
146	\N	Girmay Hagos Gebremicael	Haymanot G/Hiwot	469-882-8692		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
147	\N	Gnbework Fanta	Hailemariam kidanu			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
148	\N	Goitiom Abreha	Lemlem Ali			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
149	\N	Goitiom Tewolde			240-280-9837	2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
150	\N	Goitom Atsbha	Atsede Haftamu	240-289-3233		2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
151	\N	Habtom Kidanemariam			469-203-0195	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
152	\N	Hadas Berehe			2024	2024	$50	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
153	\N	Hadera Abay	Genet			2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
154	\N	Hadera Abera			2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
155	\N	Hadera Gidey			682-221-2646	2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	180.00	-180.00	6/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
156	\N	Hadera Medhane weldegebriel			214-382-8574	2024	cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
157	\N	Hailay Woldu		214-779-3331		2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
158	\N	Haile Fanta	/Abeba Hailu	502-718-3529		2024	Cash	20.00	240.00	0.00	0.00	0.00	20.00	20.00	20.00	20.00	20.00	0.00	0.00	0.00	0.00	100.00	-140.00	8/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
159	\N	Haile Gebru			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
160	\N	Haileleul Haileyesus			682-365-3056	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
161	\N	Hailu Egigu	Enanu			2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
162	\N	Hailu Woldetenday DN			2024	2024	$50	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
163	\N	Halefom Gebreset			737-247-5259	2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
164	\N	Hana Eyasu			972-693-6631	2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
165	\N	Hana Gebrewahid			2024	2024	$10	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
166	\N	Hana Leikun			2024	2024	$30	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
167	\N	Haregu Ayalew			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
168	\N	Heaven Hagos			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
169	\N	Helen Tekelu			2024	2024	$100	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
170	\N	Helen Woldu			469-279-8246	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
171	\N	Helen Yohanis	Daniel Hailu DN			2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
172	\N	Henok Woldemariam	Fana Woldearegai	214-783-9780		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
173	\N	Hewan Haileslase			512-521-6281	2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	0.00	0.00	0.00	0.00	160.00	-80.00	8/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
174	\N	Hezekias Tadesse			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
175	\N	Hintsa T.Gebremedhin	Bsrat T.Gebresilasie			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
176	\N	Hizbawit Tesfay			214-998-0042	2024	Cash	5.00	60.00	5.00	5.00	5.00	5.00	5.00	5.00	5.00	5.00	0.00	0.00	0.00	0.00	40.00	-20.00	08|01/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
177	\N	Israel Alemayehu	Ruth Tadesse	651-399-9048		2024	Cash	40.00	480.00	40.00	40.00	40.00	40.00	40.00	40.00	40.00	0.00	0.00	0.00	0.00	0.00	280.00	-200.00	7/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
178	\N	Jerusalem Admasu			2024	2024	$50	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
179	\N	Joe and Sofia	Tsedale Mariam			2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
180	\N	Kalayou Gebregziabher	Alem Asres	214-757-9142		2024	paypal	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
181	\N	Kesete G/Silassi	Alem Desta	469-427-7877		2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
182	\N	Kibom Kidanu	Letebrhan Nuguse	435-557-6712		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
183	\N	Kibrom Desta	Brikti Nigus	972-357-0222		2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	240.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
184	\N	Kibrom Kidanu	Rahwa Kibrom			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
185	\N	Kidist Tsehaie Mariam			2024	2024	$10	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	40.00	150.00	30.00	12.00	1	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
186	\N	Kidus Dade Mengesha	Selam Chala	469-358-5053		2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
187	\N	Kidus Yohanes	Liya Solomon	214-636-2754		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
188	\N	Kindeya N.Techan	Elsa	214-601-4871		2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
189	\N	Kiros Berhe	Beletu			2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
190	\N	Kiros Gebregewergis	Rewina Girmay	614-214-1695		2024	Cash	200.00	2400.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	0.00	0.00	0.00	1800.00	-600.00	9/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
191	\N	Kiros Gebriel	Tiruwork Abraha			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
192	\N	Kiros Nega			720-938-5069	2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
193	\N	Leake Wuteta	Helen Kinfe	214-546-2054		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
194	\N	Lemlem Abate			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
195	\N	Lemlem Berhehe Araya			2024	2024	$5	60.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
196	\N	Lemlem Kassa			2024	2024	$100	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
197	\N	Lemlem Semere			469-992-0935	2024	Cash	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	0.00	0.00	0.00	900.00	-300.00	9/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
198	\N	Letay Negash			214-336-6124	2024	Cash	10.00	120.00	10.00	10.00	10.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	30.00	-90.00	3/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
199	\N	Liya Berhe			2024	2024	$100	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12.00	1	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
200	\N	Liya Hagos			2024	2024	$100	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12.00	1	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
201	\N	Lulit Kidane			2024	2024	$200	2400.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
202	\N	Luul Teare			206-880-6657	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
203	\N	Mahlet Yohannes			469-951-4264	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
204	\N	Martha Berehe	Tsegazeab			2024	Dir Dep	500.00	6000.00	500.00	500.00	500.00	500.00	500.00	500.00	500.00	500.00	500.00	150.00	0.00	0.00	4650.00	-1350.00	10/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
205	\N	Meaza Berhe			16071905	2024	$380	4560.00	380.00	380.00	380.00	380.00	380.00	380.00	380.00	380.00	380.00	380.00	0.00	0.00	3800.00	-760.00	10.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
206	\N	Martha Gebru	Arefaine Tesfay	469-344-5581		2024	Cash	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
207	\N	Mathias Abebe	Seble Girma	469-556-5725		2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
208	\N	Meareg Yalew	Yaineabeba W/zgina			2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	0.00	0.00	0.00	90.00	-30.00	9/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
209	\N	Meaza Fanta Gezahgn			214-213-1874	2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	0.00	0.00	0.00	180.00	-60.00	9/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
210	\N	Mebrhatu Tselela	Selamawit			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
211	\N	Mebrhit Gebremariam	Kibrom Kidane	509-690-0463		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
212	\N	Mehari Gebremariam			214-566-0874	2024	Card	13.00	150.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	450.00	300.00	9/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
213	\N	Mehret ab Girmay				2024	$360	0.00	0.00	0.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	30.00	-330.00	1.00	1.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
214	\N	Mehret Abraham			214-603-6295	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
215	\N	Mekdes Woldu G/Mariam	Abebe Baraki	972-277-7448		2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
216	\N	Mekonnen G.Kidane	Selome Berhe			2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
217	\N	Mengistu Weldeagegnehu			2024	2024	$0	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
218	\N	Mengistu Yeebyo Alemayehu	Yezichalem Tebeje			2024	Check	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	500.00	-100.00	10/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
219	\N	Mengstab Hagos	Akberet Tekle	720-935-7619		2024	Cash	40.00	480.00	40.00	40.00	40.00	40.00	40.00	40.00	0.00	0.00	0.00	0.00	0.00	0.00	240.00	-240.00	6/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
220	\N	Meraf Haile	Yared			2024	Cash	264.00	3171.36	264.00	264.00	264.00	264.00	264.00	264.00	264.00	264.00	266.56	0.00	0.00	0.00	2378.56	-792.80	9/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
221	\N	Meressa W. Michael			2024	2024	$20	240.00	10.00	10.00	10.00	10.00	10.00	10.00	0.00	0.00	0.00	0.00	0.00	0.00	60.00	-180.00	6.00	1	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
222	\N	Merhawi G/Mariam	Zelalem Tegaw	404-650-8093		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
223	\N	Meseret Tadesse Asmerash			2024	2024	$0	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
224	\N	Mesfin Weldeyes			2024	2024	$0	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
225	\N	Meskerem Eshetie	Yenenesh			2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
226	\N	Meuze Beyadegneign Tedla			202-971-0219	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
227	\N	Mhreteab Hailemariam	Ruta Fitsum Gebreyohannes	323-384-8389		2024	card	0.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
228	\N	Michael Bokuretsion				2024	$600.00	0.00	0.00	0.00	0.00	0.00	60.00	60.00	60.00	0.00	0.00	0.00	0.00	180.00	-420.00	3.00	1.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
229	\N	Michael Ebuy	Tsedal			2024	$100	1200.00	100.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	100.00	-1100.00	1.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
230	\N	Michael Kidane G/giyorgis			214-566-2565	2024	Cash	20.00	200.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	0.00	0.00	200.00	0.00	10/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
231	\N	Michael Meshesha	Yewubdar Kelifa			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
232	\N	Minassie Beyene	Rebecca Tesfaye			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
233	\N	Miraf Yemaneh			2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
234	\N	Mirtnesh Kidanemariam Leake			469-650-0771	2024	Card	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	65.00	50.00	50.00	0.00	0.00	515.00	-85.00	10/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
235	\N	Misgan	Aklil Hagos			2024	Cash	200.00	2400.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
236	\N	Misghna Welegerima	Abynesh Brhane	214-881-5409		2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	80.00	-160.00	4/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
237	\N	Mulu G/Egzeabher			469-554-3506	2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	0.00	0.00	0.00	0.00	240.00	-120.00	8/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
238	\N	Mulubirhan Zerihun	Amanuel Bahita	858-298-1481		2024	Cash	50.00	600.00	50.00	50.00	50.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	150.00	-450.00	3/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
239	\N	Mulugeta W.Hiwot	Dehab Mahimud	214-315-5097		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
240	\N	Muluwork Mesfin Desta	Brook Areguy	432-271-6760		2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
241	\N	NAHIMIA ALCHAYE	KIDANE TESEN			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
242	\N	Nahom Hagos	Liya Hagos			2024	$100	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
243	\N	Nahom Assefa			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
244	\N	Nathnael Weldegiorgis				2024	$360.00	0.00	0.00	0.00	0.00	0.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	30.00	-330.00	1.00	1.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
245	\N	Neachi G/Michael			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
246	\N	Negash Hadgu	Yirgalem Teklehaimanot	717-344-1276		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	500.00	-100.00	10/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
247	\N	Nekahiwat Tsehaye	Alem			2024	Cash	15.00	180.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
248	\N	Rahel Kidanemariam			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
249	\N	Rahwa Mebrahtom	Angesom Berhane	206-355-7037		2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
250	\N	Rbka Mesele			214-531-5963	2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	360.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
251	\N	Rehaset Kibreab			510-860-8886	2024	Cash	16.00	192.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
252	\N	Robel Feseha	Birhan G/medihin	469-418-6677		2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
253	\N	Robel Feseha	Birhan G/medihin			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
254	\N	Robel Tekle	Milen Adam			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
255	\N	Ruth Berhe	Yrgalem Kassa			2024	Cash	25.00	300.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
256	\N	Sabrina Yasin			312-593-7950	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
257	\N	Samirawit Birhanu			940-297-5969	2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
258	\N	Sammy Bezabeh			972-603-8286	2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
259	\N	Samuel Araya G/Mariam			404-397-2611	2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
260	\N	Samuel Algeda				2024	$60.00	5.00	5.00	5.00	2.00	5.00	5.00	5.00	0.00	0.00	0.00	0.00	0.00	32.00	-28.00	7.00	1.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
261	\N	Samuel woldemariam			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
262	\N	Sandra Agarratt	TC Webb	917-449-7632		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
263	\N	Sara (saba) Mesfin			404-454-7635	2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	0.00	0.00	100.00	-20.00	10/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
264	\N	Sara Fissaha			214-400-3901	2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
265	\N	Seblewengel Seyoum			2024	2024	$50	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
266	\N	Sebsibie W.semayat	Meselech Y.			2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
267	\N	Segenet Zeratsion			469-855-5138	2024	Cash	10.00	120.00	10.00	10.00	10.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	30.00	-90.00	3/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
268	\N	Selam Mesfin	Samrawit Kidane	972-408-5869		2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	30.00	360.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
269	\N	Selamawit Hagos			469-951-0834	2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
270	\N	Selamawit Hanamariam			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
271	\N	Selemon Kahaso	Kidist Abeb	408-677-1983		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
272	\N	Semere Berehe	Tiruwork Hadgay	720-841-9309		2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
273	\N	Semere Desta Belay			469-416-6592	2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
274	\N	Semere Tadesse Belay		469-416-6592		2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	1200.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
275	\N	Silesh Eshate	Yedidya Rede			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
276	\N	SIMON SEBHAT	Eden Tekle	703-340-7506		2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
277	\N	Simon Hagos			2024	2024	$100	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
278	\N	Selam Berhe & Gezahgne			2024	2024	$300	3600.00	300.00	300.00	300.00	300.00	300.00	300.00	300.00	300.00	300.00	150.00	0.00	0.00	2850.00	-750.00	10.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
279	\N	Sisay G. Giorgis Tiku	Sabela Wessen	469-268-5331	214-734-8902	2024	Cash	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	0.00	0.00	1000.00	-200.00	10/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
280	\N	Sofi Emiru			2024	2024	$20	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	240.00	0.00	12.00	3	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
281	\N	Solomon Asefa	Ejigayoh Bedada			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
282	\N	Solomon Assefa Berhe			2024	2024	$20	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
283	\N	Solomon GebremMedhin	Medhin Gebremariam	469-396-2012		2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
284	\N	Solomon Gebresilasie			206-751-7952	2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	600.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
285	\N	Solomon Melkamu	Meselech W. M			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
286	\N	Solomon Tesfaye	Samrawit Kidane	469-671-1748	832-233-9076	2024	solomontesw@gmail.com	50.00	600.00	50.00	50.00	50.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	150.00	-450.00	3/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
287	\N	Solyana Gebrewubet			2024	2024	$30	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
288	\N	Sophia Zerihun	Bruk Tilahun			2024	Paypal	150.00	1800.00	150.00	150.00	150.00	150.00	150.00	150.00	150.00	150.00	150.00	0.00	0.00	0.00	1350.00	-450.00	9/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
289	\N	Tadele Gebre	Yergalem			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
290	\N	Tadele Kiros Zegeye			2024	2024	$10	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
291	\N	Tadele Nega	Bethlehem Haile			2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	600.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
292	\N	Tadelech G/Michael			2024	2024	$10	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
293	\N	Tadesse Araya	(Abo Keshi)			2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
294	\N	Tadesse G.Hiwot	Fiereweini			2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
295	\N	Tadesse Kidane	Hiwot			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
296	\N	Tafesae Bahita	Likea Segede			2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
297	\N	Tedla Aidengitu			2024	2024	$10	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
298	\N	Tedla Fikre	Mulu kidane			2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
299	\N	Tigist Fetsum	Ermias			2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
300	\N	Tilahun Abayu			2024	2024	$15	180.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
301	\N	Tikabo Gebregiorgis	Nigisti			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	12.00	2	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
302	\N	Tilahun Arefaine Tedla			214-546-8437	2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
303	\N	Timnit Alemayoh			214-931-2570	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
304	\N	Tirhas Gebremichael Negash			720-400-2017	2024	Cash	20.00	240.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
305	\N	Tirhas Gebresilassie	Goitom Habtesion	214-498-2834		2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
306	\N	Tiruwork Woldeyohanes			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
307	\N	Tsegaye Tadesse			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
308	\N	Tsegazeab Keleom			202-867-7246	2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
309	\N	Tsege Mariam	Yeshi Getachew			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
310	\N	Tsigabu Weldekidan	Fereweini	214-562-4173		2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
311	\N	Weletemariam			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
312	\N	Wobit Mahari			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
313	\N	Woiny Teka			2147017192	2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
314	\N	Wolday Nerayo	Yodit Tesfahunegn	469-602-8916		2024	Cash	10.00	120.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
315	\N	Wondimagegn Tekleab			489-519-5848	2024	Cash	30.00	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
316	\N	Woynishet Tesema			214-560-7261	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
317	\N	Yakob Gebrekidan	Rahel Segad	469-450-4673	469-774-4937	2024	Cash	50.00	600.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
318	\N	Yalem G. Selassie			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
319	\N	Yared Berhe	Mimi Kidane			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
320	\N	Yared W/Gebriel	Kelebet Yesunh	469-544-0174		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
321	\N	Yemane Weldemikael	Mulu Berhane	469-684-8204		2024	Cash	10.00	120.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	10.00	120.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
322	\N	Yemane Yohanns				2024	$480	0.00	0.00	0.00	0.00	0.00	40.00	0.00	0.00	0.00	0.00	0.00	0.00	40.00	-440.00	1.00	1.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
323	\N	Yemisrach Girma			214-607-2380	2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
324	\N	Yenenesh	Meskrem Shiferaw			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
325	\N	Yeshi Getachew			214-517-0922	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
326	\N	Yeshi Taire			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
327	\N	Yeshi Zerihun			972-815-8206	2024	Cash	200.00	2400.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	200.00	2400.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
328	\N	Yirgalem H/mariam				2024	$1	200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
329	\N	Yodit Kidane			214-299-3477	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
330	\N	Yohanis Woldegorgis			206-602-4783	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
331	\N	Yohannes Habteselasie			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
332	\N	Yohannes tsigaye			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
333	\N	Yohannes Weldgerima	Fiyori Gebremariam	602-772-1523		2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
334	\N	Yonas Abraham	Kidist Kiros			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
335	\N	Yonas Ayele	Askal Tekletsadik			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
336	\N	Yonas Tekle	Mihret Tekle			2024	Cash	15.00	180.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
337	\N	yordanos keflea			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
338	\N	Zafu Gebreslassie			972-900-2581	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
339	\N	Zafu Girmay Asefaw			2024	2024	$30	360.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
340	\N	Zaid Semu Tesfay			682-203-4208	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
341	\N	Zaidom Kidane	Amleset Kahsay	214-336-0606		2024	Cash	200.00	15.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
342	\N	Zekiros Guangul W. G.			2024	2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
343	\N	Zekiros W.Gebriel	Betewat Ay			2024	Cash	0.00	20.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
344	\N	Zerihum Mamo	Meseret Aweke			2024	Cash	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
345	\N	Zewdi Teklehaymanot Abraha			210-502-9282	2024	Cash	100.00	1200.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
346	\N	Zelalem Woldselassie			2024	2024	$50	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	550.00	-50.00	11.00	1	0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
347	\N	Zimame Kebede(Gezahgn)	Efrem Woldemarkos	214-258-8415		2024	Cash	20.00	240.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	20.00	240.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
348	\N	Zinash Woldeyohannes				2024	$600	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	500.00	-100.00	10.00	1.00		0	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
349	\N	Zufan Assefa			208-613-9634	2024	Cash	30.00	360.00	30.00	30.00	30.00	30.00	30.00	30.00	0.00	0.00	0.00	0.00	0.00	0.00	180.00	-180.00	6/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
350	\N	Haftom Tesfamariam	Gennet Tesfaye	469-987-7155		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
351	\N	Kahsay Gidey	Mikalem Ghebrehans	214-301-7508		2024	Check	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
352	\N	Fikremariam Solomon		469-555-9033		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	1	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
353	\N	Tsige Gebreyesus	Selamawit Berehe	214-235-9836		2024	Paypal	80.00	960.00	80.00	80.00	80.00	80.00	80.00	80.00	80.00	80.00	80.00	80.00	0.00	0.00	0.00	800.00	160	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
354	\N	Mesfin Assefa	Yonas Mulu		469-994-4452	2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
355	\N	Sara Belay	Daniel Solomon	469-255-2019		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
356	\N	Kidane Tesfaye	Tadelech		214-299-9927	2024	Paypal	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
357	\N	Hana Gerezgiher	Mebrahtu	214-793-1952		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
358	\N	Selamawit Gebremariam	Tesfaye Abebe	469-843-3217		2024	Check	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
359	\N	Teklemariam T Tesfay	Tsega W Gebremariam	214-783-5216		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
360	\N	Tsedey Gidey	Amanuel Kidane	469-556-2285		2024	Paypal	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
361	\N	Kalkidan W/Yohannes	Semere Tesfay	817-889-7770		2024	Paypal	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
362	\N	Daniel Kiros Fanta	Mekdes Weldesellase	469-258-5043		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
363	\N	Rahel Ghebre	Samson Araya	469-774-4937		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
364	\N	Yonathan Gidey	Mahi	469-831-7198		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
365	\N	Hirut Tesfaye		469-878-9736		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
366	\N	Rediet Berhe		469-499-8794		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
367	\N	Frewoini Gebremariam	Girmay Tekle			2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
368	\N	Semret Tekle	Solomon Zeru	469-546-6019		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
369	\N	Kidane Tesfay	Helen Girmay	469-869-8999		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
370	\N	Hana Tekle	Woldeab Araya	469-236-0799		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
371	\N	Meseret Araya	Haile Girmay	214-642-0334		2024	Paypal	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
372	\N	Rahel Girmay	Yemane Haile	469-867-9393		2024	Zelle	100.00	1200.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	100.00	1200.00	0.00	12/1/24	2	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
373	\N	Semhal Haile	Samuel Araya	469-774-4937		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
374	\N	Hirut Girmay		469-878-9736		2024	Cash	50.00	600.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	50.00	0.00	0.00	0.00	500.00	100	10	2025-07-30 05:03:37.624+00	2025-07-30 05:03:37.624+00
\.


--
-- TOC entry 4200 (class 0 OID 24425)
-- Dependencies: 269
-- Data for Name: members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.members (id, firebase_uid, first_name, middle_name, last_name, email, phone_number, date_of_birth, gender, baptism_name, repentance_father, household_size, street_line1, apartment_no, city, state, postal_code, country, emergency_contact_name, emergency_contact_phone, date_joined_parish, spouse_name, family_id, role, is_active, registration_status, created_at, updated_at, interested_in_serving, yearly_pledge, is_welcomed, welcomed_at, welcomed_by, marital_status, is_imported) FROM stdin;
159	yfBqOUTZJba3rXH1ycKpcHQm8UJ2	Atsede	\N	Gebrehiwot	phone_13236335685@phone-signin.local	+13236335685	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	159	member	t	pending	2025-08-17 15:03:13.416	2025-08-28 03:01:33.804	maybe	120.00	f	\N	\N	\N	f
160	\N	Embet	\N	Kebede	phone_12146038028@phone-signin.local	+12146038028	\N	female	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	160	member	t	pending	2025-08-17 15:14:10.795	2025-08-19 02:32:45.544	maybe	\N	t	2025-08-19 02:32:45.544+00	70	\N	f
3	bbtf0bla84RjHRqS09IOZgNk67b2	Dawit	\N	Yifter	dawityifter@gmail.com	+14699078229	1974-06-26	male	Habte Menfes Kidus	\N	1	12540 pond cypress ln	\N	Frisco	TX	75035	United States	\N	\N	2007-06-26	Meaza G Abera	\N	admin	t	pending	2025-07-29 23:35:51.93	2025-08-23 16:18:55.375	maybe	1200.00	t	2025-08-17 01:44:17.635595+00	3	married	f
187	\N	Abraham	\N	G/medhin	\N	+14696230120	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:20.447	2025-08-28 03:01:20.447	maybe	\N	f	\N	\N	\N	t
188	\N	Abraham	\N	Woldegabrale	\N	+12542293622	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:20.571	2025-08-28 03:01:20.571	maybe	\N	f	\N	\N	\N	t
189	\N	Abrehet	\N	Ghebru	\N	+12148593303	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:20.642	2025-08-28 03:01:20.642	maybe	\N	f	\N	\N	\N	t
190	\N	Alem	Belay	Gesesse	\N	+19792130808	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Tsehai  Tesema	\N	member	t	pending	2025-08-28 03:01:20.714	2025-08-28 03:01:20.714	maybe	\N	f	\N	\N	\N	t
191	\N	Alem	\N	Tedla	\N	+14695569123	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:20.787	2025-08-28 03:01:20.787	maybe	\N	f	\N	\N	\N	t
192	\N	Alemseged	\N	Kassa	\N	+12147323884	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Frewoini  W.Giorgis	\N	member	t	pending	2025-08-28 03:01:20.858	2025-08-28 03:01:20.858	maybe	\N	f	\N	\N	\N	t
193	\N	Aman	\N	Fikadu	\N	+12062344888	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Roman	\N	member	t	pending	2025-08-28 03:01:20.93	2025-08-28 03:01:20.93	maybe	\N	f	\N	\N	\N	t
194	\N	Aman	\N	Hagos	\N	+14696539888	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Yodit  Kassa	\N	member	t	pending	2025-08-28 03:01:21.001	2025-08-28 03:01:21.001	maybe	\N	f	\N	\N	\N	t
195	\N	Amanuel	Kahisay	Gebru	\N	+14705460196	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:21.075	2025-08-28 03:01:21.075	maybe	\N	f	\N	\N	\N	t
196	\N	Amha	\N	Araya	\N	+12074082479	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Senait  Gebreslassie	\N	member	t	pending	2025-08-28 03:01:21.146	2025-08-28 03:01:21.146	maybe	\N	f	\N	\N	\N	t
197	\N	Arefayne	\N	Guangul	\N	+19452250443	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:21.218	2025-08-28 03:01:21.218	maybe	\N	f	\N	\N	\N	t
198	\N	Aster	\N	W/Gebrael	\N	+12142560651	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:21.292	2025-08-28 03:01:21.292	maybe	\N	f	\N	\N	\N	t
199	\N	Asther	Asmelash	(Tekabo)	\N	+12149388716	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:21.364	2025-08-28 03:01:21.364	maybe	\N	f	\N	\N	\N	t
200	\N	Atsede	\N	Girmay	\N	+14693500293	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Tekalegn  Mesfin	\N	member	t	pending	2025-08-28 03:01:21.433	2025-08-28 03:01:21.433	maybe	\N	f	\N	\N	\N	t
201	\N	Awote	\N	G/Silass	\N	+14087752431	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Eden  Gebru	\N	member	t	pending	2025-08-28 03:01:21.506	2025-08-28 03:01:21.506	maybe	\N	f	\N	\N	\N	t
202	\N	Azeb	\N	Abera	\N	+19723704850	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:21.577	2025-08-28 03:01:21.577	maybe	\N	f	\N	\N	\N	t
203	\N	Belay	\N	Gesessew	\N	+12145584405	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Timnit  Teka	\N	member	t	pending	2025-08-28 03:01:21.648	2025-08-28 03:01:21.648	maybe	\N	f	\N	\N	\N	t
204	\N	Berihu	Araya	Gidey	\N	+12145004823	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Akeza  Ayele	\N	member	t	pending	2025-08-28 03:01:21.722	2025-08-28 03:01:21.722	maybe	\N	f	\N	\N	\N	t
206	\N	Bilen	\N	Bezabeh	\N	+14693639651	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:21.866	2025-08-28 03:01:21.866	maybe	\N	f	\N	\N	\N	t
207	\N	Birhane	\N	Kahsay	\N	+19727300772	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:21.937	2025-08-28 03:01:21.937	maybe	\N	f	\N	\N	\N	t
208	\N	Birhane	\N	Mebratu	\N	+14692334703	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Martha  Tadesse	\N	member	t	pending	2025-08-28 03:01:22.009	2025-08-28 03:01:22.009	maybe	\N	f	\N	\N	\N	t
209	\N	Bisrat	\N	Meles	\N	+12148452359	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Tigist  Kahsaye	\N	member	t	pending	2025-08-28 03:01:22.08	2025-08-28 03:01:22.08	maybe	\N	f	\N	\N	\N	t
210	\N	Brhane	\N	Gebru	\N	+15253555990	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:22.189	2025-08-28 03:01:22.189	maybe	\N	f	\N	\N	\N	t
211	\N	Chanyalew	\N	Girmay	\N	+12144047890	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Genet  Teklu	\N	member	t	pending	2025-08-28 03:01:22.27	2025-08-28 03:01:22.27	maybe	\N	f	\N	\N	\N	t
212	\N	Christiyana	\N	Bruk	\N	+12149980042	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:22.405	2025-08-28 03:01:22.405	maybe	\N	f	\N	\N	\N	t
213	\N	Daniel	\N	Kidane	\N	+16172853106	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Eden  W/Abzgi	\N	member	t	pending	2025-08-28 03:01:22.476	2025-08-28 03:01:22.476	maybe	\N	f	\N	\N	\N	t
214	\N	Dawit	\N	Kidane	\N	+14698785963	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Meareg  Kidanemariam	\N	member	t	pending	2025-08-28 03:01:22.548	2025-08-28 03:01:22.548	maybe	\N	f	\N	\N	\N	t
215	\N	Dawit	\N	Tekle	\N	+19723307411	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Edom G. Amanuel	\N	member	t	pending	2025-08-28 03:01:22.62	2025-08-28 03:01:22.62	maybe	\N	f	\N	\N	\N	t
216	\N	Degu	\N	Kassa	\N	+19406347173	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:22.69	2025-08-28 03:01:22.69	maybe	\N	f	\N	\N	\N	t
217	\N	Desta	Ashebir	Hailemariam	\N	+12817558289	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Fana  Negash	\N	member	t	pending	2025-08-28 03:01:22.762	2025-08-28 03:01:22.762	maybe	\N	f	\N	\N	\N	t
218	\N	Dirar	\N	Aregawi	\N	+15103568730	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Elieni  Shishay	\N	member	t	pending	2025-08-28 03:01:22.835	2025-08-28 03:01:22.835	maybe	\N	f	\N	\N	\N	t
219	\N	Elias	\N	Fekresellasie	\N	+14692262926	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Freweyni  Tesfa	\N	member	t	pending	2025-08-28 03:01:23.209	2025-08-28 03:01:23.209	maybe	\N	f	\N	\N	\N	t
220	\N	Elias	\N	Gebrehiwot	\N	+16174178073	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Adey  Gebregorgis	\N	member	t	pending	2025-08-28 03:01:23.728	2025-08-28 03:01:23.728	maybe	\N	f	\N	\N	\N	t
221	\N	Ellene	\N	Berhe	\N	+12147131851	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Alias	\N	member	t	pending	2025-08-28 03:01:23.867	2025-08-28 03:01:23.867	maybe	\N	f	\N	\N	\N	t
222	\N	Elsa	Girmay	Tesfay	\N	+12145431754	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:23.939	2025-08-28 03:01:23.939	maybe	\N	f	\N	\N	\N	t
223	\N	Emebet	\N	Kidane	\N	+14695253081	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:24.013	2025-08-28 03:01:24.013	maybe	\N	f	\N	\N	\N	t
224	\N	Emmanuel	\N	Gebrekirstos	\N	+13612208499	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Rahiwa	\N	member	t	pending	2025-08-28 03:01:24.091	2025-08-28 03:01:24.091	maybe	\N	f	\N	\N	\N	t
225	\N	Freweyni	\N	Desta	\N	+18016882141	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:24.161	2025-08-28 03:01:24.161	maybe	\N	f	\N	\N	\N	t
226	\N	Friew	\N	Abraha	\N	+16193095601	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Helina  Aregawi	\N	member	t	pending	2025-08-28 03:01:24.234	2025-08-28 03:01:24.234	maybe	\N	f	\N	\N	\N	t
227	\N	Gebrehewot	\N	Gebremariam	\N	+15854859628	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:24.307	2025-08-28 03:01:24.307	maybe	\N	f	\N	\N	\N	t
228	\N	Gebremedhin	\N	Araya	\N	+14692125884	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Simert  Nerai	\N	member	t	pending	2025-08-28 03:01:24.379	2025-08-28 03:01:24.379	maybe	\N	f	\N	\N	\N	t
205	\N	Beyou	\N	Yohanes	\N	+14693608918	\N	\N	\N	\N	1	3501 Napoleon Crt	\N	Plano	TX	75023	USA	\N	\N	\N	Teklu  Berhane	\N	member	t	pending	2025-08-28 03:01:21.795	2025-09-07 15:05:34.27	maybe	360.00	f	\N	\N	married	t
155	\N	Menbere	\N	Mesfin	phone_13128049421@phone-signin.local	+13128049421	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	155	member	t	pending	2025-08-17 13:29:46.161	2025-08-17 13:29:46.235	maybe	\N	f	\N	\N	\N	f
162	\N	Muez	\N	Biadqlign	phone_12029710219@phone-signin.local	+12029710219	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	162	member	t	pending	2025-08-17 15:53:15.155	2025-08-28 03:01:33.962	maybe	0.00	t	2025-08-19 02:32:51.169+00	70	\N	f
163	\N	Semhar	\N	Gebremariam	phone_14693497535@phone-signin.local	+14693497535	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	163	member	t	pending	2025-08-17 15:54:25.959	2025-08-17 15:54:26.036	maybe	\N	f	\N	\N	\N	f
168	\N	Zufan	\N	Sebhat	phone_14694416048@phone-signin.local	+14694416048	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	168	member	f	pending	2025-08-17 16:01:40.609	2025-08-17 16:02:03.673	maybe	\N	f	\N	\N	\N	f
172	\N	Tesfmariam	\N	Beyene	phone_16574100318@phone-signin.local	+16574100318	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	172	member	t	pending	2025-08-17 16:06:39.574	2025-08-17 16:06:39.641	maybe	\N	f	\N	\N	\N	f
173	\N	Daniel	\N	Weldemichael	phone_12083530145@phone-signin.local	+12083530145	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	173	member	t	pending	2025-08-17 16:07:10.261	2025-08-17 16:07:10.335	maybe	\N	f	\N	\N	\N	f
174	\N	Adis	\N	Zewde	phone_14698729132@phone-signin.local	+14698729132	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	174	member	t	pending	2025-08-17 16:07:47.839	2025-08-17 16:07:47.905	maybe	\N	f	\N	\N	\N	f
183	jiU4NScRPLdn27M9cxH9k7mt6Ij2	Dawit	A	Zeweldi	phone_18603368010@phone-signin.local	+18603368010	\N	male	\N	\N	1	920 Chestnut Ct	\N	Murphy	TX	75094	United States	\N	\N	\N	Sara T Gebresilasie 	183	member	t	pending	2025-08-22 02:10:55.171	2025-08-29 03:23:30.96	yes	1200.00	f	\N	\N	Married	f
161	\N	Beletu	\N	Waleliqn	phone_14698103830@phone-signin.local	+14698103830	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	161	member	t	pending	2025-08-17 15:51:35.361	2025-08-19 02:18:41.05	maybe	\N	t	2025-08-19 02:18:41.049+00	70	\N	f
165	\N	Hintsa	\N	Gebremedhin	phone_12146801420@phone-signin.local	+12146801420	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	165	member	t	pending	2025-08-17 15:55:44.282	2025-08-19 02:36:13.624	maybe	\N	t	2025-08-19 02:36:13.623+00	70	\N	f
164	\N	Firezgi	\N	Andom	phone_12145362498@phone-signin.local	+12145362498	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	164	member	t	pending	2025-08-17 15:55:05.936	2025-08-19 02:36:15.076	maybe	\N	t	2025-08-19 02:36:15.076+00	70	\N	f
166	\N	Mekonen	\N	Gebrekidan	phone_14692795669@phone-signin.local	+14692795669	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	166	member	t	pending	2025-08-17 15:58:14.935	2025-08-19 02:36:16.59	maybe	\N	t	2025-08-19 02:36:16.59+00	70	\N	f
167	\N	Selome	\N	Berhe	phone_14698266124@phone-signin.local	+14698266124	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	167	member	t	pending	2025-08-17 15:58:47.06	2025-08-19 02:36:17.911	maybe	\N	t	2025-08-19 02:36:17.911+00	70	\N	f
169	\N	Zena	\N	Belay	phone_14693534802@phone-signin.local	+14693534802	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	169	member	t	pending	2025-08-17 16:03:16.821	2025-08-19 02:36:19.155	maybe	\N	t	2025-08-19 02:36:19.154+00	70	\N	f
170	\N	Zufan	\N	Sebhat	phone_12142575627@phone-signin.local	+12142575627	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	170	member	t	pending	2025-08-17 16:04:05.202	2025-08-19 02:36:20.403	maybe	\N	t	2025-08-19 02:36:20.403+00	70	\N	f
171	\N	Alem	\N	Kahsay	phone_16126013840@phone-signin.local	+16126013840	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	171	member	t	pending	2025-08-17 16:04:43.452	2025-08-19 02:36:22.803	maybe	\N	t	2025-08-19 02:36:22.803+00	70	\N	f
176	\N	Dawit	\N	Kidane	phone_14698785965@phone-signin.local	+14698785965	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	176	member	t	pending	2025-08-17 16:09:11.269	2025-08-19 02:36:28.301	maybe	\N	t	2025-08-19 02:36:28.301+00	70	\N	f
175	\N	Michael	\N	Sebho	phone_19453277231@phone-signin.local	+19453277231	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	175	member	t	pending	2025-08-17 16:08:36.977	2025-08-19 02:36:30.267	maybe	\N	t	2025-08-19 02:36:30.267+00	70	\N	f
154	\N	Eyerusalem	\N	Hafteab	phone_12147725419@phone-signin.local	+12147725419	\N	\N	Weletemichael	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	154	member	t	pending	2025-08-17 13:26:36.345	2025-08-22 00:58:23.098	maybe	\N	t	2025-08-22 00:58:23.097+00	3	\N	f
50	iTlfzLwJhXM7nfUFfWcj8tHnX3L2	Zufan	\N	Ashebir	zufan.ashebir@yahoo.com	+16823953492	1989-12-31	female	Weletesilase	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	relationship	t	pending	2025-08-02 16:37:01.074	2025-08-23 16:14:47.087	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	married	f
47	\N	Azeb	\N	Tesfay	\N	+19724158910	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:00.643	2025-08-02 16:37:00.644	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
229	\N	Gebreselassie	\N	Gebreyesus	\N	+14692585138	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:24.453	2025-08-28 03:01:24.453	maybe	\N	f	\N	\N	\N	t
49	\N	Semhal	\N	Abrham	\N	+19727636253	1989-12-31	female	Lidia	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:00.933	2025-08-02 16:37:00.933	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
230	\N	Genet	\N	Gebreamlak	\N	+12145523120	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Solomon  Ayalew	\N	member	t	pending	2025-08-28 03:01:26.54	2025-08-28 03:01:26.54	maybe	\N	f	\N	\N	\N	t
231	\N	Genet	\N	Tesfay	\N	+14695447340	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:26.609	2025-08-28 03:01:26.609	maybe	\N	f	\N	\N	\N	t
232	\N	Getachew	\N	Siyum	\N	+18322322256	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Elsa  Girmay	\N	member	t	pending	2025-08-28 03:01:26.681	2025-08-28 03:01:26.681	maybe	\N	f	\N	\N	\N	t
233	\N	Gezahegn	\N	Abay	\N	+14693217935	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Selamawit Berhe -	\N	member	t	pending	2025-08-28 03:01:26.753	2025-08-28 03:01:26.753	maybe	\N	f	\N	\N	\N	t
234	\N	Gezayi	\N	Mana	\N	+19729788395	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Helen  Amare	\N	member	t	pending	2025-08-28 03:01:26.825	2025-08-28 03:01:26.825	maybe	\N	f	\N	\N	\N	t
235	\N	Ghebreghiorgis	\N	Ghebrekidan	\N	+12142810985	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:26.895	2025-08-28 03:01:26.895	maybe	\N	f	\N	\N	\N	t
236	\N	Gidena	\N	Mehari	\N	+12149627974	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Angesome  Mehari	\N	member	t	pending	2025-08-28 03:01:26.965	2025-08-28 03:01:26.965	maybe	\N	f	\N	\N	\N	t
237	\N	Girmay	Hagos	Gebremicael	\N	+14698828692	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Haymanot  G/Hiwot	\N	member	t	pending	2025-08-28 03:01:27.036	2025-08-28 03:01:27.036	maybe	\N	f	\N	\N	\N	t
238	\N	Goitiom	\N	Tewolde	\N	+12402809837	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:27.106	2025-08-28 03:01:27.106	maybe	\N	f	\N	\N	\N	t
239	\N	Goitom	\N	Atsbha	\N	+12402893233	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Atsede  Haftamu	\N	member	t	pending	2025-08-28 03:01:27.178	2025-08-28 03:01:27.178	maybe	\N	f	\N	\N	\N	t
240	\N	Hadera	Medhane	weldegebriel	\N	+12143828574	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:27.249	2025-08-28 03:01:27.249	maybe	\N	f	\N	\N	\N	t
241	\N	Hailay	\N	Woldu	\N	+12147793331	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:27.319	2025-08-28 03:01:27.319	maybe	\N	f	\N	\N	\N	t
242	\N	Haileleul	\N	Haileyesus	\N	+16823653056	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:27.39	2025-08-28 03:01:27.39	maybe	\N	f	\N	\N	\N	t
243	\N	Halefom	\N	Gebreset	\N	+17372475259	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:27.461	2025-08-28 03:01:27.461	maybe	\N	f	\N	\N	\N	t
244	\N	Hana	\N	Eyasu	\N	+19726936631	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:27.533	2025-08-28 03:01:27.533	maybe	\N	f	\N	\N	\N	t
245	\N	Heven	\N	Beyene	\N	+14694738551	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:27.604	2025-08-28 03:01:27.604	maybe	\N	f	\N	\N	\N	t
246	\N	Hewan	\N	Haileslase	\N	+15125216281	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:27.844	2025-08-28 03:01:27.844	maybe	\N	f	\N	\N	\N	t
247	\N	Israel	\N	Alemayehu	\N	+16513999048	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Ruth  Tadesse	\N	member	t	pending	2025-08-28 03:01:27.915	2025-08-28 03:01:27.915	maybe	\N	f	\N	\N	\N	t
248	\N	Kalayou	\N	Gebregziabher	\N	+12147579142	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Alem  Asres	\N	member	t	pending	2025-08-28 03:01:27.99	2025-08-28 03:01:27.99	maybe	\N	f	\N	\N	\N	t
249	\N	Kesete	\N	G/Silassi	\N	+14694277877	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Alem  Desta	\N	member	t	pending	2025-08-28 03:01:28.063	2025-08-28 03:01:28.063	maybe	\N	f	\N	\N	\N	t
250	\N	Kibom	\N	Kidanu	\N	+14355576712	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Letebrhan  Nuguse	\N	member	t	pending	2025-08-28 03:01:28.243	2025-08-28 03:01:28.243	maybe	\N	f	\N	\N	\N	t
251	\N	Kibrom	\N	Desta	\N	+19723570222	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Brikti  Nigus	\N	member	t	pending	2025-08-28 03:01:28.313	2025-08-28 03:01:28.313	maybe	\N	f	\N	\N	\N	t
252	\N	Kidus	Dade	Mengesha	\N	+14693585053	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Selam  Chala	\N	member	t	pending	2025-08-28 03:01:28.386	2025-08-28 03:01:28.386	maybe	\N	f	\N	\N	\N	t
156	x3TZW5XcEaSLyqjsi5oD81KV3W83	besrat	\N	mezgebe	phone_17187758634@phone-signin.local	+17187758634	\N	female	\N	\N	1	9310 locarno dr	\N	Dallas	TX	75243	United States	\N	\N	2020-12-17	Senay Redda	156	member	t	pending	2025-08-17 13:43:18.365	2025-08-17 13:43:18.472	yes	100.00	f	\N	\N	\N	f
180	\N	Mehari	\N	Gebremariam	phone_12145660874@phone-signin.local	+12145660874	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	180	member	t	pending	2025-08-17 16:11:56.866	2025-08-28 03:01:34.036	maybe	240.00	f	\N	\N	\N	f
177	\N	Frew	\N	Gebremedhin	phone_17028248331@phone-signin.local	+17028248331	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	177	member	t	pending	2025-08-17 16:10:06.312	2025-08-17 16:10:06.402	maybe	\N	f	\N	\N	\N	f
178	\N	Hlina	\N	Aregawi	phone_14696592622@phone-signin.local	+14696592622	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	178	member	t	pending	2025-08-17 16:10:50.039	2025-08-17 16:10:50.113	maybe	\N	f	\N	\N	\N	f
179	\N	Tirhas	\N	Belay	phone_16203911727@phone-signin.local	+16203911727	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	179	member	t	pending	2025-08-17 16:11:28.142	2025-08-17 16:11:28.21	maybe	\N	f	\N	\N	\N	f
184	fFfztcWkqHW2UQJQwCpti3uhyc13	Fitsum	W	Beyene	mezraete5@yahoo.com	+12062355083	\N	male	Tewelde	\N	1	1902 E Yesler Eay	2	Seattle	WA	98122	United States	Masho B Tsehaye	+12062008733	2025-08-23	\N	184	member	t	pending	2025-08-24 00:21:52.738	2025-08-24 00:21:52.896	maybe	\N	f	\N	\N	single	f
253	\N	Kidus	\N	Yohanes	\N	+12146362754	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Liya  Solomon	\N	member	t	pending	2025-08-28 03:01:28.554	2025-08-28 03:01:28.554	maybe	\N	f	\N	\N	\N	t
254	\N	Kindeya	\N	N.Techan	\N	+12146014871	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Elsa	\N	member	t	pending	2025-08-28 03:01:28.631	2025-08-28 03:01:28.631	maybe	\N	f	\N	\N	\N	t
255	\N	Kiros	\N	Gebregewergis	\N	+16142141695	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Rewina  Girmay	\N	member	t	pending	2025-08-28 03:01:28.702	2025-08-28 03:01:28.702	maybe	\N	f	\N	\N	\N	t
256	\N	Kiros	\N	Nega	\N	+17209385069	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:28.778	2025-08-28 03:01:28.778	maybe	\N	f	\N	\N	\N	t
257	\N	Leake	\N	Wuteta	\N	+12145462054	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Helen  Kinfe	\N	member	t	pending	2025-08-28 03:01:28.851	2025-08-28 03:01:28.851	maybe	\N	f	\N	\N	\N	t
258	\N	Lemlem	\N	Semere	\N	+14699920935	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:28.924	2025-08-28 03:01:28.924	maybe	\N	f	\N	\N	\N	t
259	\N	Letay	\N	Negash	\N	+12143366124	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:28.997	2025-08-28 03:01:28.997	maybe	\N	f	\N	\N	\N	t
260	\N	Luul	\N	Teare	\N	+12068806657	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:29.068	2025-08-28 03:01:29.068	maybe	\N	f	\N	\N	\N	t
261	\N	Mahlet	\N	Yohannes	\N	+14699514264	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:29.143	2025-08-28 03:01:29.143	maybe	\N	f	\N	\N	\N	t
262	\N	Martha	\N	Gebru	\N	+14693445581	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Arefaine  Tesfay	\N	member	t	pending	2025-08-28 03:01:29.213	2025-08-28 03:01:29.213	maybe	\N	f	\N	\N	\N	t
263	\N	Mathias	\N	Abebe	\N	+14695565725	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Seble  Girma	\N	member	t	pending	2025-08-28 03:01:29.284	2025-08-28 03:01:29.284	maybe	\N	f	\N	\N	\N	t
264	\N	Mebrhit	\N	Gebremariam	\N	+15096900463	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Kibrom  Kidane	\N	member	t	pending	2025-08-28 03:01:29.354	2025-08-28 03:01:29.354	maybe	\N	f	\N	\N	\N	t
265	\N	Mehret	\N	Abraham	\N	+12146036295	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:29.425	2025-08-28 03:01:29.425	maybe	\N	f	\N	\N	\N	t
266	\N	Mekdes	Woldu	G/Mariam	\N	+19722777448	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Abebe  Baraki	\N	member	t	pending	2025-08-28 03:01:29.5	2025-08-28 03:01:29.5	maybe	\N	f	\N	\N	\N	t
267	\N	Mengstab	\N	Hagos	\N	+17209357619	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Akberet  Tekle	\N	member	t	pending	2025-08-28 03:01:29.57	2025-08-28 03:01:29.57	maybe	\N	f	\N	\N	\N	t
268	\N	Merhawi	\N	G	\N	+14046508093	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Mariam/Zelalem  Tegaw	\N	member	t	pending	2025-08-28 03:01:29.639	2025-08-28 03:01:29.639	maybe	\N	f	\N	\N	\N	t
269	\N	Mhreteab	\N	Hailemariam	\N	+13233848389	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Ruta Fitsum Gebreyohannes	\N	member	t	pending	2025-08-28 03:01:29.713	2025-08-28 03:01:29.713	maybe	\N	f	\N	\N	\N	t
270	\N	Michael	Kidane	G/giyorgis	\N	+12145662565	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:29.782	2025-08-28 03:01:29.782	maybe	\N	f	\N	\N	\N	t
271	\N	Mulu	\N	G	\N	+14695543506	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Egzeabher	\N	member	t	pending	2025-08-28 03:01:29.855	2025-08-28 03:01:29.855	maybe	\N	f	\N	\N	\N	t
272	\N	Mulubirhan	\N	Zerihun	\N	+18582981481	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Amanuel  Bahita	\N	member	t	pending	2025-08-28 03:01:29.932	2025-08-28 03:01:29.932	maybe	\N	f	\N	\N	\N	t
273	\N	Mulugeta	\N	W/Hiwot	\N	+12143155097	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Dehab  Mahimud	\N	member	t	pending	2025-08-28 03:01:30.007	2025-08-28 03:01:30.007	maybe	\N	f	\N	\N	\N	t
274	\N	Muluwork	Mesfin	Desta	\N	+14322716760	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Brook  Areguy	\N	member	t	pending	2025-08-28 03:01:30.087	2025-08-28 03:01:30.087	maybe	\N	f	\N	\N	\N	t
275	\N	Negash	\N	Hadgu	\N	+17173441276	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Yirgalem  Teklehaimanot	\N	member	t	pending	2025-08-28 03:01:30.158	2025-08-28 03:01:30.158	maybe	\N	f	\N	\N	\N	t
276	\N	Rahwa	\N	Mebrahtom	\N	+12063557037	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Angesom  Berhane	\N	member	t	pending	2025-08-28 03:01:30.226	2025-08-28 03:01:30.226	maybe	\N	f	\N	\N	\N	t
277	\N	Rbka	\N	Mesele	\N	+12145315963	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:30.296	2025-08-28 03:01:30.296	maybe	\N	f	\N	\N	\N	t
278	\N	Rehaset	\N	Kibreab	\N	+15108608886	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:30.37	2025-08-28 03:01:30.37	maybe	\N	f	\N	\N	\N	t
94	qsU2y7hfX9WlB0yMF0qsCC8LjKr2	Almaz	\N	Tesfay	almazt3@yahoo.com	+14699393483	\N	female	Welete Haymanot	\N	1	\N	\N	\N	\N	\N	USA	Gebre Tesfamichael	214-215-1360	\N	Gebre  Tesfamichael	94	relationship	t	pending	2025-08-15 02:37:35.312	2025-09-02 13:21:24.802	maybe	600.00	t	2025-08-17 01:44:17.635595+00	3	married	f
103	\N	Tsehaye	\N	Haftu	phone_14697664884@phone-signin.local	+14697664884	\N	\N	Gebreeyesus	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	103	member	t	pending	2025-08-16 00:49:08.947	2025-08-16 00:49:09.087	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
70	P48VrMMua7MVGbwyeUEE0scRF713	Noah	D	Yifter	noah@dawit.com	+19452179619	\N	male	Sss	\N	1	12540 Pond Cypress Ln	\N	Frisco	TX	75035	United States	Dado Yifter	+15555555555	2025-08-02	\N	70	relationship	t	pending	2025-08-09 22:06:23.312	2025-08-19 01:56:40.661	yes	600.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
181	h1ohbhsP3acEpn7aNaRuorBBeAn2	Yared	Seged	Hagos	yaredhagos1972@yahoo.com	469-939-5416	1972-12-28	male	Gebrehiwot	\N	1	3657 leigh ct	\N	Sachse	TX	75048	United States	Merafe haile	469-939-5302	2007-10-04	Merafe haile	181	relationship	t	pending	2025-08-18 16:24:03.509	2025-08-19 18:48:21.782	yes	1200.00	f	\N	\N	married	f
4	\N	Ruth	\N	Berhe	ruth_berhe@yahoo.com	+14697329760	1989-12-31	female	Weletebirhan	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:26:47.482	2025-08-02 16:26:47.486	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
5	\N	Yrgalem	\N	Kassa	yrgalem12gkassa@gmail.com	+12144046638	1989-12-31	female	Gebrearegawi	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:26:47.639	2025-08-02 16:26:47.64	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
6	\N	Gebrehiwot	\N	Fuli	filiamsaya@yahoo.com	+14692039460	1989-12-31	male	Gebrehiwot	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:26:48.768	2025-08-02 16:26:48.768	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
7	\N	Saimon	\N	Issak	wediissak06@yahoo.com	+13148096982	1989-12-31	male	Habtemariam	Kesis Seifu	6	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:26:48.984	2025-08-02 16:26:48.984	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
8	\N	Letay	\N	Hagos	letay4me@yahoo.com	+14695448295	1989-12-31	female	Weletemariam	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:26:49.395	2025-08-02 16:26:49.395	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
10	\N	Gebreegziabiher 	\N	Reda	gebre.reda@gmail.com	+16175163467	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:26:50.286	2025-08-02 16:26:50.286	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
11	\N	Berhane	\N	Gebremeskel	\N	+19723303435	1989-12-31	male	Berhanemeskel	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:55.014	2025-08-02 16:36:55.017	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
12	\N	Desta	\N	Atsbeha	\N	+13024651197	1989-12-31	male	\N	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:55.169	2025-08-02 16:36:55.169	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
13	\N	Ferehiwot	\N	Hailu	\N	+14163161283	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:55.312	2025-08-02 16:36:55.312	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
14	\N	Selam	\N	Gebrekristos	\N	+14699375833	1989-12-31	female	Weletesilassie	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:55.452	2025-08-02 16:36:55.452	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
15	\N	Tewodros	\N	Rada	\N	+14698970708	1989-12-31	male	\N	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:55.597	2025-08-02 16:36:55.597	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
16	\N	Bereket	\N	Amdemichael	\N	+19452869457	1989-12-31	male	teklehaimanot	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:55.739	2025-08-02 16:36:55.74	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
17	\N	Helen	\N	Gebremariam	\N	+12149313926	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:55.88	2025-08-02 16:36:55.881	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
18	\N	Frewaini	\N	Araya	\N	+14696552422	1989-12-31	female	Weletemariam	Kesis Seifu	2	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:56.026	2025-08-02 16:36:56.026	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
19	\N	Sara	\N	Teklu	\N	+12673824462	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:56.167	2025-08-02 16:36:56.168	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
20	\N	Saba	\N	Teklu	\N	+16206554131	1989-12-31	female	\N	\N	4	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:56.311	2025-08-02 16:36:56.311	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
23	\N	Omega	\N	Tesfay	\N	+12067391096	1989-12-31	male	Ametegiorgis	\N	3	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:56.777	2025-08-02 16:36:56.777	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
24	\N	Temesgen	\N	Weldemichael	\N	+12023206727	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:56.919	2025-08-02 16:36:56.919	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
25	\N	Hadas	\N	Tsehaye	\N	+14692337735	1989-12-31	female	Weleabyezgi	Kesis Seifu	4	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:57.13	2025-08-02 16:36:57.13	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
26	\N	Mearg	\N	Yifter	\N	+12148665234	1989-12-31	male	Weletemeskel	Kesis Seifu	3	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:57.346	2025-08-02 16:36:57.346	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
27	\N	Mengiste	\N	Beyene	\N	+12147155605	1989-12-31	male	\N	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:57.488	2025-08-02 16:36:57.488	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
28	\N	Letemeskel	\N	Legese	\N	+15126211802	1989-12-31	female	Ametemeskel	Abune Kerlos	2	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:57.635	2025-08-02 16:36:57.635	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
29	\N	Hewon	\N	Hailesilasie	\N	+19455427308	1989-12-31	female	Mistresilasie	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:57.776	2025-08-02 16:36:57.776	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
30	\N	Gebre	\N	Bihen	\N	+14694032686	1989-12-31	male	Gebregziabiher	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:57.996	2025-08-02 16:36:57.997	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
147	\N	Yorisalem	\N	Mebrahtom	phone_12149095063@phone-signin.local	+12149095063	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	147	member	t	pending	2025-08-16 01:41:34.215	2025-08-16 01:41:34.288	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
148	\N	Zufan	\N	Lema	phone_15127347420@phone-signin.local	+15127347420	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	148	member	t	pending	2025-08-16 01:43:28.856	2025-08-16 01:43:28.926	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
150	\N	Yishaq	\N	Tesfamariam	phone_14692697150@phone-signin.local	+14692697150	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	150	member	t	pending	2025-08-16 01:44:54.687	2025-08-16 01:44:54.758	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
151	\N	Tesfay	\N	Gebrekidan	phone_12109805544@phone-signin.local	+12109805544	\N	\N	Tesfalidet	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	151	member	t	pending	2025-08-16 01:46:05.402	2025-08-16 01:46:05.469	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
185	\N	Atsede	H	Zewde	habtamuatsede@gmail.com	+14698709132	\N	female	Atsede Mariam	\N	1	12221 Plano Rd	1071	Dallas	TX	75243	USA	\N	\N	\N	\N	185	member	t	pending	2025-08-24 15:14:31.331	2025-08-24 15:14:31.483	yes	240.00	f	\N	\N	\N	f
279	\N	Robel	\N	Feseha	\N	+14694186677	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Birhan  G/medihin	\N	member	t	pending	2025-08-28 03:01:30.443	2025-08-28 03:01:30.443	maybe	\N	f	\N	\N	\N	t
280	\N	Sabrina	\N	Yasin	\N	+13125937950	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:30.52	2025-08-28 03:01:30.52	maybe	\N	f	\N	\N	\N	t
281	\N	Samirawit	\N	Birhanu	\N	+19402975969	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:30.599	2025-08-28 03:01:30.599	maybe	\N	f	\N	\N	\N	t
282	\N	Sammy	\N	Bezabeh	\N	+19726038286	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:30.671	2025-08-28 03:01:30.671	maybe	\N	f	\N	\N	\N	t
283	\N	Samuel	Araya	G/Mariam	\N	+14043972611	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:30.742	2025-08-28 03:01:30.742	maybe	\N	f	\N	\N	\N	t
9	\N	Firewoini	\N	Weldu	firewoini@yahoo.com	+14692306671	1989-12-31	female	\N	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:26:49.601	2025-08-28 03:01:34.251	maybe	240.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
21	\N	Zufan	\N	Assefa	\N	+12086139634	1989-12-31	female	Weletesilassie	Abune Kerlos	3	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:56.494	2025-08-28 03:01:34.322	maybe	360.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
22	\N	Hadera	\N	Gidey	\N	+16822212646	1989-12-31	male	\N	Abune Kerlos	4	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:56.636	2025-08-28 03:01:34.396	maybe	360.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
149	\N	Abrha	\N	Kahsay	phone_15125669881@phone-signin.local	+15125669881	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	149	member	t	pending	2025-08-16 01:44:15.787	2025-08-28 03:01:34.742	maybe	300.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
31	\N	Asefash	\N	Berhe	\N	+12145193332	1989-12-31	male	Weletegergis	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:58.209	2025-08-02 16:36:58.21	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
33	\N	Letay	\N	Birhane	\N	+12149001257	1989-12-31	female	Weletemariam	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:58.498	2025-08-02 16:36:58.498	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
36	\N	Senayt	\N	Berhe	\N	+14693091637	1989-12-31	female	Weletemariam	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:58.987	2025-08-02 16:36:58.987	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
37	\N	Zufan	\N	Kiros	\N	+12543276770	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:59.136	2025-08-02 16:36:59.136	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
38	\N	Meron	\N	Weldselase	\N	+12147728603	1989-12-31	female	Weletesilase	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:59.352	2025-08-02 16:36:59.352	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
39	\N	Selam	\N	Gebremariam	\N	+12148817016	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:59.498	2025-08-02 16:36:59.498	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
40	\N	Solomon	\N	Asfeha	\N	+14693698020	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:59.641	2025-08-02 16:36:59.641	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
41	\N	Goytom	\N	Abrha	\N	+12148827335	1989-12-31	male	Gebrelibanos	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:59.794	2025-08-02 16:36:59.794	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
42	\N	Birensh	\N	Abraha	\N	+12408159716	1989-12-31	female	Weletearegawi	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:59.933	2025-08-02 16:36:59.933	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
43	\N	Tekea	\N	Beyene	\N	+12144681521	1989-12-31	male	Gebreyohanes	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:00.076	2025-08-02 16:37:00.076	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
44	\N	Selamawit	\N	Kidane	\N	+14697357867	1989-12-31	male	Hanamariam	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:00.212	2025-08-02 16:37:00.212	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
46	\N	Lyia	\N	Berhe	\N	+17122593724	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:00.5	2025-08-02 16:37:00.5	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
52	\N	Saimon	\N	Habte	\N	+15102004212	1989-12-31	male	\N	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:01.363	2025-08-02 16:37:01.363	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
54	\N	Firahewot	\N	Girma	\N	+14694797224	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:01.645	2025-08-02 16:37:01.645	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
56	\N	Michael	\N	Kahsay	\N	+12404840310	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:01.929	2025-08-02 16:37:01.929	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
57	\N	Meresa	\N	Weldemichael	\N	+14694503896	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:02.07	2025-08-02 16:37:02.07	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
58	\N	Mebratu	\N	Legese	\N	+12142903694	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:02.209	2025-08-02 16:37:02.21	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
59	\N	Eskinder	\N	Beru	\N	+15049209682	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:02.351	2025-08-02 16:37:02.351	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
60	\N	Mengs	\N	Ghirmay	\N	+12149709213	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:02.491	2025-08-02 16:37:02.492	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
87	\N	Azeb	\N	Tesfay	phone_12144549790@phone-signin.local	+12144549790	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	87	member	t	pending	2025-08-14 12:55:31.734	2025-08-14 12:55:31.825	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
88	V2gaps6EZ5Yn4sSaF8FSUpJFIGa2	Natan	\N	Tadesse	phone_14697838603@phone-signin.local	+14697838603	\N	male	\N	\N	1	Ridgecrest road	\N	Dallas	Texas	75231	United States	Mother	+14692557522	\N	\N	88	member	t	pending	2025-08-14 17:40:31.149	2025-08-14 17:40:31.284	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
90	\N	Firtuna	\N	Gebregiazbiher	phone_14157161734@phone-signin.local	+14157161734	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	90	member	t	pending	2025-08-15 02:19:35.039	2025-08-15 02:19:35.111	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
91	\N	Sintayehu	\N	Negash	phone_12148155609@phone-signin.local	+12148155609	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	91	member	t	pending	2025-08-15 02:33:40.93	2025-08-15 02:33:41.053	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
78	kZNdGtlMRscKH5gGxRTPDhp5PJZ2	Teshager	\N	Muruts	yk11mttz@gmail.com	+13102517207	\N	male	Hailemariam 	\N	1	458 winterwood dr	\N	Lavon	Texas	75166	United States	\N	\N	2011-01-10	Zuriash Abraha	78	member	t	pending	2025-08-10 15:28:41.8	2025-08-10 15:28:50.559	yes	600.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
72	Wrb1I62LojRU94Q3B2fAFEgzsgA2	Desta	Berihu	Weldegiorgis	destaweldegiorgis@gmail.com	+16418191591	1985-07-04	male	Grebrehiwot	\N	1	3302 Willena Rd	\N	Melissa	TX	75454	United States	\N	\N	2022-02-26	Freweyni Gebrehiwot Yitbarek	72	relationship	t	pending	2025-08-10 02:49:55.848	2025-08-23 17:47:57.989	yes	270.01	t	2025-08-17 01:44:17.635595+00	3	\N	f
77	4qOxnlvJkff7KxQGYFbejlx90A63	Almaz	\N	Ertro	ertro22@yahoo.com	+14045430559	\N	female	Atsede Mariam	\N	1	1089 Old Oaks Dr	\N	Forney	TX	75126	United States	\N	\N	2009-08-11	Yohannes Gebreselasi	77	admin	t	pending	2025-08-10 14:54:55.431	2025-08-24 14:44:34.803	yes	600.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
32	\N	Haftom	\N	Fiseha	\N	+14692030195	1989-12-31	male	Habtesilasie	Kesis Seifu	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:58.358	2025-08-28 03:01:35.216	maybe	0.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
34	\N	Afework	\N	Desta	\N	+14692798246	1989-12-31	male	Hailemariam	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:58.639	2025-08-28 03:01:35.291	maybe	0.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
35	\N	Sara	\N	Fiseha	\N	+12144003901	1989-12-31	female	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:36:58.783	2025-08-28 03:01:35.362	maybe	120.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
45	\N	Tewelde 	\N	Zeru	\N	+12145176610	1989-12-31	male	Teweldebirhan	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:00.358	2025-08-28 03:01:35.432	maybe	1200.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
51	\N	Tsegazeab	\N	Gidey	\N	+12028677246	1989-12-31	male	Weldegebriel	Kesis Tadesse	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:01.218	2025-08-28 03:01:35.502	maybe	120.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
53	\N	Meaza	\N	Gezahegn	\N	+12142131874	1989-12-31	female	Tsigiemariam	Abune Kerlos	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:01.506	2025-08-28 03:01:35.573	maybe	240.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
55	\N	Yohannes	\N	Weldegebriel	\N	+12066024783	1989-12-31	male	Fikremariam	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:01.786	2025-08-28 03:01:35.644	maybe	0.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
61	\N	Haile	\N	Fenta	\N	+15027183529	1989-12-31	male	\N	\N	1	TBD	\N	TBD	TX	75000	United States	\N	\N	\N	\N	\N	member	t	pending	2025-08-02 16:37:02.632	2025-08-28 03:01:35.715	maybe	240.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
66	hnALowiR2wcIs1FNie9rSOh5apt1	Solomon	L	Gebreslasie	solomongeb22@gmail.com	+12067517952	1975-01-05	male	\N	\N	1	10867 N Central Expy	117	Dallas	TX	75231	United States	Ashenafi Taffere	+12065782304	\N	\N	66	secretary	t	pending	2025-08-06 02:21:04.768	2025-08-28 03:01:35.788	maybe	600.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
89	\N	Almaz	\N	Gebremariam	phone_19728093269@phone-signin.local	+19728093269	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	89	member	t	pending	2025-08-15 02:17:51.598	2025-08-28 03:01:35.864	maybe	120.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
92	\N	Fana	\N	Solomon	phone_12147839780@phone-signin.local	+12147839780	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	92	member	t	pending	2025-08-15 02:35:08.999	2025-08-28 03:01:35.936	maybe	240.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
93	\N	Shewit	\N	Baraki	phone_19452253577@phone-signin.local	+19452253577	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	93	member	t	pending	2025-08-15 02:35:39.816	2025-08-15 02:35:39.883	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
84	\N	Tinsae	\N	Girma	phone_12149573432@phone-signin.local	+12149573432	\N	\N	Mahdere Mariam	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	84	member	t	pending	2025-08-14 12:38:24.581	2025-08-14 12:38:24.716	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
86	\N	Kibrom	\N	Beyene	phone_14696028512@phone-signin.local	+14696028512	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	86	member	t	pending	2025-08-14 12:46:02.873	2025-08-14 12:46:02.972	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
98	\N	Ashenafi	\N	Kidanemariam	phone_12023742605@phone-signin.local	+12023742605	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	98	member	t	pending	2025-08-15 03:23:59.249	2025-08-15 03:23:59.317	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
99	\N	Kal	\N	Enquebahri	phone_12149919930@phone-signin.local	+12149919930	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	99	member	t	pending	2025-08-15 03:24:36.687	2025-08-15 03:24:36.76	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
100	\N	Bereket	\N	Haile	phone_12144029719@phone-signin.local	+12144029719	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	100	member	t	pending	2025-08-15 03:25:02.159	2025-08-15 03:25:02.225	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
101	\N	Liwam	\N	Tesfay	phone_14696001994@phone-signin.local	+14696001994	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	101	member	t	pending	2025-08-15 03:25:51.054	2025-08-15 03:25:51.12	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
102	\N	Letay	\N	Tensay	phone_19723307760@phone-signin.local	+19723307760	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	102	member	t	pending	2025-08-15 03:26:29.715	2025-08-15 03:26:29.788	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
104	\N	Genet	\N	Abasajir	phone_19454467772@phone-signin.local	+19454467772	\N	\N	Hailemichael	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	104	member	t	pending	2025-08-16 00:50:03.898	2025-08-16 00:50:03.973	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
107	\N	Yordanos	\N	Kifle	phone_14697397554@phone-signin.local	+14697397554	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	107	member	t	pending	2025-08-16 00:53:52.184	2025-08-16 00:53:52.254	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
108	\N	Negasi	\N	Birhane	phone_12146877343@phone-signin.local	+12146877343	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	108	member	t	pending	2025-08-16 00:54:49.175	2025-08-16 00:54:49.437	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
110	\N	Seble	\N	Dawit	phone_19728355197@phone-signin.local	+19728355197	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	110	member	t	pending	2025-08-16 00:56:27.815	2025-08-16 00:56:27.889	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
113	\N	Alex	\N	Abrha	phone_12145766314@phone-signin.local	+12145766314	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	113	member	t	pending	2025-08-16 00:58:58.042	2025-08-16 00:58:58.12	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
114	\N	Alem	Belay 	Gesese	phone_14697047552@phone-signin.local	+14697047552	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	114	member	t	pending	2025-08-16 01:00:00.832	2025-08-16 01:00:00.919	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
115	\N	Mibrak	\N	Aregay	phone_16203914758@phone-signin.local	+16203914758	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	115	member	t	pending	2025-08-16 01:08:45.463	2025-08-16 01:08:45.55	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
116	\N	Genet	Gebregergis	Weletewahid	phone_14694654313@phone-signin.local	+14694654313	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	116	member	t	pending	2025-08-16 01:10:03.662	2025-08-16 01:10:03.732	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
117	\N	Tigist	\N	Abrham	phone_19724889038@phone-signin.local	+19724889038	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	117	member	t	pending	2025-08-16 01:10:49.676	2025-08-16 01:10:49.748	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
118	\N	Kidist	\N	Tsehay	phone_12145740499@phone-signin.local	+12145740499	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	118	member	t	pending	2025-08-16 01:11:25.773	2025-08-16 01:11:25.846	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
120	\N	Meseret	\N	Nigus	phone_14694647359@phone-signin.local	+14694647359	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	120	member	t	pending	2025-08-16 01:13:03.183	2025-08-16 01:13:03.256	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
121	\N	Biruk	\N	Gebru	phone_15852870931@phone-signin.local	+15852870931	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	121	member	t	pending	2025-08-16 01:13:50.796	2025-08-16 01:13:50.869	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
125	\N	Fisseha	\N	Atsbeha	phone_16414511451@phone-signin.local	+16414511451	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	125	member	t	pending	2025-08-16 01:18:51.163	2025-08-16 01:18:51.24	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
126	\N	Helina	\N	Araya	phone_12146060748@phone-signin.local	+12146060748	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	126	member	t	pending	2025-08-16 01:22:57.838	2025-08-16 01:22:57.906	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
127	\N	Selam	\N	Asgedom	phone_14698182003@phone-signin.local	+14698182003	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	127	member	t	pending	2025-08-16 01:23:48.99	2025-08-16 01:23:49.072	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
128	\N	Letay	\N	Hagos	phone_14965448295@phone-signin.local	+14965448295	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	128	member	t	pending	2025-08-16 01:24:36.038	2025-08-16 01:24:36.113	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
129	\N	Abigail	\N	Teka	phone_17028819477@phone-signin.local	+17028819477	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	129	member	t	pending	2025-08-16 01:25:09.647	2025-08-16 01:25:09.719	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
130	\N	Ephrem	\N	Weldegiorgis	phone_12147721579@phone-signin.local	+12147721579	\N	\N	Hailemariam	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	130	member	t	pending	2025-08-16 01:26:19.411	2025-08-16 01:26:19.48	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
131	\N	Dawit	\N	Zeweldi	phone_18603368009@phone-signin.local	+18603368009	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	131	member	t	pending	2025-08-16 01:27:19.993	2025-08-16 01:27:20.06	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
95	pcI3gS4t6GNTCH1qFHh5yZnLgYt2	Gebre	\N	Tesfamichael	phone_12142151360@phone-signin.local	+12142151360	\N	\N	Gebremeskel	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	95	member	t	pending	2025-08-15 03:19:39.093	2025-08-17 13:52:49.376	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
80	2qjonR5MoaT68C3sCQaSteIitZq1	helu	G	Gebremeskel	phone_14698883430@phone-signin.local	+14698883430	\N	female	\N	\N	1	4405 Carmel st	\N	Dallas 	Tx	76040	United States	\N	\N	2025-08-12	Xxxxxx	80	member	t	pending	2025-08-12 23:28:39.029	2025-08-17 14:19:14.393	yes	20.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
106	cEUGqXOAcJdsyvZ9VjbllsK9lrG3	Yohannes	\N	Gebresilassie	phone_12144047129@phone-signin.local	+12144047129	\N	male	Kiflezgie	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	106	relationship	t	pending	2025-08-16 00:52:50.599	2025-08-23 16:09:53.112	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
97	\N	Degef	\N	Kasahun	phone_14699392174@phone-signin.local	+14699392174	\N	\N	Welete Eyesus	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	97	member	t	pending	2025-08-15 03:23:10.118	2025-08-28 03:01:36.009	maybe	120.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
105	\N	Andom	\N	Berhe	phone_17202167616@phone-signin.local	+17202167616	\N	\N	Hailemichael	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	105	member	t	pending	2025-08-16 00:51:48.071	2025-08-28 03:01:36.081	maybe	120.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
109	\N	Misghna	\N	Welegerima	phone_12148815409@phone-signin.local	+12148815409	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	109	member	t	pending	2025-08-16 00:55:36.876	2025-08-28 03:01:36.158	maybe	240.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
111	\N	Trhas	\N	Negash	phone_17204002017@phone-signin.local	+17204002017	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	111	member	t	pending	2025-08-16 00:57:04.708	2025-08-28 03:01:36.243	maybe	240.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
119	\N	Mirtnesh	\N	Kidanemariam	phone_14696500771@phone-signin.local	+14696500771	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	119	member	t	pending	2025-08-16 01:12:23.565	2025-08-28 03:01:36.402	maybe	1680.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
122	\N	Yemane	\N	Weldemichael	phone_12145170922@phone-signin.local	+12145170922	\N	\N	Teweldebirhan	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	122	member	t	pending	2025-08-16 01:14:48.317	2025-08-28 03:01:36.474	maybe	0.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
123	\N	Mulu	\N	Negasi	phone_14696848204@phone-signin.local	+14696848204	\N	\N	Weletesilasie	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	123	member	t	pending	2025-08-16 01:15:36.319	2025-08-28 03:01:36.541	maybe	120.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
124	VFpWIyPh9PZPGcwOZ8uLbnnIf5y2	Eden	\N	Kassa	edenkassa11@gmail.com	+12146796610	\N	\N	Askalemariam	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	124	member	t	pending	2025-08-16 01:17:15.471	2025-08-28 03:01:36.612	maybe	240.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
96	\N	Tesfom	\N	Gebrehiwot	phone_14439348109@phone-signin.local	+14439348109	\N	male	Tesfamariam	\N	1	3957 Sidney ln	\N	Heath	Tx	75126	USA	\N	\N	\N	\N	96	member	t	pending	2025-08-15 03:21:40.459	2025-09-07 14:50:37.023	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	married	f
132	\N	Fiyori	\N	Fitsum	phone_14698814746@phone-signin.local	+14698814746	\N	\N	Weletemariam	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	132	member	t	pending	2025-08-16 01:28:18.501	2025-08-16 01:28:18.575	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
134	\N	Kidus	\N	Aregawi	phone_12063066593@phone-signin.local	+12063066593	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	134	member	t	pending	2025-08-16 01:29:08.556	2025-08-16 01:29:08.637	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
135	\N	Liwam	\N	Gidey	phone_16173692357@phone-signin.local	+16173692357	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	135	member	t	pending	2025-08-16 01:30:42.436	2025-08-16 01:30:42.503	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
136	\N	Nataeal	\N	Tsigab	phone_12023611630@phone-signin.local	+12023611630	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	136	member	t	pending	2025-08-16 01:32:02.281	2025-08-16 01:32:02.348	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
137	\N	Yirgalem	\N	Teferi	phone_14696641192@phone-signin.local	+14696641192	\N	\N	Tsegasilassie	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	137	member	t	pending	2025-08-16 01:32:43.194	2025-08-16 01:32:43.264	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
139	\N	Abraha	\N	Tesfay	phone_12144340370@phone-signin.local	+12144340370	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	139	member	t	pending	2025-08-16 01:35:37.061	2025-08-16 01:35:37.134	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
141	\N	Amelework	\N	Desta	phone_12142358827@phone-signin.local	+12142358827	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	141	member	t	pending	2025-08-16 01:37:08.847	2025-08-16 01:37:08.913	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
142	\N	Daniel	\N	Demoz	phone_19726932308@phone-signin.local	+19726932308	\N	\N	Amanuel	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	142	member	t	pending	2025-08-16 01:37:53.964	2025-08-16 01:37:54.032	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
143	sr2Knu9UzbV5e3KFGgiixsNu0pz1	Dawit	\N	Abraham	dawit_adwa@yahoo.com	+12144507647	\N	male	\N	\N	1	2714 dove Creek Dr 	\N	Rowlett 	Texas	75088	United States	\N	\N	\N	Mebrat eyasy	143	member	t	pending	2025-08-16 01:38:06.191	2025-08-16 01:38:06.265	maybe	4800.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
144	\N	Tekie	\N	Reta	phone_13413561068@phone-signin.local	+13413561068	\N	\N	Gebregiabiher	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	144	member	t	pending	2025-08-16 01:38:42.213	2025-08-16 01:38:42.29	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
145	\N	Dawit	\N	Fshaye	phone_15129389057@phone-signin.local	+15129389057	\N	\N	Gebremichael	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	145	member	t	pending	2025-08-16 01:40:05.127	2025-08-16 01:40:05.199	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
146	\N	Brhan	\N	abraha	phone_15128885846@phone-signin.local	+15128885846	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	146	member	t	pending	2025-08-16 01:40:53.072	2025-08-16 01:40:53.137	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
152	kmU8M2DwudYWJxNybmpexLEXjX52	Zaab	\N	Weldegebrial	phone_14694785934@phone-signin.local	+14694785934	\N	male	\N	\N	1	331 Houston St	\N	Lavon	TX	75166	United States	\N	\N	\N	Martha Mulugeta	152	secretary	t	pending	2025-08-16 23:10:58.509	2025-08-17 00:23:15.793	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
138	\N	Tirhas	\N	Woldu	phone_14697740370@phone-signin.local	+14697740370	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	138	member	t	pending	2025-08-16 01:35:01.683	2025-08-28 03:01:36.682	maybe	600.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
158	\N	Alem	\N	Kidane	phone_14699529112@phone-signin.local	+14699529112	\N	female	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	158	member	t	pending	2025-08-17 14:39:18.26	2025-08-19 02:33:24.805	maybe	\N	t	2025-08-19 02:33:24.805+00	70	\N	f
133	XNZmUK1MIGM32ba8l87znhHyJAv2	Mengistu	Yeebyo	Alemayehu	myeebyo@gmail.com	+14699396475	\N	male	\N	\N	1	112 Enchanted Forest Dr	\N	wylie	TX	75098	United States	\N	\N	2007-01-01	Yezichalem	133	member	t	pending	2025-08-16 01:28:19.366	2025-08-29 02:45:54.417	yes	1200.00	t	2025-08-17 01:44:17.635595+00	3	married	f
182	rS6LsausHbhwi5FK0x0l2hfEAqY2	YESHI	EMEBIET	ZERIHUN	yeshizerihun1212@gmail.com	+19728158206	\N	female	Kidusan	\N	1	5418 Kentcroft Drive, , Garland	\N	garland	TX	75043-5347	United States	Matthew Mulugeta	+12142837369	2014-01-01	\N	182	treasurer	t	pending	2025-08-21 01:32:19.699	2025-08-29 14:51:02.556	yes	1200.00	t	2025-08-22 01:35:27.048+00	3	Widowed	f
140	\N	Bisrat	\N	Gebresilassie	phone_14045435685@phone-signin.local	+14045435685	\N	female	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	140	relationship	t	pending	2025-08-16 01:36:15.029	2025-08-23 16:01:58.574	maybe	\N	t	2025-08-17 01:44:17.635595+00	3	married	f
186	\N	Terhas	Mengistu	WoldeGerima	terhaswoldegerima@gmail.com	+17039063098	\N	female	Wolete Medhin	\N	1	810 Milenda Dr	\N	Allen	TX	75002	USA	\N	\N	\N	\N	186	member	t	pending	2025-08-24 16:12:57.999	2025-08-24 16:12:58.13	maybe	120.00	f	\N	\N	\N	f
284	\N	Sandra	\N	Agarratt	\N	+19174497632	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	TC  Webb	\N	member	t	pending	2025-08-28 03:01:30.813	2025-08-28 03:01:30.813	maybe	\N	f	\N	\N	\N	t
285	\N	Sara	(saba)	Mesfin	\N	+14044547635	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:30.884	2025-08-28 03:01:30.884	maybe	\N	f	\N	\N	\N	t
286	\N	Segenet	\N	Zeratsion	\N	+14698555138	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:30.956	2025-08-28 03:01:30.956	maybe	\N	f	\N	\N	\N	t
287	\N	Selam	\N	Mesfin	\N	+19724085869	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Samrawit  Kidane	\N	member	t	pending	2025-08-28 03:01:31.029	2025-08-28 03:01:31.029	maybe	\N	f	\N	\N	\N	t
288	\N	Selemon	\N	Kahaso	\N	+14086771983	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Kidist  Abeb	\N	member	t	pending	2025-08-28 03:01:31.104	2025-08-28 03:01:31.104	maybe	\N	f	\N	\N	\N	t
289	\N	Semere	\N	Berehe	\N	+17208419309	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Tiruwork  Hadgay	\N	member	t	pending	2025-08-28 03:01:31.175	2025-08-28 03:01:31.175	maybe	\N	f	\N	\N	\N	t
290	\N	Semere	Desta	Belay	\N	+14694166592	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:31.249	2025-08-28 03:01:31.249	maybe	\N	f	\N	\N	\N	t
291	\N	SIMON	\N	SEBHAT	\N	+17033407506	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Eden  Tekle	\N	member	t	pending	2025-08-28 03:01:31.324	2025-08-28 03:01:31.324	maybe	\N	f	\N	\N	\N	t
292	\N	Sisay	G.	Giorgis	\N	+14692685331	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Sabela  Wessen	\N	member	t	pending	2025-08-28 03:01:31.398	2025-08-28 03:01:31.398	maybe	\N	f	\N	\N	\N	t
293	\N	Solomon	\N	GebremMedhin	\N	+14693962012	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Medhin  Gebremariam	\N	member	t	pending	2025-08-28 03:01:31.484	2025-08-28 03:01:31.484	maybe	\N	f	\N	\N	\N	t
294	\N	Solomon	\N	Tesfaye	\N	+14696711748	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Samrawit  Kidane	\N	member	t	pending	2025-08-28 03:01:31.566	2025-08-28 03:01:31.566	maybe	\N	f	\N	\N	\N	t
295	\N	Tekabo	\N	Giorgis	\N	+12143171145	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Nigesti  Ayele	\N	member	t	pending	2025-08-28 03:01:31.648	2025-08-28 03:01:31.648	maybe	\N	f	\N	\N	\N	t
296	\N	Tekea	\N	Beyene	\N	+12144485959	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Roman	\N	member	t	pending	2025-08-28 03:01:31.72	2025-08-28 03:01:31.72	maybe	\N	f	\N	\N	\N	t
297	\N	Tekie	\N	Reta	\N	+13413561126	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Tsege Hadera Tsegemariam	\N	member	t	pending	2025-08-28 03:01:31.791	2025-08-28 03:01:31.791	maybe	\N	f	\N	\N	\N	t
299	\N	Tena	\N	Derar	\N	+17867599288	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:31.94	2025-08-28 03:01:31.94	maybe	\N	f	\N	\N	\N	t
300	\N	Tesfalidet	\N	Tareke	\N	+12142374373	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Tirhas  w.gibriel	\N	member	t	pending	2025-08-28 03:01:32.017	2025-08-28 03:01:32.017	maybe	\N	f	\N	\N	\N	t
301	\N	Tesfay	\N	Markos	\N	+19406429766	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:32.092	2025-08-28 03:01:32.092	maybe	\N	f	\N	\N	\N	t
302	\N	Tesfay	\N	Mezgebo	\N	+12403572650	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:32.167	2025-08-28 03:01:32.167	maybe	\N	f	\N	\N	\N	t
303	\N	Tesfay	\N	Yikuno	\N	+14694716779	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Eleni  Gebru	\N	member	t	pending	2025-08-28 03:01:32.239	2025-08-28 03:01:32.239	maybe	\N	f	\N	\N	\N	t
304	\N	Tesfaye	\N	Araya	\N	+14694933952	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Genet  Mengisteab	\N	member	t	pending	2025-08-28 03:01:32.311	2025-08-28 03:01:32.311	maybe	\N	f	\N	\N	\N	t
305	\N	Tilahun	Arefaine	Tedla	\N	+12145468437	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:32.388	2025-08-28 03:01:32.388	maybe	\N	f	\N	\N	\N	t
306	\N	Timnit	\N	Alemayoh	\N	+12149312570	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:32.463	2025-08-28 03:01:32.463	maybe	\N	f	\N	\N	\N	t
307	\N	Tirhas	\N	Gebresilassie	\N	+12144982834	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Goitom  Habtesion	\N	member	t	pending	2025-08-28 03:01:32.542	2025-08-28 03:01:32.542	maybe	\N	f	\N	\N	\N	t
308	\N	Tsigabu	\N	Weldekidan	\N	+12145624173	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Fereweini	\N	member	t	pending	2025-08-28 03:01:32.616	2025-08-28 03:01:32.616	maybe	\N	f	\N	\N	\N	t
309	\N	Woiny	\N	Teka	\N	+12147017192	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:32.688	2025-08-28 03:01:32.688	maybe	\N	f	\N	\N	\N	t
310	\N	Wolday	\N	Nerayo	\N	+14696028916	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Yodit  Tesfahunegn	\N	member	t	pending	2025-08-28 03:01:32.755	2025-08-28 03:01:32.755	maybe	\N	f	\N	\N	\N	t
311	\N	Wondimagegn	\N	Tekleab	\N	+14895195848	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:32.826	2025-08-28 03:01:32.826	maybe	\N	f	\N	\N	\N	t
312	\N	Woynishet	\N	Tesema	\N	+12145607261	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:32.9	2025-08-28 03:01:32.9	maybe	\N	f	\N	\N	\N	t
313	\N	Yakob	\N	Gebrekidan	\N	+14694504673	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Rahel  Segad	\N	member	t	pending	2025-08-28 03:01:32.972	2025-08-28 03:01:32.972	maybe	\N	f	\N	\N	\N	t
315	\N	Yemisrach	\N	Girma	\N	+12146072380	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:33.125	2025-08-28 03:01:33.125	maybe	\N	f	\N	\N	\N	t
316	\N	Yodit	\N	Kidane	\N	+12142993477	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:33.204	2025-08-28 03:01:33.204	maybe	\N	f	\N	\N	\N	t
317	\N	Yohannes	\N	Weldgerima	\N	+16027721523	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Riyori  Gebremariam	\N	member	t	pending	2025-08-28 03:01:33.278	2025-08-28 03:01:33.278	maybe	\N	f	\N	\N	\N	t
157	\N	Selamawit	\N	Hagos	phone_14699510834@phone-signin.local	+14699510834	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	157	member	t	pending	2025-08-17 14:38:28.463	2025-08-28 03:01:34.179	maybe	1200.00	f	\N	\N	\N	f
112	\N	Zewdi	\N	Abrha	phone_12105029282@phone-signin.local	+12105029282	\N	\N	Weleteegziabiher	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	112	member	t	pending	2025-08-16 00:58:15.368	2025-08-28 03:01:36.316	maybe	600.00	t	2025-08-17 01:44:17.635595+00	3	\N	f
298	cJhVODu1bsY2BrsetIGblUHAHf62	Teklemariam	T	Tesfay	\N	+14077195667	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Tsega W Gebremariam	\N	member	t	pending	2025-08-28 03:01:31.865	2025-08-29 04:40:28.842	maybe	\N	f	\N	\N	\N	t
321	\N	Zimame	\N	Kebede(Gezahgn)	\N	+12142588415	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Efrem  Woldemarkos	\N	member	t	pending	2025-08-28 03:01:33.73	2025-08-30 00:35:37.389	maybe	\N	t	2025-08-30 00:35:37.389+00	3	\N	t
320	\N	Zaidom	\N	Kidane	\N	+12143360606	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Amleset  Kahsay	\N	member	t	pending	2025-08-28 03:01:33.654	2025-08-30 00:35:39.633	maybe	\N	t	2025-08-30 00:35:39.633+00	3	\N	t
319	\N	Zaid	Semu	Tesfay	\N	+16822034208	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:33.58	2025-08-30 00:35:41.337	maybe	\N	t	2025-08-30 00:35:41.337+00	3	\N	t
314	\N	Yared	\N	W/Gebriel	\N	+14695440174	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	Kelebet  Yesunh	\N	member	t	pending	2025-08-28 03:01:33.051	2025-08-30 00:35:49.556	maybe	\N	t	2025-08-30 00:35:49.556+00	3	\N	t
85	7tHP8kdC88ZOEefTYuegnLGTPzy2	Dn Abrham	Takele	Haile	phone_14693601356@phone-signin.local	+14693601356	\N	male	\N	\N	1	186 w Autumn Hill Bluff	\N	Lavon	TEXAS	75166	USA	\N	\N	2010-04-20	\N	85	member	t	pending	2025-08-14 12:40:32.998	2025-08-30 02:56:07.843	yes	\N	t	2025-08-17 01:44:17.635595+00	3	\N	f
324	LSnA3XlM9BVcucDv20eiEN6kplH2	ddd	\N	dd	dd@yaho.com	+15555555555	\N	male	dddd ddd	\N	1	134 W Woodbury Dr	\N	Garland	TX	75041	United States	\N	\N	\N	ddd ddd	324	member	t	pending	2025-09-04 03:16:28.451	2025-09-07 02:55:19.899	yes	1200.00	t	2025-09-07 02:55:19.897+00	3	married	f
323	\N	Elsabeth	Ayalew	Shiferaw	phone_14695545153@phone-signin.local	+14695545153	\N	female	\N	\N	1	\N	\N	\N	TX	\N	USA	\N	\N	\N	\N	323	member	t	pending	2025-09-02 01:24:39.037	2025-09-02 01:24:39.182	maybe	600.00	f	\N	\N	\N	f
322	I24nyqS7tcWYcG8ao4bfajwqsZG3	Chanyalew	\N	Girmay	grchan2@yahoo.com	+14698783472	\N	male	\N	\N	1	305 waterwood	\N	Wylie	Texas	75098	United States	\N	\N	\N	Genet Teklu	322	member	t	pending	2025-08-31 14:53:10.409	2025-09-02 17:58:21.194	maybe	\N	t	2025-08-31 17:23:01.987+00	3	married	f
318	\N	Zafu	\N	Gebreslassie	\N	+19729002581	\N	\N	\N	\N	1	\N	\N	\N	\N	\N	USA	\N	\N	\N	\N	\N	member	t	pending	2025-08-28 03:01:33.346	2025-09-03 01:21:08.034	maybe	\N	t	2025-09-03 01:21:08.034+00	3	\N	t
325	\N	Aida	\N	Kalechirstos	adorsey11@gmail.com	+18584492896	\N	female	Tirsite Mariam	\N	1	205 Lake Ridge 	\N	Prinston	TX	75407	USA	\N	\N	\N	\N	325	member	t	pending	2025-09-07 16:31:38.587	2025-09-07 16:31:38.7	maybe	240.00	f	\N	\N	\N	f
48	95K7ySGDVWglZUOd0UR4Xk4ZKbf2	Fetsum	\N	Biadgelgne	fbiad34@gmail.com	+14698675429	1954-11-04	male	Teklehaimanot	Abune Kerlos	1	609 Sunningdale	\N	Richardson	TX	75081	United States	Aster Abraha	469-422-2131	2025-08-17	\N	\N	member	t	pending	2025-08-02 16:37:00.783	2025-09-07 21:37:51.901	yes	600.00	t	2025-08-17 01:44:17.635595+00	3	married	f
326	\N	Freweyni	\N	Tesfa	phone_12145663500@phone-signin.local	+12145663500	\N	female	\N	\N	1	\N	\N	\N	TX	\N	USA	\N	\N	\N	\N	326	member	t	pending	2025-09-09 21:51:33.567	2025-09-09 21:51:33.701	maybe	600.00	f	\N	\N	\N	f
\.


--
-- TOC entry 4217 (class 0 OID 70305)
-- Dependencies: 286
-- Data for Name: outreach; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outreach (id, member_id, welcomed_by, welcomed_date, note, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4212 (class 0 OID 42512)
-- Dependencies: 281
-- Data for Name: sms_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sms_logs (id, sender_id, role, recipient_type, recipient_member_id, group_id, recipient_count, message, status, error, created_at, updated_at) FROM stdin;
1	3	admin	individual	3	\N	1	Testing individual  text message from Abune Aregawi Church using twillio.	failed	'From' +15005550006 is not a Twilio phone number or Short Code country mismatch	2025-08-18 04:04:31.385+00	2025-08-18 04:04:31.385+00
2	3	admin	individual	3	\N	1	Testing individual  text message from Abune Aregawi Church using twillio.	failed	'From' +15005550006 is not a Twilio phone number or Short Code country mismatch	2025-08-18 04:28:30.824+00	2025-08-18 04:28:30.824+00
3	3	admin	individual	3	\N	1	Testing individual  text message from Abune Aregawi Church using twillio.	success	\N	2025-08-18 04:35:48.383+00	2025-08-18 04:35:48.383+00
4	3	admin	individual	3	\N	1	test message 	failed	'From' +15005550006 is not a Twilio phone number or Short Code country mismatch	2025-08-24 16:37:32.617+00	2025-08-24 16:37:32.617+00
5	3	admin	individual	3	\N	1	Test	failed	'From' +15005550006 is not a Twilio phone number or Short Code country mismatch	2025-08-25 22:01:52.652+00	2025-08-25 22:01:52.652+00
6	3	admin	individual	3	\N	1	Test	failed	'From' +15005550006 is not a Twilio phone number or Short Code country mismatch	2025-08-26 00:59:09.265+00	2025-08-26 00:59:09.265+00
7	3	admin	individual	3	\N	1	Test	failed	'From' +15005550006 is not a Twilio phone number or Short Code country mismatch	2025-08-26 00:59:38.324+00	2025-08-26 00:59:38.324+00
8	3	admin	individual	3	\N	1	Test	success	\N	2025-08-26 01:02:42.08+00	2025-08-26 01:02:42.08+00
9	3	admin	individual	184	\N	1	Testing	failed	'From' +15005550006 is not a Twilio phone number or Short Code country mismatch	2025-08-26 01:11:22.843+00	2025-08-26 01:11:22.843+00
10	3	admin	individual	184	\N	1	Testing	failed	'From' +15005550006 is not a Twilio phone number or Short Code country mismatch	2025-08-26 01:15:14.419+00	2025-08-26 01:15:14.419+00
11	3	admin	individual	184	\N	1	Testing 123	failed	The number +1206235XXXX is unverified. Trial accounts cannot send messages to unverified numbers; verify +1206235XXXX at twilio.com/user/account/phone-numbers/verified, or purchase a Twilio number to send messages to unverified numbers	2025-08-26 01:20:19.372+00	2025-08-26 01:20:19.372+00
12	3	admin	individual	3	\N	1	Testing	success	\N	2025-08-26 01:21:55.523+00	2025-08-26 01:21:55.523+00
13	3	admin	individual	3	\N	1	Test text	success	\N	2025-08-28 04:03:08.756+00	2025-08-28 04:03:08.756+00
14	3	admin	individual	3	\N	1	Test	success	\N	2025-08-30 00:36:32.111+00	2025-08-30 00:36:32.111+00
\.


--
-- TOC entry 4204 (class 0 OID 24473)
-- Dependencies: 273
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.transactions (id, member_id, collected_by, payment_date, amount, payment_type, payment_method, receipt_number, note, created_at, updated_at, external_id, status, donation_id) FROM stdin;
15	189	77	2025-08-27	60.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
16	190	77	2025-08-27	180.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
17	192	77	2025-08-27	600.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
18	89	77	2025-08-27	120.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
19	203	77	2025-08-27	160.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
20	200	77	2025-08-27	60.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
21	214	77	2025-08-27	200.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
22	97	77	2025-08-27	120.00	membership_due	cash	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
23	124	77	2025-08-27	240.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
24	48	77	2025-08-27	100.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
25	48	77	2025-08-27	100.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
26	229	77	2025-08-27	240.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
27	22	77	2025-08-27	210.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
28	255	77	2025-08-27	1200.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
29	61	77	2025-08-27	160.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
30	257	77	2025-08-27	396.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
31	156	77	2025-08-27	800.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
32	262	77	2025-08-27	1200.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
33	53	77	2025-08-27	240.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
34	180	77	2025-08-27	120.00	membership_due	credit_card	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
35	119	77	2025-08-27	1386.00	membership_due	credit_card	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
36	271	77	2025-08-27	270.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
37	272	77	2025-08-27	300.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
38	286	77	2025-08-27	120.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
39	287	77	2025-08-27	360.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
40	289	77	2025-08-27	300.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
41	66	77	2025-08-27	200.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
42	300	77	2025-08-27	600.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
43	297	77	2025-08-27	160.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
44	45	77	2025-08-27	1333.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
45	305	77	2025-08-27	10.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
46	307	77	2025-08-27	120.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
47	308	77	2025-08-27	300.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
48	77	77	2025-08-27	600.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
49	112	77	2025-08-27	200.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
50	320	77	2025-08-27	199.92	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
51	21	77	2025-08-27	180.00	membership_due	other	Imported	Imported from Excel	2025-08-28 03:06:45.763	2025-08-28 03:06:45.768	\N	succeeded	\N
52	173	3	2025-08-24	100.00	membership_due	zelle	\N	DANIEL WELDEMICHAEL	2025-08-29 02:39:22.156	2025-08-29 02:39:22.158	gmail:<376932781.8490825.1756052240798.JavaMail.webuser@iaasn00692058>	succeeded	\N
53	94	3	2025-08-02	100.00	membership_due	zelle	\N	Memo for church ALMAZ G TESFAY member	2025-08-29 13:11:13.061	2025-08-29 13:11:13.063	gmail:<659437400.5401073.1754177067667.JavaMail.webuser@iaasn00692068>	succeeded	\N
54	66	3	2025-08-03	300.00	membership_due	zelle	\N	Memo Membership SOLOMON GEBRESLASIE is registered with a	2025-08-29 13:12:33.425	2025-08-29 13:12:33.426	gmail:<1218678169.6053503.1754231673327.JavaMail.webuser@iaasn00692056>	succeeded	\N
55	258	3	2025-08-17	100.00	membership_due	zelle	\N	Memo Haile and Lemlem LEMLEM SEMERE	2025-08-29 13:14:55.518	2025-08-29 13:14:55.519	gmail:<1640497926.7875546.1755445204879.JavaMail.webuser@iaasn00692073>	succeeded	\N
56	133	3	2025-08-17	1000.00	donation	zelle	\N	Memo Mengistu donation MENGISTU Y ALEMAYEHU is registered	2025-08-29 13:15:44.119	2025-08-29 13:15:44.12	gmail:<1661004184.9105817.1755442980637.JavaMail.webuser@iaasn00692074>	succeeded	\N
57	48	3	2025-08-11	50.00	membership_due	zelle	\N	Memo church due FETSUM BIADGELGNE	2025-08-29 13:17:43.091	2025-08-29 13:17:43.091	gmail:<1084831368.2443686.1754878170175.JavaMail.webuser@iaasn00692074>	succeeded	\N
58	143	3	2025-08-08	400.00	membership_due	zelle	\N	Memo Dawit Abraham &amp; Mebrat Eyasu Payment for August. DAWIT	2025-08-29 13:20:46.466	2025-08-29 13:20:46.466	gmail:<2122886452.7206335.1754675784573.JavaMail.webuser@iaasn00692058>	succeeded	\N
59	137	3	2025-08-15	800.00	membership_due	zelle	\N	Memo February to september member services YIRIGALEM TEFERI is	2025-08-29 13:28:40.276	2025-08-29 13:28:40.276	gmail:<232957555.4140767.1755252830513.JavaMail.webuser@iaasn00692068>	succeeded	\N
60	48	3	2025-08-31	50.00	membership_due	zelle	\N	Memo service FETSUM BIADGELGNE	2025-08-31 16:35:25.3	2025-08-31 16:35:25.302	gmail:<1045422688.5143727.1756648050901.JavaMail.webuser@iaasn00692073>	succeeded	\N
61	78	3	2025-08-31	50.00	membership_due	zelle	\N	Memo membership fee monthly TESHAGER MURUTS is registered with a	2025-08-31 16:37:11.364	2025-08-31 16:37:11.364	gmail:<1864135857.4238469.1756638537378.JavaMail.webuser@iaasn00692071>	succeeded	\N
62	275	3	2025-08-31	50.00	membership_due	zelle	\N	Memo July member fee NEGASH HADGU member	2025-08-31 16:37:42.916	2025-08-31 16:37:42.916	gmail:<1672743435.6699411.1756637382813.JavaMail.webuser@iaasn00692056>	succeeded	\N
63	183	3	2025-08-31	100.00	membership_due	zelle	\N	Memo membership payment Sara Teklu and Dawit Zeweldi DAWIT ZEWELDI	2025-08-31 16:38:05.129	2025-08-31 16:38:05.129	gmail:<499950301.5794931.1756630165929.JavaMail.webuser@iaasn00692074>	succeeded	\N
64	189	77	2025-08-31	20.00	membership_due	cash	5505	Payment is for July and August 2025.	2025-08-31 17:15:03.095	2025-08-31 17:15:03.098	\N	succeeded	\N
65	94	3	2025-09-01	50.00	membership_due	zelle	\N	Memo church ALMAZ G TESFAY member bank	2025-09-02 02:18:44.709	2025-09-02 02:18:44.712	gmail:<1039096605.7422534.1756708240423.JavaMail.webuser@iaasn00692074>	succeeded	\N
66	205	77	2025-09-07	720.00	membership_due	check	5508	Payments for 2024 and 2025.	2025-09-07 15:10:11.963	2025-09-07 15:10:11.965	\N	succeeded	\N
67	96	77	2025-09-07	100.00	membership_due	other	5509	Payment was processed in Square using CC, and it is for Sep 2025.	2025-09-07 15:14:52.315	2025-09-07 15:14:52.316	\N	succeeded	\N
68	143	3	2025-09-04	400.00	membership_due	zelle	\N	Memo Dawit Abraham &amp; Mebrat Eyasu Payment for September 2025.	2025-09-07 16:02:44.927	2025-09-07 16:02:44.929	gmail:<1043434504.1723702.1757008899530.JavaMail.webuser@iaasn00692068>	succeeded	\N
69	57	77	2025-09-07	30.00	membership_due	cash	5512	Payment for Sep 2025.	2025-09-07 16:21:12.004	2025-09-07 16:21:12.005	\N	succeeded	\N
70	182	3	2025-09-07	300.00	donation	zelle	\N	Memo Visiting Guest Memher YESHI ZERIHUN	2025-09-07 21:41:28.339	2025-09-07 21:41:28.339	gmail:<119188548.6424340.1757270881443.JavaMail.webuser@iaasn00692074>	succeeded	\N
71	3	3	2025-09-08	1.00	donation	credit_card		Validating production stripe payment with real card	2025-09-09 02:49:10.324	2025-09-09 02:49:10.97	pi_3S5HcF1Y4tq8nVje1mN05gbg	succeeded	20
\.


--
-- TOC entry 4215 (class 0 OID 57007)
-- Dependencies: 284
-- Data for Name: zelle_memo_matches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.zelle_memo_matches (id, member_id, first_name, last_name, memo, created_at, updated_at) FROM stdin;
675bd84b-517c-4e6b-a86c-9d990ff1ea95	173	Daniel	Weldemichael	DANIEL WELDEMICHAEL	2025-08-29 02:39:22.452+00	2025-08-29 02:39:22.452+00
0efd2850-68e5-47a9-aee8-51fedde3a6e9	94	Almaz	Tesfay	Memo for church ALMAZ G TESFAY member	2025-08-29 13:11:13.338+00	2025-08-29 13:11:13.338+00
70bd465b-db1f-41a8-a4e8-324b17a84a5d	66	Solomon	Gebreslasie	Memo Membership SOLOMON GEBRESLASIE is registered with a	2025-08-29 13:12:34.208+00	2025-08-29 13:12:34.208+00
08ed6574-5473-4037-91cf-194fa42b1d1e	258	Lemlem	Semere	Memo Haile and Lemlem LEMLEM SEMERE	2025-08-29 13:14:55.719+00	2025-08-29 13:14:55.719+00
ed523798-4477-4675-96c8-10c7479fd2d2	133	Mengistu	Alemayehu	Memo Mengistu donation MENGISTU Y ALEMAYEHU is registered	2025-08-29 13:15:44.352+00	2025-08-29 13:15:44.352+00
d4145e7e-8828-441a-bd00-d4a423ae8401	48	Fetsum	Biadgelgne	Memo church due FETSUM BIADGELGNE	2025-08-29 13:17:43.309+00	2025-08-29 13:17:43.309+00
d2e69229-3dd3-4dfe-a74c-7e1bac2aa3b1	143	Dawit	Abraham	Memo Dawit Abraham &amp; Mebrat Eyasu Payment for August. DAWIT	2025-08-29 13:20:46.999+00	2025-08-29 13:20:46.999+00
92c53953-7d8b-4727-8bea-84a32c5330e3	137	Yirgalem	Teferi	Memo February to september member services YIRIGALEM TEFERI is	2025-08-29 13:28:40.5+00	2025-08-29 13:28:40.5+00
860d8805-7d0d-41f0-aaf3-2617060fa9a6	48	Fetsum	Biadgelgne	Memo service FETSUM BIADGELGNE	2025-08-31 16:35:25.584+00	2025-08-31 16:35:25.584+00
fdefb8d8-154e-4fb5-a8b3-5d754bdb96c4	78	Teshager	Muruts	Memo membership fee monthly TESHAGER MURUTS is registered with a	2025-08-31 16:37:11.58+00	2025-08-31 16:37:11.58+00
9ad2146c-a8c2-43d2-84b1-164332b3595f	275	Negash	Hadgu	Memo July member fee NEGASH HADGU member	2025-08-31 16:37:43.132+00	2025-08-31 16:37:43.132+00
d65765ef-4edf-40ca-a563-dabe894acfd3	183	Dawit	Zeweldi	Memo membership payment Sara Teklu and Dawit Zeweldi DAWIT ZEWELDI	2025-08-31 16:38:05.346+00	2025-08-31 16:38:05.346+00
c281eea8-3c35-4caa-9b22-6cfc2da35b9a	94	Almaz	Tesfay	Memo church ALMAZ G TESFAY member bank	2025-09-02 02:18:44.98+00	2025-09-02 02:18:44.98+00
d99ea36f-7a71-42dc-a9f7-f1a7a6edf254	143	Dawit	Abraham	Memo Dawit Abraham &amp; Mebrat Eyasu Payment for September 2025.	2025-09-07 16:02:45.176+00	2025-09-07 16:02:45.176+00
f02283fb-c0ac-45e7-9cbf-0bc47bfc6d29	182	YESHI	ZERIHUN	Memo Visiting Guest Memher YESHI ZERIHUN	2025-09-07 21:41:28.617+00	2025-09-07 21:41:28.617+00
\.


--
-- TOC entry 4192 (class 0 OID 17089)
-- Dependencies: 257
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.schema_migrations (version, inserted_at) FROM stdin;
20211116024918	2025-07-28 15:50:07
20211116045059	2025-07-28 15:50:09
20211116050929	2025-07-28 15:50:11
20211116051442	2025-07-28 15:50:13
20211116212300	2025-07-28 15:50:15
20211116213355	2025-07-28 15:50:16
20211116213934	2025-07-28 15:50:18
20211116214523	2025-07-28 15:50:21
20211122062447	2025-07-28 15:50:22
20211124070109	2025-07-28 15:50:24
20211202204204	2025-07-28 15:50:26
20211202204605	2025-07-28 15:50:27
20211210212804	2025-07-28 15:50:33
20211228014915	2025-07-28 15:50:35
20220107221237	2025-07-28 15:50:36
20220228202821	2025-07-28 15:50:38
20220312004840	2025-07-28 15:50:40
20220603231003	2025-07-28 15:50:43
20220603232444	2025-07-28 15:50:44
20220615214548	2025-07-28 15:50:46
20220712093339	2025-07-28 15:50:48
20220908172859	2025-07-28 15:50:50
20220916233421	2025-07-28 15:50:51
20230119133233	2025-07-28 15:50:53
20230128025114	2025-07-28 15:50:56
20230128025212	2025-07-28 15:50:57
20230227211149	2025-07-28 15:50:59
20230228184745	2025-07-28 15:51:01
20230308225145	2025-07-28 15:51:02
20230328144023	2025-07-28 15:51:04
20231018144023	2025-07-28 15:51:06
20231204144023	2025-07-28 15:51:09
20231204144024	2025-07-28 15:51:11
20231204144025	2025-07-28 15:51:12
20240108234812	2025-07-28 15:51:14
20240109165339	2025-07-28 15:51:16
20240227174441	2025-07-28 15:51:19
20240311171622	2025-07-28 15:51:21
20240321100241	2025-07-28 15:51:25
20240401105812	2025-07-28 15:51:30
20240418121054	2025-07-28 15:51:32
20240523004032	2025-07-28 15:51:39
20240618124746	2025-07-28 15:51:40
20240801235015	2025-07-28 15:51:42
20240805133720	2025-07-28 15:51:44
20240827160934	2025-07-28 15:51:45
20240919163303	2025-07-28 15:51:48
20240919163305	2025-07-28 15:51:50
20241019105805	2025-07-28 15:51:51
20241030150047	2025-07-28 15:51:58
20241108114728	2025-07-28 15:52:00
20241121104152	2025-07-28 15:52:02
20241130184212	2025-07-28 15:52:04
20241220035512	2025-07-28 15:52:06
20241220123912	2025-07-28 15:52:07
20241224161212	2025-07-28 15:52:09
20250107150512	2025-07-28 15:52:11
20250110162412	2025-07-28 15:52:13
20250123174212	2025-07-28 15:52:14
20250128220012	2025-07-28 15:52:16
20250506224012	2025-07-28 15:52:17
20250523164012	2025-07-28 15:52:19
20250714121412	2025-07-28 15:52:21
\.


--
-- TOC entry 4194 (class 0 OID 17111)
-- Dependencies: 260
-- Data for Name: subscription; Type: TABLE DATA; Schema: realtime; Owner: -
--

COPY realtime.subscription (id, subscription_id, entity, filters, claims, created_at) FROM stdin;
\.


--
-- TOC entry 4176 (class 0 OID 16544)
-- Dependencies: 238
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets (id, name, owner, created_at, updated_at, public, avif_autodetection, file_size_limit, allowed_mime_types, owner_id, type) FROM stdin;
\.


--
-- TOC entry 4214 (class 0 OID 56990)
-- Dependencies: 283
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.buckets_analytics (id, type, format, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4178 (class 0 OID 16586)
-- Dependencies: 240
-- Data for Name: migrations; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.migrations (id, name, hash, executed_at) FROM stdin;
0	create-migrations-table	e18db593bcde2aca2a408c4d1100f6abba2195df	2025-07-28 15:48:28.399134
1	initialmigration	6ab16121fbaa08bbd11b712d05f358f9b555d777	2025-07-28 15:48:28.42243
2	storage-schema	5c7968fd083fcea04050c1b7f6253c9771b99011	2025-07-28 15:48:28.425528
3	pathtoken-column	2cb1b0004b817b29d5b0a971af16bafeede4b70d	2025-07-28 15:48:28.469253
4	add-migrations-rls	427c5b63fe1c5937495d9c635c263ee7a5905058	2025-07-28 15:48:28.488144
5	add-size-functions	79e081a1455b63666c1294a440f8ad4b1e6a7f84	2025-07-28 15:48:28.490553
6	change-column-name-in-get-size	f93f62afdf6613ee5e7e815b30d02dc990201044	2025-07-28 15:48:28.49411
7	add-rls-to-buckets	e7e7f86adbc51049f341dfe8d30256c1abca17aa	2025-07-28 15:48:28.498009
8	add-public-to-buckets	fd670db39ed65f9d08b01db09d6202503ca2bab3	2025-07-28 15:48:28.500713
9	fix-search-function	3a0af29f42e35a4d101c259ed955b67e1bee6825	2025-07-28 15:48:28.503572
10	search-files-search-function	68dc14822daad0ffac3746a502234f486182ef6e	2025-07-28 15:48:28.508565
11	add-trigger-to-auto-update-updated_at-column	7425bdb14366d1739fa8a18c83100636d74dcaa2	2025-07-28 15:48:28.511616
12	add-automatic-avif-detection-flag	8e92e1266eb29518b6a4c5313ab8f29dd0d08df9	2025-07-28 15:48:28.517997
13	add-bucket-custom-limits	cce962054138135cd9a8c4bcd531598684b25e7d	2025-07-28 15:48:28.52078
14	use-bytes-for-max-size	941c41b346f9802b411f06f30e972ad4744dad27	2025-07-28 15:48:28.525631
15	add-can-insert-object-function	934146bc38ead475f4ef4b555c524ee5d66799e5	2025-07-28 15:48:28.554519
16	add-version	76debf38d3fd07dcfc747ca49096457d95b1221b	2025-07-28 15:48:28.559972
17	drop-owner-foreign-key	f1cbb288f1b7a4c1eb8c38504b80ae2a0153d101	2025-07-28 15:48:28.562648
18	add_owner_id_column_deprecate_owner	e7a511b379110b08e2f214be852c35414749fe66	2025-07-28 15:48:28.568972
19	alter-default-value-objects-id	02e5e22a78626187e00d173dc45f58fa66a4f043	2025-07-28 15:48:28.574364
20	list-objects-with-delimiter	cd694ae708e51ba82bf012bba00caf4f3b6393b7	2025-07-28 15:48:28.577401
21	s3-multipart-uploads	8c804d4a566c40cd1e4cc5b3725a664a9303657f	2025-07-28 15:48:28.584055
22	s3-multipart-uploads-big-ints	9737dc258d2397953c9953d9b86920b8be0cdb73	2025-07-28 15:48:28.601034
23	optimize-search-function	9d7e604cddc4b56a5422dc68c9313f4a1b6f132c	2025-07-28 15:48:28.611442
24	operation-function	8312e37c2bf9e76bbe841aa5fda889206d2bf8aa	2025-07-28 15:48:28.616708
25	custom-metadata	d974c6057c3db1c1f847afa0e291e6165693b990	2025-07-28 15:48:28.621261
26	objects-prefixes	ef3f7871121cdc47a65308e6702519e853422ae2	2025-08-28 05:55:08.159959
27	search-v2	33b8f2a7ae53105f028e13e9fcda9dc4f356b4a2	2025-08-28 05:55:08.351205
28	object-bucket-name-sorting	ba85ec41b62c6a30a3f136788227ee47f311c436	2025-08-28 05:55:08.437071
29	create-prefixes	a7b1a22c0dc3ab630e3055bfec7ce7d2045c5b7b	2025-08-28 05:55:08.525193
30	update-object-levels	6c6f6cc9430d570f26284a24cf7b210599032db7	2025-08-28 05:55:08.56206
31	objects-level-index	33f1fef7ec7fea08bb892222f4f0f5d79bab5eb8	2025-08-28 05:55:08.585065
32	backward-compatible-index-on-objects	2d51eeb437a96868b36fcdfb1ddefdf13bef1647	2025-08-28 05:55:08.603538
33	backward-compatible-index-on-prefixes	fe473390e1b8c407434c0e470655945b110507bf	2025-08-28 05:55:08.645186
34	optimize-search-function-v1	82b0e469a00e8ebce495e29bfa70a0797f7ebd2c	2025-08-28 05:55:08.661966
35	add-insert-trigger-prefixes	63bb9fd05deb3dc5e9fa66c83e82b152f0caf589	2025-08-28 05:55:08.749592
36	optimise-existing-functions	81cf92eb0c36612865a18016a38496c530443899	2025-08-28 05:55:08.849134
37	add-bucket-name-length-trigger	3944135b4e3e8b22d6d4cbb568fe3b0b51df15c1	2025-08-28 05:55:08.93797
38	iceberg-catalog-flag-on-buckets	19a8bd89d5dfa69af7f222a46c726b7c41e462c5	2025-08-28 05:55:08.975142
\.


--
-- TOC entry 4177 (class 0 OID 16559)
-- Dependencies: 239
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.objects (id, bucket_id, name, owner, created_at, updated_at, last_accessed_at, metadata, version, owner_id, user_metadata, level) FROM stdin;
\.


--
-- TOC entry 4213 (class 0 OID 56946)
-- Dependencies: 282
-- Data for Name: prefixes; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.prefixes (bucket_id, name, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4190 (class 0 OID 17032)
-- Dependencies: 255
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads (id, in_progress_size, upload_signature, bucket_id, key, version, owner_id, created_at, user_metadata) FROM stdin;
\.


--
-- TOC entry 4191 (class 0 OID 17046)
-- Dependencies: 256
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: -
--

COPY storage.s3_multipart_uploads_parts (id, upload_id, size, part_number, bucket_id, key, etag, owner_id, version, created_at) FROM stdin;
\.


--
-- TOC entry 3655 (class 0 OID 16656)
-- Dependencies: 241
-- Data for Name: secrets; Type: TABLE DATA; Schema: vault; Owner: -
--

COPY vault.secrets (id, name, description, secret, key_id, nonce, created_at, updated_at) FROM stdin;
\.


--
-- TOC entry 4270 (class 0 OID 0)
-- Dependencies: 233
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: -
--

SELECT pg_catalog.setval('auth.refresh_tokens_id_seq', 1, false);


--
-- TOC entry 4271 (class 0 OID 0)
-- Dependencies: 270
-- Name: dependents_new_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.dependents_new_id_seq', 27, true);


--
-- TOC entry 4272 (class 0 OID 0)
-- Dependencies: 274
-- Name: donations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.donations_id_seq', 20, true);


--
-- TOC entry 4273 (class 0 OID 0)
-- Dependencies: 276
-- Name: groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.groups_id_seq', 1, false);


--
-- TOC entry 4274 (class 0 OID 0)
-- Dependencies: 278
-- Name: member_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_groups_id_seq', 1, false);


--
-- TOC entry 4275 (class 0 OID 0)
-- Dependencies: 264
-- Name: member_payments_2024_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.member_payments_2024_id_seq', 374, true);


--
-- TOC entry 4276 (class 0 OID 0)
-- Dependencies: 268
-- Name: members_new_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.members_new_id_seq', 326, true);


--
-- TOC entry 4277 (class 0 OID 0)
-- Dependencies: 280
-- Name: sms_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.sms_logs_id_seq', 14, true);


--
-- TOC entry 4278 (class 0 OID 0)
-- Dependencies: 272
-- Name: transactions_new_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.transactions_new_id_seq', 71, true);


--
-- TOC entry 4279 (class 0 OID 0)
-- Dependencies: 259
-- Name: subscription_id_seq; Type: SEQUENCE SET; Schema: realtime; Owner: -
--

SELECT pg_catalog.setval('realtime.subscription_id_seq', 1, false);


--
-- TOC entry 3824 (class 2606 OID 16825)
-- Name: mfa_amr_claims amr_id_pk; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT amr_id_pk PRIMARY KEY (id);


--
-- TOC entry 3779 (class 2606 OID 16529)
-- Name: audit_log_entries audit_log_entries_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.audit_log_entries
    ADD CONSTRAINT audit_log_entries_pkey PRIMARY KEY (id);


--
-- TOC entry 3847 (class 2606 OID 16931)
-- Name: flow_state flow_state_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.flow_state
    ADD CONSTRAINT flow_state_pkey PRIMARY KEY (id);


--
-- TOC entry 3803 (class 2606 OID 16949)
-- Name: identities identities_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_pkey PRIMARY KEY (id);


--
-- TOC entry 3805 (class 2606 OID 16959)
-- Name: identities identities_provider_id_provider_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_provider_id_provider_unique UNIQUE (provider_id, provider);


--
-- TOC entry 3777 (class 2606 OID 16522)
-- Name: instances instances_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.instances
    ADD CONSTRAINT instances_pkey PRIMARY KEY (id);


--
-- TOC entry 3826 (class 2606 OID 16818)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_authentication_method_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_authentication_method_pkey UNIQUE (session_id, authentication_method);


--
-- TOC entry 3822 (class 2606 OID 16806)
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- TOC entry 3814 (class 2606 OID 16999)
-- Name: mfa_factors mfa_factors_last_challenged_at_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_last_challenged_at_key UNIQUE (last_challenged_at);


--
-- TOC entry 3816 (class 2606 OID 16793)
-- Name: mfa_factors mfa_factors_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_pkey PRIMARY KEY (id);


--
-- TOC entry 3953 (class 2606 OID 63672)
-- Name: oauth_clients oauth_clients_client_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_client_id_key UNIQUE (client_id);


--
-- TOC entry 3956 (class 2606 OID 63670)
-- Name: oauth_clients oauth_clients_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.oauth_clients
    ADD CONSTRAINT oauth_clients_pkey PRIMARY KEY (id);


--
-- TOC entry 3851 (class 2606 OID 16984)
-- Name: one_time_tokens one_time_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3771 (class 2606 OID 16512)
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- TOC entry 3774 (class 2606 OID 16736)
-- Name: refresh_tokens refresh_tokens_token_unique; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_token_unique UNIQUE (token);


--
-- TOC entry 3836 (class 2606 OID 16865)
-- Name: saml_providers saml_providers_entity_id_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_entity_id_key UNIQUE (entity_id);


--
-- TOC entry 3838 (class 2606 OID 16863)
-- Name: saml_providers saml_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 3843 (class 2606 OID 16879)
-- Name: saml_relay_states saml_relay_states_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_pkey PRIMARY KEY (id);


--
-- TOC entry 3782 (class 2606 OID 16535)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 3809 (class 2606 OID 16757)
-- Name: sessions sessions_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_pkey PRIMARY KEY (id);


--
-- TOC entry 3833 (class 2606 OID 16846)
-- Name: sso_domains sso_domains_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_pkey PRIMARY KEY (id);


--
-- TOC entry 3828 (class 2606 OID 16837)
-- Name: sso_providers sso_providers_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_providers
    ADD CONSTRAINT sso_providers_pkey PRIMARY KEY (id);


--
-- TOC entry 3764 (class 2606 OID 16919)
-- Name: users users_phone_key; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_phone_key UNIQUE (phone);


--
-- TOC entry 3766 (class 2606 OID 16499)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3871 (class 2606 OID 22899)
-- Name: SequelizeMeta SequelizeMeta_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public."SequelizeMeta"
    ADD CONSTRAINT "SequelizeMeta_pkey" PRIMARY KEY (name);


--
-- TOC entry 3878 (class 2606 OID 22941)
-- Name: church_transactions church_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.church_transactions
    ADD CONSTRAINT church_transactions_pkey PRIMARY KEY (id);


--
-- TOC entry 3902 (class 2606 OID 24465)
-- Name: dependents dependents_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dependents
    ADD CONSTRAINT dependents_new_pkey PRIMARY KEY (id);


--
-- TOC entry 3923 (class 2606 OID 30249)
-- Name: donations donations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT donations_pkey PRIMARY KEY (id);


--
-- TOC entry 3927 (class 2606 OID 30251)
-- Name: donations donations_stripe_payment_intent_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.donations
    ADD CONSTRAINT donations_stripe_payment_intent_id_key UNIQUE (stripe_payment_intent_id);


--
-- TOC entry 3929 (class 2606 OID 42478)
-- Name: groups groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.groups
    ADD CONSTRAINT groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3933 (class 2606 OID 42485)
-- Name: member_groups member_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_groups
    ADD CONSTRAINT member_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3869 (class 2606 OID 17364)
-- Name: member_payments_2024 member_payments_2024_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_payments_2024
    ADD CONSTRAINT member_payments_2024_pkey PRIMARY KEY (id);


--
-- TOC entry 3885 (class 2606 OID 24442)
-- Name: members members_new_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_new_email_key UNIQUE (email);


--
-- TOC entry 3889 (class 2606 OID 24440)
-- Name: members members_new_firebase_uid_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_new_firebase_uid_key UNIQUE (firebase_uid);


--
-- TOC entry 3893 (class 2606 OID 24444)
-- Name: members members_new_phone_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_new_phone_number_key UNIQUE (phone_number);


--
-- TOC entry 3895 (class 2606 OID 24438)
-- Name: members members_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_new_pkey PRIMARY KEY (id);


--
-- TOC entry 3959 (class 2606 OID 70315)
-- Name: outreach outreach_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outreach
    ADD CONSTRAINT outreach_pkey PRIMARY KEY (id);


--
-- TOC entry 3937 (class 2606 OID 42520)
-- Name: sms_logs sms_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_pkey PRIMARY KEY (id);


--
-- TOC entry 3915 (class 2606 OID 24484)
-- Name: transactions transactions_new_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_new_pkey PRIMARY KEY (id);


--
-- TOC entry 3935 (class 2606 OID 57004)
-- Name: member_groups uq_member_groups_member_group; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_groups
    ADD CONSTRAINT uq_member_groups_member_group UNIQUE (member_id, group_id);


--
-- TOC entry 3948 (class 2606 OID 57022)
-- Name: zelle_memo_matches zelle_memo_matches_memo_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zelle_memo_matches
    ADD CONSTRAINT zelle_memo_matches_memo_unique UNIQUE (memo);


--
-- TOC entry 3950 (class 2606 OID 57013)
-- Name: zelle_memo_matches zelle_memo_matches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zelle_memo_matches
    ADD CONSTRAINT zelle_memo_matches_pkey PRIMARY KEY (id);


--
-- TOC entry 3867 (class 2606 OID 17265)
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id, inserted_at);


--
-- TOC entry 3864 (class 2606 OID 17119)
-- Name: subscription pk_subscription; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.subscription
    ADD CONSTRAINT pk_subscription PRIMARY KEY (id);


--
-- TOC entry 3861 (class 2606 OID 17093)
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: realtime; Owner: -
--

ALTER TABLE ONLY realtime.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (version);


--
-- TOC entry 3944 (class 2606 OID 57000)
-- Name: buckets_analytics buckets_analytics_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets_analytics
    ADD CONSTRAINT buckets_analytics_pkey PRIMARY KEY (id);


--
-- TOC entry 3785 (class 2606 OID 16552)
-- Name: buckets buckets_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.buckets
    ADD CONSTRAINT buckets_pkey PRIMARY KEY (id);


--
-- TOC entry 3795 (class 2606 OID 16593)
-- Name: migrations migrations_name_key; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_name_key UNIQUE (name);


--
-- TOC entry 3797 (class 2606 OID 16591)
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3793 (class 2606 OID 16569)
-- Name: objects objects_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT objects_pkey PRIMARY KEY (id);


--
-- TOC entry 3942 (class 2606 OID 56955)
-- Name: prefixes prefixes_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT prefixes_pkey PRIMARY KEY (bucket_id, level, name);


--
-- TOC entry 3859 (class 2606 OID 17055)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_pkey PRIMARY KEY (id);


--
-- TOC entry 3857 (class 2606 OID 17040)
-- Name: s3_multipart_uploads s3_multipart_uploads_pkey; Type: CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_pkey PRIMARY KEY (id);


--
-- TOC entry 3780 (class 1259 OID 16530)
-- Name: audit_logs_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX audit_logs_instance_id_idx ON auth.audit_log_entries USING btree (instance_id);


--
-- TOC entry 3754 (class 1259 OID 16746)
-- Name: confirmation_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX confirmation_token_idx ON auth.users USING btree (confirmation_token) WHERE ((confirmation_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3755 (class 1259 OID 16748)
-- Name: email_change_token_current_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_current_idx ON auth.users USING btree (email_change_token_current) WHERE ((email_change_token_current)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3756 (class 1259 OID 16749)
-- Name: email_change_token_new_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX email_change_token_new_idx ON auth.users USING btree (email_change_token_new) WHERE ((email_change_token_new)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3812 (class 1259 OID 16827)
-- Name: factor_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX factor_id_created_at_idx ON auth.mfa_factors USING btree (user_id, created_at);


--
-- TOC entry 3845 (class 1259 OID 16935)
-- Name: flow_state_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX flow_state_created_at_idx ON auth.flow_state USING btree (created_at DESC);


--
-- TOC entry 3801 (class 1259 OID 16915)
-- Name: identities_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_email_idx ON auth.identities USING btree (email text_pattern_ops);


--
-- TOC entry 4280 (class 0 OID 0)
-- Dependencies: 3801
-- Name: INDEX identities_email_idx; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.identities_email_idx IS 'Auth: Ensures indexed queries on the email column';


--
-- TOC entry 3806 (class 1259 OID 16743)
-- Name: identities_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX identities_user_id_idx ON auth.identities USING btree (user_id);


--
-- TOC entry 3848 (class 1259 OID 16932)
-- Name: idx_auth_code; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_auth_code ON auth.flow_state USING btree (auth_code);


--
-- TOC entry 3849 (class 1259 OID 16933)
-- Name: idx_user_id_auth_method; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX idx_user_id_auth_method ON auth.flow_state USING btree (user_id, authentication_method);


--
-- TOC entry 3820 (class 1259 OID 16938)
-- Name: mfa_challenge_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_challenge_created_at_idx ON auth.mfa_challenges USING btree (created_at DESC);


--
-- TOC entry 3817 (class 1259 OID 16799)
-- Name: mfa_factors_user_friendly_name_unique; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX mfa_factors_user_friendly_name_unique ON auth.mfa_factors USING btree (friendly_name, user_id) WHERE (TRIM(BOTH FROM friendly_name) <> ''::text);


--
-- TOC entry 3818 (class 1259 OID 16944)
-- Name: mfa_factors_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX mfa_factors_user_id_idx ON auth.mfa_factors USING btree (user_id);


--
-- TOC entry 3951 (class 1259 OID 63673)
-- Name: oauth_clients_client_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_client_id_idx ON auth.oauth_clients USING btree (client_id);


--
-- TOC entry 3954 (class 1259 OID 63674)
-- Name: oauth_clients_deleted_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX oauth_clients_deleted_at_idx ON auth.oauth_clients USING btree (deleted_at);


--
-- TOC entry 3852 (class 1259 OID 16991)
-- Name: one_time_tokens_relates_to_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_relates_to_hash_idx ON auth.one_time_tokens USING hash (relates_to);


--
-- TOC entry 3853 (class 1259 OID 16990)
-- Name: one_time_tokens_token_hash_hash_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX one_time_tokens_token_hash_hash_idx ON auth.one_time_tokens USING hash (token_hash);


--
-- TOC entry 3854 (class 1259 OID 16992)
-- Name: one_time_tokens_user_id_token_type_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX one_time_tokens_user_id_token_type_key ON auth.one_time_tokens USING btree (user_id, token_type);


--
-- TOC entry 3757 (class 1259 OID 16750)
-- Name: reauthentication_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX reauthentication_token_idx ON auth.users USING btree (reauthentication_token) WHERE ((reauthentication_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3758 (class 1259 OID 16747)
-- Name: recovery_token_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX recovery_token_idx ON auth.users USING btree (recovery_token) WHERE ((recovery_token)::text !~ '^[0-9 ]*$'::text);


--
-- TOC entry 3767 (class 1259 OID 16513)
-- Name: refresh_tokens_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_idx ON auth.refresh_tokens USING btree (instance_id);


--
-- TOC entry 3768 (class 1259 OID 16514)
-- Name: refresh_tokens_instance_id_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_instance_id_user_id_idx ON auth.refresh_tokens USING btree (instance_id, user_id);


--
-- TOC entry 3769 (class 1259 OID 16742)
-- Name: refresh_tokens_parent_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_parent_idx ON auth.refresh_tokens USING btree (parent);


--
-- TOC entry 3772 (class 1259 OID 16829)
-- Name: refresh_tokens_session_id_revoked_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_session_id_revoked_idx ON auth.refresh_tokens USING btree (session_id, revoked);


--
-- TOC entry 3775 (class 1259 OID 16934)
-- Name: refresh_tokens_updated_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX refresh_tokens_updated_at_idx ON auth.refresh_tokens USING btree (updated_at DESC);


--
-- TOC entry 3839 (class 1259 OID 16871)
-- Name: saml_providers_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_providers_sso_provider_id_idx ON auth.saml_providers USING btree (sso_provider_id);


--
-- TOC entry 3840 (class 1259 OID 16936)
-- Name: saml_relay_states_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_created_at_idx ON auth.saml_relay_states USING btree (created_at DESC);


--
-- TOC entry 3841 (class 1259 OID 16886)
-- Name: saml_relay_states_for_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_for_email_idx ON auth.saml_relay_states USING btree (for_email);


--
-- TOC entry 3844 (class 1259 OID 16885)
-- Name: saml_relay_states_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX saml_relay_states_sso_provider_id_idx ON auth.saml_relay_states USING btree (sso_provider_id);


--
-- TOC entry 3807 (class 1259 OID 16937)
-- Name: sessions_not_after_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_not_after_idx ON auth.sessions USING btree (not_after DESC);


--
-- TOC entry 3810 (class 1259 OID 16828)
-- Name: sessions_user_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sessions_user_id_idx ON auth.sessions USING btree (user_id);


--
-- TOC entry 3831 (class 1259 OID 16853)
-- Name: sso_domains_domain_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_domains_domain_idx ON auth.sso_domains USING btree (lower(domain));


--
-- TOC entry 3834 (class 1259 OID 16852)
-- Name: sso_domains_sso_provider_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_domains_sso_provider_id_idx ON auth.sso_domains USING btree (sso_provider_id);


--
-- TOC entry 3829 (class 1259 OID 16838)
-- Name: sso_providers_resource_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX sso_providers_resource_id_idx ON auth.sso_providers USING btree (lower(resource_id));


--
-- TOC entry 3830 (class 1259 OID 43631)
-- Name: sso_providers_resource_id_pattern_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX sso_providers_resource_id_pattern_idx ON auth.sso_providers USING btree (resource_id text_pattern_ops);


--
-- TOC entry 3819 (class 1259 OID 16997)
-- Name: unique_phone_factor_per_user; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX unique_phone_factor_per_user ON auth.mfa_factors USING btree (user_id, phone);


--
-- TOC entry 3811 (class 1259 OID 16826)
-- Name: user_id_created_at_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX user_id_created_at_idx ON auth.sessions USING btree (user_id, created_at);


--
-- TOC entry 3759 (class 1259 OID 16906)
-- Name: users_email_partial_key; Type: INDEX; Schema: auth; Owner: -
--

CREATE UNIQUE INDEX users_email_partial_key ON auth.users USING btree (email) WHERE (is_sso_user = false);


--
-- TOC entry 4281 (class 0 OID 0)
-- Dependencies: 3759
-- Name: INDEX users_email_partial_key; Type: COMMENT; Schema: auth; Owner: -
--

COMMENT ON INDEX auth.users_email_partial_key IS 'Auth: A partial unique index that applies only when is_sso_user is false';


--
-- TOC entry 3760 (class 1259 OID 16744)
-- Name: users_instance_id_email_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_email_idx ON auth.users USING btree (instance_id, lower((email)::text));


--
-- TOC entry 3761 (class 1259 OID 16503)
-- Name: users_instance_id_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_instance_id_idx ON auth.users USING btree (instance_id);


--
-- TOC entry 3762 (class 1259 OID 16961)
-- Name: users_is_anonymous_idx; Type: INDEX; Schema: auth; Owner: -
--

CREATE INDEX users_is_anonymous_idx ON auth.users USING btree (is_anonymous);


--
-- TOC entry 3872 (class 1259 OID 22953)
-- Name: church_transactions_collected_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX church_transactions_collected_by ON public.church_transactions USING btree (collected_by);


--
-- TOC entry 3873 (class 1259 OID 22952)
-- Name: church_transactions_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX church_transactions_member_id ON public.church_transactions USING btree (member_id);


--
-- TOC entry 3874 (class 1259 OID 22954)
-- Name: church_transactions_payment_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX church_transactions_payment_date ON public.church_transactions USING btree (payment_date);


--
-- TOC entry 3875 (class 1259 OID 22956)
-- Name: church_transactions_payment_method; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX church_transactions_payment_method ON public.church_transactions USING btree (payment_method);


--
-- TOC entry 3876 (class 1259 OID 22955)
-- Name: church_transactions_payment_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX church_transactions_payment_type ON public.church_transactions USING btree (payment_type);


--
-- TOC entry 3899 (class 1259 OID 24533)
-- Name: dependents_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dependents_member_id ON public.dependents USING btree (member_id);


--
-- TOC entry 3900 (class 1259 OID 24471)
-- Name: dependents_new_member_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX dependents_new_member_id_idx ON public.dependents USING btree (member_id);


--
-- TOC entry 3920 (class 1259 OID 30255)
-- Name: donations_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX donations_created_at ON public.donations USING btree (created_at);


--
-- TOC entry 3921 (class 1259 OID 30253)
-- Name: donations_donor_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX donations_donor_email ON public.donations USING btree (donor_email);


--
-- TOC entry 3924 (class 1259 OID 30254)
-- Name: donations_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX donations_status ON public.donations USING btree (status);


--
-- TOC entry 3925 (class 1259 OID 30252)
-- Name: donations_stripe_payment_intent_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX donations_stripe_payment_intent_id ON public.donations USING btree (stripe_payment_intent_id);


--
-- TOC entry 3903 (class 1259 OID 49162)
-- Name: idx_dependents_linked_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dependents_linked_member_id ON public.dependents USING btree (linked_member_id);


--
-- TOC entry 3930 (class 1259 OID 57001)
-- Name: member_groups_group_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_groups_group_id ON public.member_groups USING btree (group_id);


--
-- TOC entry 3931 (class 1259 OID 57002)
-- Name: member_groups_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX member_groups_member_id ON public.member_groups USING btree (member_id);


--
-- TOC entry 3879 (class 1259 OID 24519)
-- Name: members_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_email ON public.members USING btree (email);


--
-- TOC entry 3880 (class 1259 OID 24524)
-- Name: members_family_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_family_id ON public.members USING btree (family_id);


--
-- TOC entry 3881 (class 1259 OID 24521)
-- Name: members_firebase_uid; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_firebase_uid ON public.members USING btree (firebase_uid);


--
-- TOC entry 3882 (class 1259 OID 24523)
-- Name: members_is_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_is_active ON public.members USING btree (is_active);


--
-- TOC entry 3883 (class 1259 OID 24450)
-- Name: members_new_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_new_email_idx ON public.members USING btree (email);


--
-- TOC entry 3886 (class 1259 OID 24455)
-- Name: members_new_family_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_new_family_id_idx ON public.members USING btree (family_id);


--
-- TOC entry 3887 (class 1259 OID 24452)
-- Name: members_new_firebase_uid_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_new_firebase_uid_idx ON public.members USING btree (firebase_uid);


--
-- TOC entry 3890 (class 1259 OID 24454)
-- Name: members_new_is_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_new_is_active_idx ON public.members USING btree (is_active);


--
-- TOC entry 3891 (class 1259 OID 24451)
-- Name: members_new_phone_number_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_new_phone_number_idx ON public.members USING btree (phone_number);


--
-- TOC entry 3896 (class 1259 OID 24453)
-- Name: members_new_role_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_new_role_idx ON public.members USING btree (role);


--
-- TOC entry 3897 (class 1259 OID 24520)
-- Name: members_phone_number; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_phone_number ON public.members USING btree (phone_number);


--
-- TOC entry 3898 (class 1259 OID 24522)
-- Name: members_role; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX members_role ON public.members USING btree (role);


--
-- TOC entry 3957 (class 1259 OID 70321)
-- Name: outreach_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outreach_member_id ON public.outreach USING btree (member_id);


--
-- TOC entry 3960 (class 1259 OID 70322)
-- Name: outreach_welcomed_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX outreach_welcomed_date ON public.outreach USING btree (welcomed_date);


--
-- TOC entry 3938 (class 1259 OID 57006)
-- Name: sms_logs_recipient_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_logs_recipient_type ON public.sms_logs USING btree (recipient_type);


--
-- TOC entry 3939 (class 1259 OID 57005)
-- Name: sms_logs_sender_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX sms_logs_sender_id ON public.sms_logs USING btree (sender_id);


--
-- TOC entry 3904 (class 1259 OID 24562)
-- Name: transactions_collected_by; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_collected_by ON public.transactions USING btree (collected_by);


--
-- TOC entry 3905 (class 1259 OID 31378)
-- Name: transactions_donation_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_donation_id ON public.transactions USING btree (donation_id);


--
-- TOC entry 3906 (class 1259 OID 32507)
-- Name: transactions_external_id; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX transactions_external_id ON public.transactions USING btree (external_id);


--
-- TOC entry 3907 (class 1259 OID 31361)
-- Name: transactions_external_id_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX transactions_external_id_unique ON public.transactions USING btree (external_id);


--
-- TOC entry 3908 (class 1259 OID 24561)
-- Name: transactions_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_member_id ON public.transactions USING btree (member_id);


--
-- TOC entry 3909 (class 1259 OID 24496)
-- Name: transactions_new_collected_by_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_new_collected_by_idx ON public.transactions USING btree (collected_by);


--
-- TOC entry 3910 (class 1259 OID 24495)
-- Name: transactions_new_member_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_new_member_id_idx ON public.transactions USING btree (member_id);


--
-- TOC entry 3911 (class 1259 OID 24497)
-- Name: transactions_new_payment_date_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_new_payment_date_idx ON public.transactions USING btree (payment_date);


--
-- TOC entry 3912 (class 1259 OID 24499)
-- Name: transactions_new_payment_method_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_new_payment_method_idx ON public.transactions USING btree (payment_method);


--
-- TOC entry 3913 (class 1259 OID 24498)
-- Name: transactions_new_payment_type_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_new_payment_type_idx ON public.transactions USING btree (payment_type);


--
-- TOC entry 3916 (class 1259 OID 24563)
-- Name: transactions_payment_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_payment_date ON public.transactions USING btree (payment_date);


--
-- TOC entry 3917 (class 1259 OID 24565)
-- Name: transactions_payment_method; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_payment_method ON public.transactions USING btree (payment_method);


--
-- TOC entry 3918 (class 1259 OID 24564)
-- Name: transactions_payment_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_payment_type ON public.transactions USING btree (payment_type);


--
-- TOC entry 3919 (class 1259 OID 31372)
-- Name: transactions_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX transactions_status ON public.transactions USING btree (status);


--
-- TOC entry 3945 (class 1259 OID 57019)
-- Name: zelle_memo_matches_member_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX zelle_memo_matches_member_id ON public.zelle_memo_matches USING btree (member_id);


--
-- TOC entry 3946 (class 1259 OID 57020)
-- Name: zelle_memo_matches_memo_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX zelle_memo_matches_memo_idx ON public.zelle_memo_matches USING btree (memo);


--
-- TOC entry 3862 (class 1259 OID 17266)
-- Name: ix_realtime_subscription_entity; Type: INDEX; Schema: realtime; Owner: -
--

CREATE INDEX ix_realtime_subscription_entity ON realtime.subscription USING btree (entity);


--
-- TOC entry 3865 (class 1259 OID 17168)
-- Name: subscription_subscription_id_entity_filters_key; Type: INDEX; Schema: realtime; Owner: -
--

CREATE UNIQUE INDEX subscription_subscription_id_entity_filters_key ON realtime.subscription USING btree (subscription_id, entity, filters);


--
-- TOC entry 3783 (class 1259 OID 16558)
-- Name: bname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bname ON storage.buckets USING btree (name);


--
-- TOC entry 3786 (class 1259 OID 16580)
-- Name: bucketid_objname; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX bucketid_objname ON storage.objects USING btree (bucket_id, name);


--
-- TOC entry 3855 (class 1259 OID 17066)
-- Name: idx_multipart_uploads_list; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_multipart_uploads_list ON storage.s3_multipart_uploads USING btree (bucket_id, key, created_at);


--
-- TOC entry 3787 (class 1259 OID 56973)
-- Name: idx_name_bucket_level_unique; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX idx_name_bucket_level_unique ON storage.objects USING btree (name COLLATE "C", bucket_id, level);


--
-- TOC entry 3788 (class 1259 OID 17031)
-- Name: idx_objects_bucket_id_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_bucket_id_name ON storage.objects USING btree (bucket_id, name COLLATE "C");


--
-- TOC entry 3789 (class 1259 OID 56975)
-- Name: idx_objects_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_objects_lower_name ON storage.objects USING btree ((path_tokens[level]), lower(name) text_pattern_ops, bucket_id, level);


--
-- TOC entry 3940 (class 1259 OID 56976)
-- Name: idx_prefixes_lower_name; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX idx_prefixes_lower_name ON storage.prefixes USING btree (bucket_id, level, ((string_to_array(name, '/'::text))[level]), lower(name) text_pattern_ops);


--
-- TOC entry 3790 (class 1259 OID 16581)
-- Name: name_prefix_search; Type: INDEX; Schema: storage; Owner: -
--

CREATE INDEX name_prefix_search ON storage.objects USING btree (name text_pattern_ops);


--
-- TOC entry 3791 (class 1259 OID 56974)
-- Name: objects_bucket_id_level_idx; Type: INDEX; Schema: storage; Owner: -
--

CREATE UNIQUE INDEX objects_bucket_id_level_idx ON storage.objects USING btree (bucket_id, level, name COLLATE "C");


--
-- TOC entry 3994 (class 2620 OID 17124)
-- Name: subscription tr_check_filters; Type: TRIGGER; Schema: realtime; Owner: -
--

CREATE TRIGGER tr_check_filters BEFORE INSERT OR UPDATE ON realtime.subscription FOR EACH ROW EXECUTE FUNCTION realtime.subscription_check_filters();


--
-- TOC entry 3989 (class 2620 OID 56983)
-- Name: buckets enforce_bucket_name_length_trigger; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER enforce_bucket_name_length_trigger BEFORE INSERT OR UPDATE OF name ON storage.buckets FOR EACH ROW EXECUTE FUNCTION storage.enforce_bucket_name_length();


--
-- TOC entry 3990 (class 2620 OID 56971)
-- Name: objects objects_delete_delete_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_delete_delete_prefix AFTER DELETE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 3991 (class 2620 OID 56969)
-- Name: objects objects_insert_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_insert_create_prefix BEFORE INSERT ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.objects_insert_prefix_trigger();


--
-- TOC entry 3992 (class 2620 OID 56970)
-- Name: objects objects_update_create_prefix; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER objects_update_create_prefix BEFORE UPDATE ON storage.objects FOR EACH ROW WHEN (((new.name <> old.name) OR (new.bucket_id <> old.bucket_id))) EXECUTE FUNCTION storage.objects_update_prefix_trigger();


--
-- TOC entry 3995 (class 2620 OID 56979)
-- Name: prefixes prefixes_create_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_create_hierarchy BEFORE INSERT ON storage.prefixes FOR EACH ROW WHEN ((pg_trigger_depth() < 1)) EXECUTE FUNCTION storage.prefixes_insert_trigger();


--
-- TOC entry 3996 (class 2620 OID 56968)
-- Name: prefixes prefixes_delete_hierarchy; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER prefixes_delete_hierarchy AFTER DELETE ON storage.prefixes FOR EACH ROW EXECUTE FUNCTION storage.delete_prefix_hierarchy_trigger();


--
-- TOC entry 3993 (class 2620 OID 17019)
-- Name: objects update_objects_updated_at; Type: TRIGGER; Schema: storage; Owner: -
--

CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON storage.objects FOR EACH ROW EXECUTE FUNCTION storage.update_updated_at_column();


--
-- TOC entry 3963 (class 2606 OID 16730)
-- Name: identities identities_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.identities
    ADD CONSTRAINT identities_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 3967 (class 2606 OID 16819)
-- Name: mfa_amr_claims mfa_amr_claims_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_amr_claims
    ADD CONSTRAINT mfa_amr_claims_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 3966 (class 2606 OID 16807)
-- Name: mfa_challenges mfa_challenges_auth_factor_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_challenges
    ADD CONSTRAINT mfa_challenges_auth_factor_id_fkey FOREIGN KEY (factor_id) REFERENCES auth.mfa_factors(id) ON DELETE CASCADE;


--
-- TOC entry 3965 (class 2606 OID 16794)
-- Name: mfa_factors mfa_factors_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.mfa_factors
    ADD CONSTRAINT mfa_factors_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 3972 (class 2606 OID 16985)
-- Name: one_time_tokens one_time_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.one_time_tokens
    ADD CONSTRAINT one_time_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 3961 (class 2606 OID 16763)
-- Name: refresh_tokens refresh_tokens_session_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.refresh_tokens
    ADD CONSTRAINT refresh_tokens_session_id_fkey FOREIGN KEY (session_id) REFERENCES auth.sessions(id) ON DELETE CASCADE;


--
-- TOC entry 3969 (class 2606 OID 16866)
-- Name: saml_providers saml_providers_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_providers
    ADD CONSTRAINT saml_providers_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 3970 (class 2606 OID 16939)
-- Name: saml_relay_states saml_relay_states_flow_state_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_flow_state_id_fkey FOREIGN KEY (flow_state_id) REFERENCES auth.flow_state(id) ON DELETE CASCADE;


--
-- TOC entry 3971 (class 2606 OID 16880)
-- Name: saml_relay_states saml_relay_states_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.saml_relay_states
    ADD CONSTRAINT saml_relay_states_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 3964 (class 2606 OID 16758)
-- Name: sessions sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sessions
    ADD CONSTRAINT sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- TOC entry 3968 (class 2606 OID 16847)
-- Name: sso_domains sso_domains_sso_provider_id_fkey; Type: FK CONSTRAINT; Schema: auth; Owner: -
--

ALTER TABLE ONLY auth.sso_domains
    ADD CONSTRAINT sso_domains_sso_provider_id_fkey FOREIGN KEY (sso_provider_id) REFERENCES auth.sso_providers(id) ON DELETE CASCADE;


--
-- TOC entry 3978 (class 2606 OID 49157)
-- Name: dependents dependents_linked_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dependents
    ADD CONSTRAINT dependents_linked_member_id_fkey FOREIGN KEY (linked_member_id) REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3979 (class 2606 OID 24466)
-- Name: dependents dependents_new_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dependents
    ADD CONSTRAINT dependents_new_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3976 (class 2606 OID 40246)
-- Name: members fk_members_welcomed_by_members_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT fk_members_welcomed_by_members_id FOREIGN KEY (welcomed_by) REFERENCES public.members(id) ON UPDATE SET NULL ON DELETE SET NULL;


--
-- TOC entry 3983 (class 2606 OID 42491)
-- Name: member_groups member_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_groups
    ADD CONSTRAINT member_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES public.groups(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3984 (class 2606 OID 42486)
-- Name: member_groups member_groups_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.member_groups
    ADD CONSTRAINT member_groups_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON UPDATE CASCADE;


--
-- TOC entry 3977 (class 2606 OID 24445)
-- Name: members members_new_family_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.members
    ADD CONSTRAINT members_new_family_id_fkey FOREIGN KEY (family_id) REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3988 (class 2606 OID 70316)
-- Name: outreach outreach_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outreach
    ADD CONSTRAINT outreach_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- TOC entry 3985 (class 2606 OID 42521)
-- Name: sms_logs sms_logs_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sms_logs
    ADD CONSTRAINT sms_logs_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.members(id) ON UPDATE CASCADE;


--
-- TOC entry 3980 (class 2606 OID 31373)
-- Name: transactions transactions_donation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_donation_id_fkey FOREIGN KEY (donation_id) REFERENCES public.donations(id) ON UPDATE CASCADE ON DELETE SET NULL;


--
-- TOC entry 3981 (class 2606 OID 24490)
-- Name: transactions transactions_new_collected_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_new_collected_by_fkey FOREIGN KEY (collected_by) REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3982 (class 2606 OID 24485)
-- Name: transactions transactions_new_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_new_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3987 (class 2606 OID 57014)
-- Name: zelle_memo_matches zelle_memo_matches_member_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.zelle_memo_matches
    ADD CONSTRAINT zelle_memo_matches_member_id_fkey FOREIGN KEY (member_id) REFERENCES public.members(id) ON UPDATE CASCADE ON DELETE RESTRICT;


--
-- TOC entry 3962 (class 2606 OID 16570)
-- Name: objects objects_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.objects
    ADD CONSTRAINT "objects_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 3986 (class 2606 OID 56956)
-- Name: prefixes prefixes_bucketId_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.prefixes
    ADD CONSTRAINT "prefixes_bucketId_fkey" FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 3973 (class 2606 OID 17041)
-- Name: s3_multipart_uploads s3_multipart_uploads_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads
    ADD CONSTRAINT s3_multipart_uploads_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 3974 (class 2606 OID 17061)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_bucket_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_bucket_id_fkey FOREIGN KEY (bucket_id) REFERENCES storage.buckets(id);


--
-- TOC entry 3975 (class 2606 OID 17056)
-- Name: s3_multipart_uploads_parts s3_multipart_uploads_parts_upload_id_fkey; Type: FK CONSTRAINT; Schema: storage; Owner: -
--

ALTER TABLE ONLY storage.s3_multipart_uploads_parts
    ADD CONSTRAINT s3_multipart_uploads_parts_upload_id_fkey FOREIGN KEY (upload_id) REFERENCES storage.s3_multipart_uploads(id) ON DELETE CASCADE;


--
-- TOC entry 4148 (class 0 OID 16523)
-- Dependencies: 236
-- Name: audit_log_entries; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.audit_log_entries ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4162 (class 0 OID 16925)
-- Dependencies: 253
-- Name: flow_state; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.flow_state ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4153 (class 0 OID 16723)
-- Dependencies: 244
-- Name: identities; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.identities ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4147 (class 0 OID 16516)
-- Dependencies: 235
-- Name: instances; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.instances ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4157 (class 0 OID 16812)
-- Dependencies: 248
-- Name: mfa_amr_claims; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_amr_claims ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4156 (class 0 OID 16800)
-- Dependencies: 247
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4155 (class 0 OID 16787)
-- Dependencies: 246
-- Name: mfa_factors; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.mfa_factors ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4163 (class 0 OID 16975)
-- Dependencies: 254
-- Name: one_time_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.one_time_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4146 (class 0 OID 16505)
-- Dependencies: 234
-- Name: refresh_tokens; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.refresh_tokens ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4160 (class 0 OID 16854)
-- Dependencies: 251
-- Name: saml_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4161 (class 0 OID 16872)
-- Dependencies: 252
-- Name: saml_relay_states; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.saml_relay_states ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4149 (class 0 OID 16531)
-- Dependencies: 237
-- Name: schema_migrations; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.schema_migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4154 (class 0 OID 16753)
-- Dependencies: 245
-- Name: sessions; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sessions ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4159 (class 0 OID 16839)
-- Dependencies: 250
-- Name: sso_domains; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_domains ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4158 (class 0 OID 16830)
-- Dependencies: 249
-- Name: sso_providers; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.sso_providers ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4145 (class 0 OID 16493)
-- Dependencies: 232
-- Name: users; Type: ROW SECURITY; Schema: auth; Owner: -
--

ALTER TABLE auth.users ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4166 (class 0 OID 17251)
-- Dependencies: 263
-- Name: messages; Type: ROW SECURITY; Schema: realtime; Owner: -
--

ALTER TABLE realtime.messages ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4150 (class 0 OID 16544)
-- Dependencies: 238
-- Name: buckets; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4168 (class 0 OID 56990)
-- Dependencies: 283
-- Name: buckets_analytics; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.buckets_analytics ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4152 (class 0 OID 16586)
-- Dependencies: 240
-- Name: migrations; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.migrations ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4151 (class 0 OID 16559)
-- Dependencies: 239
-- Name: objects; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.objects ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4167 (class 0 OID 56946)
-- Dependencies: 282
-- Name: prefixes; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.prefixes ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4164 (class 0 OID 17032)
-- Dependencies: 255
-- Name: s3_multipart_uploads; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4165 (class 0 OID 17046)
-- Dependencies: 256
-- Name: s3_multipart_uploads_parts; Type: ROW SECURITY; Schema: storage; Owner: -
--

ALTER TABLE storage.s3_multipart_uploads_parts ENABLE ROW LEVEL SECURITY;

--
-- TOC entry 4169 (class 6104 OID 16426)
-- Name: supabase_realtime; Type: PUBLICATION; Schema: -; Owner: -
--

CREATE PUBLICATION supabase_realtime WITH (publish = 'insert, update, delete, truncate');


--
-- TOC entry 3648 (class 3466 OID 16619)
-- Name: issue_graphql_placeholder; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_graphql_placeholder ON sql_drop
         WHEN TAG IN ('DROP EXTENSION')
   EXECUTE FUNCTION extensions.set_graphql_placeholder();


--
-- TOC entry 3653 (class 3466 OID 16698)
-- Name: issue_pg_cron_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_cron_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_cron_access();


--
-- TOC entry 3647 (class 3466 OID 16617)
-- Name: issue_pg_graphql_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_graphql_access ON ddl_command_end
         WHEN TAG IN ('CREATE FUNCTION')
   EXECUTE FUNCTION extensions.grant_pg_graphql_access();


--
-- TOC entry 3654 (class 3466 OID 16701)
-- Name: issue_pg_net_access; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER issue_pg_net_access ON ddl_command_end
         WHEN TAG IN ('CREATE EXTENSION')
   EXECUTE FUNCTION extensions.grant_pg_net_access();


--
-- TOC entry 3649 (class 3466 OID 16620)
-- Name: pgrst_ddl_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_ddl_watch ON ddl_command_end
   EXECUTE FUNCTION extensions.pgrst_ddl_watch();


--
-- TOC entry 3650 (class 3466 OID 16621)
-- Name: pgrst_drop_watch; Type: EVENT TRIGGER; Schema: -; Owner: -
--

CREATE EVENT TRIGGER pgrst_drop_watch ON sql_drop
   EXECUTE FUNCTION extensions.pgrst_drop_watch();


-- Completed on 2025-09-09 17:16:14 CDT

--
-- PostgreSQL database dump complete
--

